# Hydrogen V12 Supercar — 3D Studio

A modular Three.js 3D supercar showcase, tuning studio, and playable racing experience with Neon Apex UI, procedural city/circuit/drag worlds, Web Audio V12 synthesis, OBJ export, and WebM video recording.

## Project Structure

```text
hydrogen-v12-supercar-3d-studio/
├── index.html                        # Entry HTML shell
├── package.json                      # Project metadata & local server scripts
├── README.md
├── assets/
│   ├── images/                       # UI backdrops, avatars, emblems & vehicle cards
│   └── textures/                     # UV wrap textures (Serphenix wrap)
└── src/
    ├── styles/
    │   ├── studio.css                # 3D Studio HUD, telemetry, modals & responsive layout
    │   └── menu.css                  # Neon Apex start menu & cyber grid styling
    └── js/
        ├── main.js                   # Boot sequence & application entrypoint
        ├── config/constants.js       # Physics constants, time presets, finishes & defaults
        ├── state/context.js          # Centralized state, timers, DOM cache & shared refs
        ├── core/scene.js             # Three.js scene, lighting, tracks, traffic & materials
        ├── car/supercar.js           # Procedural H2-V12 supercar & aero/mechanical passes
        ├── world/cityLod.js          # Architectural LODs & infinite open-world chunks
        ├── ui/
        │   ├── hudControls.js        # Camera presets, finishes, race/AI/replay controls
        │   ├── events.js             # Keyboard, pointer, touch steering & UI event bindings
        │   └── neonApexMenu.js       # Start menu, garage tuning & system modals
        ├── simulation/
        │   ├── effects.js            # Skid marks, sparks, drift smoke, collisions & minimap
        │   └── loop.js               # Main physics, AI, camera & rendering loop
        ├── audio/soundEngine.js      # Web Audio V12 synthesizer & SFX loader
        └── export/exporters.js       # Wavefront OBJ & WebM video exporters
```

## Running Locally

Because the project uses native ES Modules (`<script type="module">`) and loads local texture assets, serve it over HTTP rather than opening `index.html` via `file://`:

```bash
# Using Python 3
python3 -m http.server 8080

# Or using Node.js
npx serve .
```

Then open `http://localhost:8080` in a WebGL-capable browser.
