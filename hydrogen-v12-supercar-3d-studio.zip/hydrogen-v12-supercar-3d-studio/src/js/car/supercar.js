import { state, refs } from '../state/context.js';

export function createSupercar() {
    const floorPan = new THREE.Mesh(new THREE.BoxGeometry(4.64, 0.08, 1.92), refs.carbonMat);
    floorPan.position.set(-0.02, 0.16, 0);
    floorPan.castShadow = true;
    floorPan.receiveShadow = true;
    refs.carGroup.add(floorPan);

    refs.underglowGroup = new THREE.Group();
    const neonBlueMat = new THREE.MeshStandardMaterial({
        color: 0x3b82f6,
        emissive: 0x1d4ed8,
        emissiveIntensity: 4.5,
        roughness: 0.1
    });
    [-0.92, 0.92].forEach(uz => {
        const sideTube = new THREE.Mesh(new THREE.BoxGeometry(2.25, 0.025, 0.035), neonBlueMat);
        sideTube.position.set(0.02, 0.135, uz);
        refs.underglowGroup.add(sideTube);
    });
    const frontTube = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.025, 1.52), neonBlueMat);
    frontTube.position.set(-2.36, 0.14, 0);
    const rearTube = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.025, 1.56), neonBlueMat);
    rearTube.position.set(2.14, 0.14, 0);
    refs.underglowGroup.add(frontTube, rearTube);

    const ugLightF = new THREE.PointLight(0x2563eb, 5.5, 7.5, 1.6);
    ugLightF.position.set(-1.1, 0.12, 0);
    const ugLightR = new THREE.PointLight(0x2563eb, 5.5, 7.5, 1.6);
    ugLightR.position.set(1.1, 0.12, 0);
    refs.underglowGroup.add(ugLightF, ugLightR);

    const ugGlowMat = new THREE.ShaderMaterial({
        transparent: true,
        depthWrite: false,
        depthTest: true,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
        uniforms: {
            uGlowColor: { value: new THREE.Color(0x1769ff) },
            uIntensity: { value: 0.92 },
            uTime: { value: 0 }
        },
        vertexShader: `
            varying vec2 vUv;
            varying vec3 vLocalPosition;
            void main() {
                vUv = uv;
                vLocalPosition = position;
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `,
        fragmentShader: `
            uniform vec3 uGlowColor;
            uniform float uIntensity;
            uniform float uTime;
            varying vec2 vUv;
            varying vec3 vLocalPosition;
            void main() {
                vec2 p = (vUv - 0.5) * 2.0;
                float radius = length(vec2(p.x * 0.78, p.y * 1.12));
                float core = exp(-radius * radius * 3.6);
                float feather = 1.0 - smoothstep(0.48, 1.0, radius);
                float subtlePulse = 0.97 + 0.03 * sin(uTime * 2.0);
                float alpha = core * feather * uIntensity * subtlePulse;
                vec3 color = uGlowColor * (0.72 + 0.28 * core);
                gl_FragColor = vec4(color, alpha);
                #include <tonemapping_fragment>
                #include <colorspace_fragment>
            }
        `
    });
    const ugPlane = new THREE.Mesh(new THREE.PlaneGeometry(5.9, 3.55, 32, 16), ugGlowMat);
    ugPlane.rotation.x = -Math.PI / 2;
    ugPlane.position.set(-0.08, 0.026, 0);
    ugPlane.renderOrder = 2;
    refs.underglowGroup.add(ugPlane);
    refs.underglowGroup.userData.glowMaterial = ugGlowMat;
    refs.carGroup.add(refs.underglowGroup);

    const splitterShape = new THREE.Shape();
    splitterShape.moveTo(-2.46, -0.58);
    splitterShape.lineTo(-2.54, 0.00);
    splitterShape.lineTo(-2.46, 0.58);
    splitterShape.lineTo(-2.22, 0.94);
    splitterShape.lineTo(-1.80, 0.94);
    splitterShape.lineTo(-1.80, -0.94);
    splitterShape.lineTo(-2.22, -0.94);
    splitterShape.closePath();

    const splitterGeo = new THREE.ExtrudeGeometry(splitterShape, { depth: 0.04, bevelEnabled: false });
    splitterGeo.rotateX(Math.PI / 2);
    const splitter = new THREE.Mesh(splitterGeo, refs.carbonMat);
    splitter.position.set(0, 0.17, 0);
    splitter.castShadow = true;
    refs.carGroup.add(splitter);

    [-0.94, 0.94].forEach(sz => {
        const skirt = new THREE.Mesh(new THREE.BoxGeometry(2.10, 0.06, 0.12), refs.carbonMat);
        skirt.position.set(0.02, 0.17, sz);
        skirt.castShadow = true;
        refs.carGroup.add(skirt);

        const fin = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.16, 0.03), refs.carbonMat);
        fin.position.set(0.92, 0.24, sz + Math.sign(sz) * 0.04);
        refs.carGroup.add(fin);
    });

    const diffuserBase = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.14, 1.74), refs.carbonMat);
    diffuserBase.position.set(2.16, 0.21, 0);
    diffuserBase.rotation.z = 0.22;
    refs.carGroup.add(diffuserBase);

    [-0.64, -0.32, 0, 0.32, 0.64].forEach(dz => {
        const strake = new THREE.Mesh(new THREE.BoxGeometry(0.40, 0.18, 0.025), refs.carbonMat);
        strake.position.set(2.20, 0.20, dz);
        refs.carGroup.add(strake);
    });

    // Raised Left & Right Front Fenders with clean wheel-arch cutout (radius 0.45)
    const noseShape = new THREE.Shape();
    noseShape.moveTo(-2.46, 0.19);
    noseShape.lineTo(-2.45, 0.62);
    noseShape.lineTo(-2.30, 0.70);
    noseShape.lineTo(-1.68, 0.74);
    noseShape.lineTo(-0.90, 0.76);
    noseShape.lineTo(-0.90, 0.19);
    noseShape.lineTo(-1.105, 0.19);
    noseShape.absarc(-1.52, 0.31, 0.415, 0, Math.PI, false);
    noseShape.lineTo(-1.935, 0.19);
    noseShape.lineTo(-2.46, 0.19);

    [-0.88, 0.54].forEach(zPos => {
        const fenderGeo = new THREE.ExtrudeGeometry(noseShape, {
            depth: 0.34,
            bevelEnabled: true,
            bevelSegments: 4,
            steps: 1,
            bevelSize: 0.025,
            bevelThickness: 0.025
        });
        fenderGeo.translate(0, 0, zPos);
        const fenderMesh = new THREE.Mesh(fenderGeo, refs.paintMat);
        fenderMesh.castShadow = true;
        fenderMesh.receiveShadow = true;
        refs.carGroup.add(fenderMesh);
    });

    // Raised Center Front Bumper Apron & Front Engine Bay Floor
    const frontApron = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.51, 1.14), refs.paintMat);
    frontApron.position.set(-2.35, 0.445, 0);
    frontApron.castShadow = true;
    frontApron.receiveShadow = true;
    const frunkFloor = new THREE.Mesh(new THREE.BoxGeometry(1.36, 0.05, 1.10), refs.carbonMat);
    frunkFloor.position.set(-1.58, 0.25, 0);
    refs.carGroup.add(frontApron, frunkFloor);

    // 2nd Engine (Front-Mounted Twin-Turbo V12 under the raised hood)
    const frontEngineBlock = new THREE.Mesh(new THREE.BoxGeometry(0.84, 0.26, 0.42), refs.alloyMat);
    frontEngineBlock.position.set(-1.58, 0.41, 0);
    const frontPlenum = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.08, 0.26), refs.carbonMat);
    frontPlenum.position.set(-1.58, 0.62, 0);
    refs.carGroup.add(frontEngineBlock, frontPlenum);

    [-0.17, 0.17].forEach(vz => {
        const fBank = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.08, 0.14), refs.chromeMat);
        fBank.position.set(-1.58, 0.56, vz);
        fBank.rotation.x = Math.sign(vz) * 0.28;
        refs.carGroup.add(fBank);
        for (let c = 0; c < 6; c++) {
            const fStack = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.018, 0.07, 10), refs.chromeMat);
            fStack.position.set(-1.88 + c * 0.12, 0.62, vz * 0.65);
            refs.carGroup.add(fStack);
        }
        // Twin front turbo housings
        const turbo = new THREE.Mesh(new THREE.TorusGeometry(0.075, 0.032, 10, 18), refs.chromeMat);
        turbo.position.set(-2.06, 0.46, vz * 1.45);
        turbo.rotation.y = Math.PI / 2;
        refs.carGroup.add(turbo);
    });

    const fBrace1 = new THREE.Mesh(new THREE.BoxGeometry(0.90, 0.028, 0.04), refs.carbonMat);
    fBrace1.position.set(-1.58, 0.68, 0);
    fBrace1.rotation.y = 0.42;
    const fBrace2 = fBrace1.clone();
    fBrace2.rotation.y = -0.42;
    const fEngLight = new THREE.PointLight(0x38bdf8, 1.2, 2.8);
    fEngLight.position.set(-1.58, 0.85, 0);
    refs.carGroup.add(fBrace1, fBrace2, fEngLight);

    // Skyline-style upper & lower front grille (raised to match taller nose)
    const upperGrille = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.14, 0.94), refs.darkTrimMat);
    upperGrille.position.set(-2.49, 0.56, 0);
    const grilleBar = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.03, 0.92), refs.chromeMat);
    grilleBar.position.set(-2.50, 0.56, 0);
    const lowerGrille = new THREE.Mesh(new THREE.BoxGeometry(0.10, 0.18, 1.24), refs.darkTrimMat);
    lowerGrille.position.set(-2.49, 0.31, 0);
    refs.carGroup.add(upperGrille, grilleBar, lowerGrille);

    // Hinged Raised Skyline Hood Pivot (hinges upward from cowl at x = -0.90, y = 0.75)
    const hoodPivot = new THREE.Group();
    hoodPivot.position.set(-0.90, 0.75, 0);
    hoodPivot.name = 'frontHood';

    const hoodLid = new THREE.Mesh(new THREE.BoxGeometry(1.44, 0.045, 1.12), refs.paintMat);
    hoodLid.position.set(-0.71, -0.018, 0);
    hoodLid.rotation.z = 0.042;
    hoodLid.castShadow = true;
    hoodLid.receiveShadow = true;
    hoodPivot.add(hoodLid);

    [-0.34, 0.34].forEach(hz => {
        const bulge = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.032, 0.22), refs.paintMat);
        bulge.position.set(-0.72, -0.005, hz);
        bulge.rotation.z = 0.042;
        const naca = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.02, 0.14), refs.darkTrimMat);
        naca.position.set(-0.82, 0.008, hz);
        naca.rotation.z = 0.042;
        hoodPivot.add(bulge, naca);
    });
    refs.carGroup.add(hoodPivot);

    const rearQuarterShape = new THREE.Shape();
    rearQuarterShape.moveTo(0.22, 0.19);
    rearQuarterShape.lineTo(0.22, 0.82);
    rearQuarterShape.lineTo(0.84, 1.06);
    rearQuarterShape.lineTo(2.16, 0.90);
    rearQuarterShape.lineTo(2.26, 0.36);
    rearQuarterShape.lineTo(1.95, 0.20);
    rearQuarterShape.absarc(1.48, 0.37, 0.47, 0, Math.PI, false);
    rearQuarterShape.lineTo(1.01, 0.19);
    rearQuarterShape.lineTo(0.22, 0.19);

    [-0.90, 0.54].forEach(zPos => {
        const qGeo = new THREE.ExtrudeGeometry(rearQuarterShape, {
            depth: 0.36,
            bevelEnabled: true,
            bevelSegments: 4,
            steps: 1,
            bevelSize: 0.025,
            bevelThickness: 0.025
        });
        qGeo.translate(0, 0, zPos);
        const qMesh = new THREE.Mesh(qGeo, refs.paintMat);
        qMesh.castShadow = true;
        qMesh.receiveShadow = true;
        refs.carGroup.add(qMesh);
    });

    [-0.95, 0.95].forEach(sz => {
        const scoop = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.38, 0.08), refs.darkTrimMat);
        scoop.position.set(0.48, 0.54, sz);
        const scoopBlade = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.42, 0.12), refs.carbonMat);
        scoopBlade.position.set(0.28, 0.54, sz);
        scoopBlade.rotation.z = -0.22;
        refs.carGroup.add(scoop, scoopBlade);
    });

    const roof = new THREE.Mesh(new THREE.BoxGeometry(1.18, 0.065, 1.36), refs.paintMat);
    roof.position.set(0.20, 1.11, 0);
    roof.castShadow = true;
    refs.carGroup.add(roof);

    const cowlSeal = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.045, 1.76), refs.darkTrimMat);
    cowlSeal.position.set(-0.94, 0.735, 0);
    const rearRoofBridge = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.08, 1.36), refs.carbonMat);
    rearRoofBridge.position.set(0.78, 1.09, 0);
    [-0.98, 0.96].forEach(bx => {
        const wb = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.62, 1.78), refs.darkTrimMat);
        wb.position.set(bx, 0.48, 0);
        refs.carGroup.add(wb);
    });
    refs.carGroup.add(cowlSeal, rearRoofBridge);



    const frontStripe = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.025, 1.88), refs.stripeMat);
    frontStripe.position.set(-2.46, 0.19, 0);
    refs.carGroup.add(frontStripe);
    [-1.00, 1.00].forEach(sz => {
        const sideStripe = new THREE.Mesh(new THREE.BoxGeometry(2.12, 0.025, 0.03), refs.stripeMat);
        sideStripe.position.set(0.02, 0.19, sz);
        refs.carGroup.add(sideStripe);
    });

    [-1, 1].forEach(sideSign => {
        const az = sideSign * 0.64;
        const pStart = new THREE.Vector3(-0.96, 0.74, sideSign * 0.87);
        const pEnd = new THREE.Vector3(-0.37, 1.11, sideSign * 0.66);
        const pDir = new THREE.Vector3().subVectors(pEnd, pStart);
        const aPillar = new THREE.Mesh(new THREE.BoxGeometry(0.09, pDir.length() + 0.05, 0.09), refs.carbonMat);
        aPillar.position.copy(pStart).addScaledVector(pDir, 0.5);
        aPillar.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), pDir.clone().normalize());
        aPillar.castShadow = true;
        refs.carGroup.add(aPillar);

        // Diagonal Rear C-Pillar Buttress matching roof corner (0.76, 1.11, ±0.64) to rear deck (1.64, 0.96, ±0.74)
        const bStart = new THREE.Vector3(0.76, 1.10, sideSign * 0.64);
        const bEnd = new THREE.Vector3(1.64, 0.96, sideSign * 0.74);
        const bDir = new THREE.Vector3().subVectors(bEnd, bStart);
        const buttress = new THREE.Mesh(new THREE.BoxGeometry(0.11, bDir.length() + 0.04, 0.11), refs.paintMat);
        buttress.position.copy(bStart).addScaledVector(bDir, 0.5);
        buttress.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), bDir.clone().normalize());
        buttress.castShadow = true;
        refs.carGroup.add(buttress);
    });

    [
        { x: -1.52, y: 0.31, rIn: 0.395, rOut: 0.445 },
        { x: 1.48, y: 0.37, rIn: 0.445, rOut: 0.495 }
    ].forEach(ax => {
        const lipShape = new THREE.Shape();
        lipShape.absarc(0, 0, ax.rOut, 0, Math.PI, false);
        lipShape.absarc(0, 0, ax.rIn, Math.PI, 0, true);
        lipShape.closePath();
        const lipGeo = new THREE.ExtrudeGeometry(lipShape, {
            depth: 0.045,
            bevelEnabled: true,
            bevelSegments: 2,
            bevelSize: 0.008,
            bevelThickness: 0.008
        });
        [-1, 1].forEach(sideSign => {
            const lip = new THREE.Mesh(lipGeo, refs.carbonMat);
            lip.position.set(ax.x, ax.y, sideSign > 0 ? 0.88 : -0.925);
            lip.castShadow = true;
            refs.carGroup.add(lip);

            const liner = new THREE.Mesh(
                new THREE.CylinderGeometry(ax.rIn, ax.rIn, 0.38, 32, 1, true, -Math.PI / 2, Math.PI),
                refs.darkTrimMat
            );
            liner.rotation.x = -Math.PI / 2;
            liner.position.set(ax.x, ax.y, sideSign * 0.72);
            refs.carGroup.add(liner);
        });
    });

    const cockpitFloor = new THREE.Mesh(new THREE.BoxGeometry(1.16, 0.04, 1.38), refs.carbonMat);
    cockpitFloor.position.set(-0.34, 0.21, 0);
    refs.carGroup.add(cockpitFloor);

    const centerTunnel = new THREE.Mesh(new THREE.BoxGeometry(1.12, 0.26, 0.22), refs.carbonMat);
    centerTunnel.position.set(-0.32, 0.35, 0);
    const infoScreen = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.14, 0.18), refs.screenMat);
    infoScreen.position.set(-0.66, 0.56, 0);
    infoScreen.rotation.z = 0.35;
    const startButton = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.02, 16), refs.tailLedMat);
    startButton.position.set(-0.46, 0.49, 0);
    refs.carGroup.add(centerTunnel, infoScreen, startButton);

    const dash = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.22, 1.38), refs.alcantaraMat);
    dash.position.set(-0.76, 0.65, 0);
    const tftCluster = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.13, 0.30), refs.screenMat);
    tftCluster.position.set(-0.62, 0.72, 0.38);
    tftCluster.rotation.z = 0.25;
    refs.carGroup.add(dash, tftCluster);

    const column = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.038, 0.28, 12), refs.carbonMat);
    column.rotation.z = -1.25;
    column.position.set(-0.56, 0.66, 0.38);
    refs.carGroup.add(column);

    const steeringGroup = new THREE.Group();
    steeringGroup.position.set(-0.42, 0.71, 0.38);
    steeringGroup.rotation.z = 0.32;
    const swRim = new THREE.Mesh(new THREE.TorusGeometry(0.14, 0.018, 10, 26), refs.alcantaraMat);
    swRim.rotation.y = Math.PI / 2;
    const swTopMarker = new THREE.Mesh(new THREE.BoxGeometry(0.022, 0.02, 0.03), refs.caliperMat);
    swTopMarker.position.set(0, 0.14, 0);
    const swHub = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.025, 16), refs.carbonMat);
    swHub.rotation.z = Math.PI / 2;
    const swSpoke = new THREE.Mesh(new THREE.BoxGeometry(0.018, 0.025, 0.26), refs.alloyMat);
    const paddleL = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.09, 0.03), refs.chromeMat);
    paddleL.position.set(-0.03, 0.02, 0.10);
    const paddleR = paddleL.clone();
    paddleR.position.z = -0.10;
    steeringGroup.add(swRim, swTopMarker, swHub, swSpoke, paddleL, paddleR);
    refs.steeringWheelMesh = steeringGroup;
    refs.carGroup.add(steeringGroup);

    const brakePedal = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.08, 0.06), refs.chromeMat);
    brakePedal.position.set(-0.84, 0.34, 0.33);
    brakePedal.rotation.z = 0.4;
    const gasPedal = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.11, 0.04), refs.chromeMat);
    gasPedal.position.set(-0.86, 0.32, 0.43);
    gasPedal.rotation.z = 0.45;
    refs.carGroup.add(brakePedal, gasPedal);

    [-0.38, 0.38].forEach(sz => {
        const base = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.10, 0.40), refs.alcantaraMat);
        base.position.set(-0.18, 0.28, sz);
        const back = new THREE.Mesh(new THREE.BoxGeometry(0.10, 0.56, 0.38), refs.alcantaraMat);
        back.position.set(0.06, 0.54, sz);
        back.rotation.z = -0.34;
        const bolsterL = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.44, 0.06), refs.paintMat);
        bolsterL.position.set(0.03, 0.52, sz + 0.18);
        bolsterL.rotation.z = -0.34;
        const bolsterR = bolsterL.clone();
        bolsterR.position.z = sz - 0.18;
        refs.carGroup.add(base, back, bolsterL, bolsterR);
    });

    const wsGeo = new THREE.BufferGeometry();
    const wsVerts = new Float32Array([
        -0.96, 0.74, -0.86,
        -0.96, 0.74,  0.86,
        -0.37, 1.11,  0.65,
        -0.37, 1.11, -0.65
    ]);
    wsGeo.setAttribute('position', new THREE.BufferAttribute(wsVerts, 3));
    wsGeo.setIndex([0, 1, 2, 0, 2, 3]);
    wsGeo.computeVertexNormals();
    const wsMat = refs.glassMat.clone();
    wsMat.side = THREE.DoubleSide;
    refs.carGroup.add(new THREE.Mesh(wsGeo, wsMat));

    const wsHeader = new THREE.Mesh(new THREE.BoxGeometry(0.10, 0.06, 1.36), refs.carbonMat);
    wsHeader.position.set(-0.37, 1.11, 0);
    const wiper = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.018, 0.025), refs.darkTrimMat);
    wiper.position.set(-0.84, 0.79, 0.12);
    wiper.rotation.z = 0.56;
    wiper.rotation.y = 0.25;
    refs.carGroup.add(wsHeader, wiper);

    function buildCarDoor(sideSign) {
        const pivot = new THREE.Group();
        pivot.position.set(-0.92, 0.21, sideSign * 0.90);
        pivot.name = sideSign > 0 ? 'carDoorL' : 'carDoorR';

        const doorShape = new THREE.Shape();
        doorShape.moveTo(0.00, 0.00);
        doorShape.lineTo(1.16, 0.00);
        doorShape.lineTo(1.16, 0.61);
        doorShape.lineTo(0.00, 0.55);
        doorShape.closePath();

        const doorGeo = new THREE.ExtrudeGeometry(doorShape, {
            depth: 0.055,
            bevelEnabled: true,
            bevelSegments: 2,
            steps: 1,
            bevelSize: 0.015,
            bevelThickness: 0.015
        });
        doorGeo.translate(0, 0, -0.0275);
        const doorPanel = new THREE.Mesh(doorGeo, refs.paintMat);
        doorPanel.castShadow = true;
        pivot.add(doorPanel);

        const winGroup = new THREE.Group();
        winGroup.position.set(0, 0.55, 0);
        winGroup.rotation.x = -sideSign * 0.54;

        const winShape = new THREE.Shape();
        winShape.moveTo(0.00, 0.00);
        winShape.lineTo(0.56, 0.42);
        winShape.lineTo(1.14, 0.42);
        winShape.lineTo(1.14, 0.06);
        winShape.lineTo(0.00, 0.00);
        winShape.closePath();
        const winGeo = new THREE.ExtrudeGeometry(winShape, { depth: 0.016, bevelEnabled: false });
        winGeo.translate(0, 0, -0.008);
        winGroup.add(new THREE.Mesh(winGeo, refs.glassMat));

        // Full perimeter window frame sealing the front A-pillar edge, top cantrail, rear, and sill
        const wfStart = new THREE.Vector3(0.00, 0.00, 0);
        const wfEnd = new THREE.Vector3(0.56, 0.42, 0);
        const wfDir = new THREE.Vector3().subVectors(wfEnd, wfStart);
        const frameFront = new THREE.Mesh(new THREE.BoxGeometry(0.045, wfDir.length() + 0.03, 0.045), refs.carbonMat);
        frameFront.position.copy(wfStart).addScaledVector(wfDir, 0.5);
        frameFront.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), wfDir.clone().normalize());

        const frameTop = new THREE.Mesh(new THREE.BoxGeometry(0.60, 0.04, 0.045), refs.carbonMat);
        frameTop.position.set(0.85, 0.42, 0);
        const frameRear = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.38, 0.045), refs.carbonMat);
        frameRear.position.set(1.14, 0.24, 0);
        const frameBottom = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.032, 0.042), refs.carbonMat);
        frameBottom.position.set(0.57, 0.01, 0);
        frameBottom.rotation.z = 0.045;
        winGroup.add(frameFront, frameTop, frameRear, frameBottom);
        pivot.add(winGroup);

        const arm = new THREE.Mesh(new THREE.BoxGeometry(0.10, 0.04, 0.14), refs.carbonMat);
        arm.position.set(0.24, 0.54, sideSign * 0.07);
        const mirror = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.10, 0.16), refs.carbonMat);
        mirror.position.set(0.24, 0.57, sideSign * 0.16);
        pivot.add(arm, mirror);

        const card = new THREE.Mesh(new THREE.BoxGeometry(0.96, 0.40, 0.03), refs.alcantaraMat);
        card.position.set(0.58, 0.28, -sideSign * 0.038);
        pivot.add(card);

        refs.carGroup.add(pivot);
    }
    buildCarDoor(1);
    buildCarDoor(-1);

    const engineFloor = new THREE.Mesh(new THREE.BoxGeometry(1.36, 0.06, 0.96), refs.carbonMat);
    engineFloor.position.set(1.25, 0.34, 0);
    refs.carGroup.add(engineFloor);

    const v12Block = new THREE.Mesh(new THREE.BoxGeometry(0.88, 0.28, 0.44), refs.alloyMat);
    v12Block.position.set(1.22, 0.50, 0);
    refs.carGroup.add(v12Block);

    [-0.16, 0.16].forEach(vz => {
        const bank = new THREE.Mesh(new THREE.BoxGeometry(0.82, 0.10, 0.16), refs.tailLedMat);
        bank.position.set(1.22, 0.66, vz);
        bank.rotation.x = Math.sign(vz) * 0.32;
        refs.carGroup.add(bank);

        for (let c = 0; c < 6; c++) {
            const stack = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.02, 0.08, 12), refs.chromeMat);
            stack.position.set(0.90 + c * 0.125, 0.73, vz * 0.65);
            refs.carGroup.add(stack);
        }
    });

    const xBrace1 = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.03, 0.045), refs.carbonMat);
    xBrace1.position.set(1.22, 0.80, 0);
    xBrace1.rotation.y = 0.42;
    const xBrace2 = xBrace1.clone();
    xBrace2.rotation.y = -0.42;
    const heatShield = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.46, 0.92), refs.goldFoilMat);
    heatShield.position.set(0.62, 0.62, 0);
    refs.carGroup.add(xBrace1, xBrace2, heatShield);

    const engLight = new THREE.PointLight(0xfacc15, 1.4, 3.0);
    engLight.position.set(1.22, 0.95, 0);
    const engLedBar = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.02, 0.04), refs.engineLedMat);
    engLedBar.position.set(1.22, 0.86, 0);
    refs.carGroup.add(engLight, engLedBar);

    const engineCoverPivot = new THREE.Group();
    engineCoverPivot.position.set(0.78, 1.04, 0);
    engineCoverPivot.name = 'engineCover';

    const coverFrameL = new THREE.Mesh(new THREE.BoxGeometry(1.32, 0.04, 0.08), refs.carbonMat);
    coverFrameL.position.set(0.66, -0.06, 0.46);
    coverFrameL.rotation.z = -0.11;
    const coverFrameR = coverFrameL.clone();
    coverFrameR.position.z = -0.46;
    const coverGlass = new THREE.Mesh(new THREE.BoxGeometry(1.24, 0.02, 0.84), refs.glassMat);
    coverGlass.position.set(0.66, -0.06, 0);
    coverGlass.rotation.z = -0.11;
    engineCoverPivot.add(coverFrameL, coverFrameR, coverGlass);

    for (let l = 0; l < 4; l++) {
        const louver = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.025, 0.82), refs.carbonMat);
        louver.position.set(0.26 + l * 0.26, -0.01 - l * 0.03, 0);
        louver.rotation.z = 0.14;
        engineCoverPivot.add(louver);
    }
    refs.carGroup.add(engineCoverPivot);

    // Skyline-inspired dual-element rectangular LED headlights
    [-0.66, 0.66].forEach(hz => {
        const housing = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.10, 0.34), refs.darkTrimMat);
        housing.position.set(-2.47, 0.61, hz);
        const ledBar = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.022, 0.31), refs.drlMat);
        ledBar.position.set(-2.525, 0.585, hz);
        refs.carGroup.add(housing, ledBar);
        [-0.08, 0.08].forEach(off => {
            const proj = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.06, 16), refs.drlMat);
            proj.rotation.z = Math.PI / 2;
            proj.position.set(-2.52, 0.625, hz + off);
            refs.carGroup.add(proj);
        });
    });

    const rearBulkhead = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.72, 1.78), refs.carbonMat);
    rearBulkhead.position.set(2.14, 0.56, 0);
    const rearGrille = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.42, 1.76), refs.darkTrimMat);
    rearGrille.position.set(2.22, 0.58, 0);
    refs.carGroup.add(rearBulkhead, rearGrille);

    // Trapezoid / Upside-Down Trapezoid Tail Lights: 2 each side [^↓ ↓^ ]
    const createTrapezoidLight = (topW, botW, h, depth, mat) => {
        const s = new THREE.Shape();
        s.moveTo(-botW / 2, -h / 2);
        s.lineTo(botW / 2, -h / 2);
        s.lineTo(topW / 2, h / 2);
        s.lineTo(-topW / 2, h / 2);
        s.closePath();
        const g = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: false });
        g.rotateY(Math.PI / 2);
        return new THREE.Mesh(g, mat);
    };
    [-1, 1].forEach(sideSign => {
        // Outer: upright trapezoid (^), Inner: upside-down trapezoid (↓)
        const specs = [
            { z: sideSign * 0.72, topW: 0.12, botW: 0.24 },
            { z: sideSign * 0.44, topW: 0.24, botW: 0.12 }
        ];
        specs.forEach(sp => {
            const bezel = createTrapezoidLight(sp.topW + 0.03, sp.botW + 0.03, 0.15, 0.04, refs.darkTrimMat);
            bezel.position.set(2.22, 0.72, sp.z);
            const led = createTrapezoidLight(sp.topW, sp.botW, 0.12, 0.05, refs.tailLedMat);
            led.position.set(2.23, 0.72, sp.z);
            refs.carGroup.add(bezel, led);
        });
    });

    [-0.64, 0.64].forEach((hz, idx) => {
        const spot = new THREE.SpotLight(0xe0f2fe, 14, 48, Math.PI / 5, 0.45, 1.2);
        spot.position.set(-2.22, 0.55, hz);
        const tgt = new THREE.Object3D();
        tgt.position.set(-16, 0.15, hz * 1.3);
        refs.carGroup.add(tgt);
        spot.target = tgt;
        refs.carGroup.add(spot);
        if (idx === 0) refs.headlightSpotL = spot;
        else refs.headlightSpotR = spot;
    });

    const flameMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.92 });
    refs.nosLight = new THREE.PointLight(0x38bdf8, 0, 8.0);
    refs.nosLight.position.set(2.8, 0.45, 0);
    refs.carGroup.add(refs.nosLight);
    [-0.12, 0, 0.12].forEach(ez => {
        const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.042, 0.14, 16), refs.exhaustGlowMat);
        pipe.rotation.z = Math.PI / 2;
        pipe.position.set(2.25, 0.42, ez);
        refs.carGroup.add(pipe);

        const flame = new THREE.Mesh(new THREE.ConeGeometry(0.042, 0.45, 10), flameMat);
        flame.rotation.z = -Math.PI / 2;
        flame.position.set(2.50, 0.42, ez);
        flame.visible = false;
        refs.carGroup.add(flame);
        refs.flameMeshes.push(flame);
    });

    const wingGroup = new THREE.Group();
    wingGroup.position.set(2.08, 0.96, 0);
    wingGroup.name = 'activeWing';

    [-0.44, 0.44].forEach(pz => {
        const pylon = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.22, 0.03), refs.carbonMat);
        pylon.position.set(-0.04, 0.06, pz);
        pylon.rotation.z = -0.25;
        wingGroup.add(pylon);
    });
    const wingBlade = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.03, 1.76), refs.carbonMat);
    wingBlade.position.set(0.04, 0.18, 0);
    wingBlade.rotation.z = -0.12;
    wingBlade.castShadow = true;
    wingGroup.add(wingBlade);

    [-0.88, 0.88].forEach(epz => {
        const endplate = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.18, 0.025), refs.carbonMat);
        endplate.position.set(0.04, 0.16, epz);
        wingGroup.add(endplate);
    });
    refs.carGroup.add(wingGroup);

    const wheelSpecs = [
        { x: -1.52, z: 0.86, r: 0.35 },
        { x: -1.52, z: -0.86, r: 0.35 },
        { x: 1.48, z: 0.88, r: 0.37 },
        { x: 1.48, z: -0.88, r: 0.37 }
    ];

    wheelSpecs.forEach((spec, wIdx) => {
        const knuckle = new THREE.Group();
        knuckle.position.set(spec.x, spec.r, spec.z);
        const wGroup = new THREE.Group();
        const sideSign = Math.sign(spec.z);
        const r = spec.r;

        const tire = new THREE.Mesh(new THREE.CylinderGeometry(r, r, 0.29, 36), refs.tireMat);
        tire.rotation.x = Math.PI / 2;
        tire.castShadow = true;
        wGroup.add(tire);

        const rim = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.72, r * 0.72, 0.30, 28), refs.alloyMat);
        rim.rotation.x = Math.PI / 2;
        wGroup.add(rim);

        const rotor = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.58, r * 0.58, 0.04, 24), refs.chromeMat);
        rotor.rotation.x = Math.PI / 2;
        rotor.position.z = sideSign * 0.02;
        wGroup.add(rotor);

        const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.33, 16), refs.chromeMat);
        hub.rotation.x = Math.PI / 2;
        wGroup.add(hub);

        for (let s = 0; s < 5; s++) {
            const baseAngle = (s / 5) * Math.PI * 2;
            [-0.14, 0.14].forEach(offset => {
                const a = baseAngle + offset;
                const spoke = new THREE.Mesh(new THREE.BoxGeometry(0.026, r * 0.66, 0.025), refs.alloyMat);
                spoke.position.set(
                    Math.cos(a) * (r * 0.36),
                    Math.sin(a) * (r * 0.36),
                    sideSign * 0.145
                );
                spoke.rotation.z = a - Math.PI / 2;
                wGroup.add(spoke);
            });
        }

        knuckle.add(wGroup);
        const caliper = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.17, 0.08), refs.caliperMat);
        caliper.position.set(0.11, 0.06, sideSign * 0.03);
        knuckle.add(caliper);

        refs.carGroup.add(knuckle);
        refs.wheels.push(wGroup);
        if (wIdx < 2) refs.frontSteerKnuckles.push(knuckle);
    });
}

export function addMechanicalDetailPass() {
    const darkSteel = new THREE.MeshStandardMaterial({ color: 0x20252c, metalness: 0.78, roughness: 0.42 });
    const rotorSteel = new THREE.MeshStandardMaterial({ color: 0x737b84, metalness: 0.88, roughness: 0.32 });
    const rubberGroove = new THREE.MeshStandardMaterial({ color: 0x101216, roughness: 0.96 });
    const fastenerMat = new THREE.MeshStandardMaterial({ color: 0xb8c0c8, metalness: 0.92, roughness: 0.22 });
    const wheelSpecs = [
        { r: 0.35, side: 1 }, { r: 0.35, side: -1 },
        { r: 0.37, side: 1 }, { r: 0.37, side: -1 }
    ];
    refs.wheels.forEach((wheel, wi) => {
        const { r, side } = wheelSpecs[wi];
        const hat = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.22, r * 0.22, 0.052, 24), darkSteel);
        hat.rotation.x = Math.PI / 2;
        hat.position.z = side * 0.052;
        wheel.add(hat);
        for (let h = 0; h < 12; h++) {
            const a = h / 12 * Math.PI * 2;
            const hole = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.006, 8), darkSteel);
            hole.rotation.x = Math.PI / 2;
            hole.position.set(Math.cos(a) * r * 0.48, Math.sin(a) * r * 0.48, side * 0.046);
            wheel.add(hole);
        }
        for (let n = 0; n < 5; n++) {
            const a = n / 5 * Math.PI * 2;
            const lug = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.018, 8), fastenerMat);
            lug.rotation.x = Math.PI / 2;
            lug.position.set(Math.cos(a) * r * 0.19, Math.sin(a) * r * 0.19, side * 0.158);
            wheel.add(lug);
        }
        const valve = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.035, 6), fastenerMat);
        valve.rotation.x = Math.PI / 2;
        valve.position.set(r * 0.68, 0, side * 0.148);
        wheel.add(valve);
        [-1, 1].forEach(edge => {
            const rib = new THREE.Mesh(new THREE.TorusGeometry(r * 0.965, 0.006, 5, 40), rubberGroove);
            rib.position.z = edge * 0.105;
            wheel.add(rib);
        });
        for (let t = 0; t < 3; t++) {
            const groove = new THREE.Mesh(new THREE.TorusGeometry(r * (0.985 - t * 0.025), 0.0035, 4, 48), rubberGroove);
            groove.position.z = side * (0.035 + t * 0.018);
            wheel.add(groove);
        }
    });

    const makeLink = (a, b, radius = 0.018) => {
        const start = new THREE.Vector3(...a), end = new THREE.Vector3(...b);
        const dir = new THREE.Vector3().subVectors(end, start);
        const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, dir.length(), 8), rotorSteel);
        mesh.position.copy(start).add(end).multiplyScalar(0.5);
        mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
        mesh.castShadow = true;
        refs.carGroup.add(mesh);
    };
    [
        [[-1.52, 0.35, 0.86], [-1.12, 0.25, 0.58]],
        [[-1.52, 0.35, -0.86], [-1.12, 0.25, -0.58]],
        [[1.48, 0.37, 0.88], [1.08, 0.25, 0.58]],
        [[1.48, 0.37, -0.88], [1.08, 0.25, -0.58]]
    ].forEach(pair => makeLink(pair[0], pair[1]));

    [-1, 1].forEach(side => {
        const stalk = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.024, 0.22, 8), darkSteel);
        stalk.position.set(-0.78, 0.83, side * 0.82);
        stalk.rotation.x = side * 0.32;
        refs.carGroup.add(stalk);
        const mirror = new THREE.Mesh(new THREE.SphereGeometry(0.105, 16, 10), refs.paintMat);
        mirror.scale.set(1.25, 0.62, 0.82);
        mirror.position.set(-0.76, 0.91, side * 0.94);
        mirror.castShadow = true;
        refs.carGroup.add(mirror);
        const glass = new THREE.Mesh(new THREE.SphereGeometry(0.072, 12, 8), refs.glassMat);
        glass.scale.set(1.12, 0.54, 0.7);
        glass.position.set(-0.69, 0.91, side * 0.985);
        refs.carGroup.add(glass);
    });
}

export function addEngineeringUpgradePass() {
    const steel = new THREE.MeshStandardMaterial({ color: 0x77818b, metalness: 0.86, roughness: 0.31 });
    const darkSteel = new THREE.MeshStandardMaterial({ color: 0x252b32, metalness: 0.72, roughness: 0.43 });
    const alloy = new THREE.MeshStandardMaterial({ color: 0xaab4bf, metalness: 0.92, roughness: 0.24 });
    const carbon = new THREE.MeshStandardMaterial({ color: 0x111820, metalness: 0.42, roughness: 0.58 });
    const ceramic = new THREE.MeshStandardMaterial({ color: 0xb9c4d0, metalness: 0.58, roughness: 0.3 });
    const gold = new THREE.MeshStandardMaterial({ color: 0xc59b50, metalness: 0.78, roughness: 0.3 });

    const addMesh = (geo, mat, pos, rot = null, parent = refs.carGroup) => {
        const m = new THREE.Mesh(geo, mat);
        m.position.set(pos[0], pos[1], pos[2]);
        if (rot) m.rotation.set(rot[0], rot[1], rot[2]);
        m.castShadow = true;
        m.receiveShadow = true;
        parent.add(m);
        return m;
    };
    const link = (a, b, radius, mat = steel) => {
        const A = new THREE.Vector3(...a), B = new THREE.Vector3(...b);
        const d = new THREE.Vector3().subVectors(B, A);
        const m = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, d.length(), 10), mat);
        m.position.copy(A).add(B).multiplyScalar(0.5);
        m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize());
        m.castShadow = true;
        refs.carGroup.add(m);
        return m;
    };

    const corners = [
        { x: -1.52, z: 0.86, r: 0.35, front: true, sgn: 1 },
        { x: -1.52, z: -0.86, r: 0.35, front: true, sgn: -1 },
        { x: 1.48, z: 0.88, r: 0.37, front: false, sgn: 1 },
        { x: 1.48, z: -0.88, r: 0.37, front: false, sgn: -1 }
    ];
    corners.forEach(c => {
        const innerX = c.x + (c.front ? 0.30 : -0.30);
        const innerZ = c.z - c.sgn * 0.30;
        const outer = [c.x, c.r + 0.03, c.z];
        const frontPivot = [innerX - 0.16, 0.28, innerZ];
        const rearPivot = [innerX + 0.16, 0.28, innerZ];
        link(outer, frontPivot, 0.024, darkSteel);
        link(outer, rearPivot, 0.024, darkSteel);
        link([c.x, c.r + 0.15, c.z], [c.x, 0.72, c.z - c.sgn * 0.11], 0.018, alloy);

        const damperBase = [innerX, 0.32, innerZ];
        const damperTop = [innerX + (c.front ? 0.10 : -0.10), 0.78, c.z - c.sgn * 0.12];
        link(damperBase, damperTop, 0.043, darkSteel);
        link([damperBase[0], damperBase[1] + 0.12, damperBase[2]], damperTop, 0.014, alloy);

        const springPath = new THREE.CatmullRomCurve3([
            new THREE.Vector3(damperBase[0], 0.39, damperBase[2]),
            new THREE.Vector3(damperBase[0] + 0.025, 0.46, damperBase[2]),
            new THREE.Vector3(damperTop[0] - 0.025, 0.66, damperTop[2]),
            new THREE.Vector3(damperTop[0], 0.73, damperTop[2])
        ]);
        const spring = new THREE.Mesh(new THREE.TubeGeometry(springPath, 22, 0.012, 6, false), gold);
        spring.castShadow = true;
        refs.carGroup.add(spring);
        [frontPivot, rearPivot].forEach(pt => addMesh(new THREE.SphereGeometry(0.045, 10, 8), alloy, pt));
    });

    [-0.62, 0.62].forEach(z => addMesh(new THREE.BoxGeometry(3.85, 0.10, 0.10), carbon, [0.02, 0.23, z]));
    [-1.12, 0.20, 1.12].forEach(x => addMesh(new THREE.BoxGeometry(0.12, 0.10, 1.34), darkSteel, [x, 0.24, 0]));

    addMesh(new THREE.BoxGeometry(1.20, 0.34, 0.62), darkSteel, [1.22, 0.56, 0]);
    addMesh(new THREE.BoxGeometry(0.98, 0.14, 0.38), alloy, [1.18, 0.78, 0]);
    [-1, 1].forEach(side => {
        for (let i = 0; i < 6; i++) {
            const x = 0.77 + i * 0.18;
            const cyl = addMesh(new THREE.CylinderGeometry(0.075, 0.085, 0.29, 12), ceramic, [x, 0.68, side * 0.245], [0, 0, Math.PI / 2]);
            cyl.name = `V12-cylinder-bank-${side}-${i + 1}`;
            addMesh(new THREE.CylinderGeometry(0.048, 0.048, 0.12, 10), darkSteel, [x, 0.84, side * 0.245], [0, 0, Math.PI / 2]);
            link([x, 0.86, side * 0.25], [x - 0.035, 0.99, side * 0.09], 0.018, alloy);
        }
        for (let i = 0; i < 3; i++) {
            const x = 0.84 + i * 0.30;
            const path = new THREE.CatmullRomCurve3([
                new THREE.Vector3(x, 0.48, side * 0.34),
                new THREE.Vector3(x + 0.08, 0.39, side * 0.52),
                new THREE.Vector3(x + 0.22, 0.39, side * 0.55),
                new THREE.Vector3(x + 0.32, 0.47, side * 0.48)
            ]);
            const pipe = new THREE.Mesh(new THREE.TubeGeometry(path, 16, 0.022, 8, false), gold);
            pipe.castShadow = true;
            refs.carGroup.add(pipe);
        }
    });

    addMesh(new THREE.BoxGeometry(0.72, 0.12, 0.28), carbon, [1.22, 1.00, 0]);
    addMesh(new THREE.CylinderGeometry(0.09, 0.09, 0.16, 16), alloy, [1.22, 1.01, 0], [Math.PI / 2, 0, 0]);
    addMesh(new THREE.BoxGeometry(0.18, 0.12, 0.12), gold, [1.75, 0.61, 0]);

    [-0.58, 0.58].forEach(z => {
        const rad = addMesh(new THREE.BoxGeometry(0.10, 0.48, 0.48), darkSteel, [-1.72, 0.52, z]);
        rad.name = 'cooling-radiator-core';
        for (let n = 0; n < 5; n++) addMesh(new THREE.BoxGeometry(0.012, 0.43, 0.45), alloy, [-1.78 + n * 0.025, 0.52, z]);
        const fan = new THREE.Group();
        fan.position.set(-1.63, 0.52, z);
        const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.065, 0.065, 0.07, 12), alloy);
        hub.rotation.z = Math.PI / 2;
        fan.add(hub);
        for (let b = 0; b < 7; b++) {
            const blade = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.025, 0.19), darkSteel);
            blade.position.set(0, Math.cos(b * Math.PI * 2 / 7) * 0.11, Math.sin(b * Math.PI * 2 / 7) * 0.11);
            blade.rotation.x = b * Math.PI * 2 / 7;
            fan.add(blade);
        }
        refs.carGroup.add(fan);
    });

    const seamMat = new THREE.LineBasicMaterial({ color: 0x111820, transparent: true, opacity: 0.72 });
    const seamPaths = [
        [[-2.10, 0.69, -0.50], [-1.78, 0.76, -0.76], [-1.38, 0.78, -0.82]],
        [[-2.10, 0.69, 0.50], [-1.78, 0.76, 0.76], [-1.38, 0.78, 0.82]],
        [[-0.58, 0.91, -0.70], [-0.25, 0.98, -0.72], [0.12, 0.94, -0.70]],
        [[-0.58, 0.91, 0.70], [-0.25, 0.98, 0.72], [0.12, 0.94, 0.70]]
    ];
    seamPaths.forEach(points => {
        const geo = new THREE.BufferGeometry().setFromPoints(points.map(v => new THREE.Vector3(...v)));
        refs.carGroup.add(new THREE.Line(geo, seamMat));
    });

    const conceptTank = addMesh(new THREE.CylinderGeometry(0.18, 0.18, 0.72, 18), gold, [1.86, 0.47, 0], [0, 0, Math.PI / 2]);
    conceptTank.name = 'conceptual-hydrogen-storage-placeholder';
    conceptTank.visible = false;
}
