import { FINISHES, TIME_PRESETS } from '../config/constants.js';
import { state, timers, clearTimerList, refs, dom } from '../state/context.js';
import { updateInfiniteWorld } from '../world/cityLod.js';
import { playCountdownBeep, playWebSfx } from '../audio/soundEngine.js';
import { clearDriveInputs } from './events.js';

export function updateStatus(finishLabel, suspLabel, temporaryResetMs = 0) {
    if (timers.statusReset) {
        clearTimeout(timers.statusReset);
        timers.statusReset = null;
    }
    if (dom.status) {
        dom.status.innerHTML =
            `CHASSIS: CARBON_MONOCOQUE_V12<br>FINISH: ${finishLabel}<br>SUSPENSION: ${suspLabel}`;
    }
    if (temporaryResetMs > 0) {
        timers.statusReset = setTimeout(() => {
            timers.statusReset = null;
            const fallback = state.isReplaying
                ? 'CINEMATIC_REPLAY'
                : state.aiDriverActive
                    ? 'AI_AUTOPILOT_ENGAGED'
                    : state.driveMode
                        ? 'FPS_DRIVE_ACTIVE'
                        : 'PUSHROD_NOMINAL';
            updateStatus(FINISHES[state.finishIdx].status, fallback);
        }, temporaryResetMs);
    }
}

export function setCameraPreset(preset) {
    if (preset === 'chase') state.camMode = 'chase';
    else if (preset === 'fps') state.camMode = 'fps';
    else state.camMode = 'orbit';

    dom.camBtns.forEach(b => {
        b.classList.toggle('active', b.dataset.cam === preset);
    });

    if (preset === 'front34') {
        state.targetRotation = { x: 0.22, y: -2.35 };
        state.targetZoom = 7.4;
        refs.desiredLookTarget.set(0, 0.55, 0);
    } else if (preset === 'rear34') {
        state.targetRotation = { x: 0.24, y: 0.78 };
        state.targetZoom = 7.4;
        refs.desiredLookTarget.set(0.1, 0.58, 0);
    } else if (preset === 'side') {
        state.targetRotation = { x: 0.08, y: 0.0 };
        state.targetZoom = 8.4;
        refs.desiredLookTarget.set(-0.05, 0.55, 0);
    } else if (preset === 'engine') {
        state.targetEngineCoverAngle = 0.68;
        dom.btnEngine.classList.add('active');
        state.targetRotation = { x: 0.45, y: 0.82 };
        state.targetZoom = 4.2;
        refs.desiredLookTarget.set(1.22, 0.72, 0);
    } else if (preset === 'chase') {
        state.targetZoom = 6.0;
    } else if (preset === 'cockpit') {
        state.targetDoorAngle = 1.08;
        dom.btnDoors.classList.add('active');
        state.targetRotation = { x: 0.26, y: 0.42 };
        state.targetZoom = 4.0;
        refs.desiredLookTarget.set(-0.32, 0.62, 0.15);
    }
}


export function applySerphenixWrapUVs(root) {
    root.updateMatrixWorld(true);
    const vPos = new THREE.Vector3();
    const vNorm = new THREE.Vector3();
    const normMat = new THREE.Matrix3();
    root.traverse(obj => {
        if (!obj.isMesh) return;
        const usesPaint = obj.material === refs.paintMat || (Array.isArray(obj.material) && obj.material.includes(refs.paintMat));
        if (!usesPaint) return;
        obj.geometry = obj.geometry.clone();
        const geo = obj.geometry;
        if (!geo.attributes.normal) geo.computeVertexNormals();
        const posAttr = geo.attributes.position;
        const normAttr = geo.attributes.normal;
        const count = posAttr.count;
        const uvs = new Float32Array(count * 2);
        normMat.getNormalMatrix(obj.matrixWorld);
        for (let i = 0; i < count; i++) {
            vPos.fromBufferAttribute(posAttr, i).applyMatrix4(obj.matrixWorld);
            vNorm.fromBufferAttribute(normAttr, i).applyMatrix3(normMat).normalize();
            const ax = Math.abs(vNorm.x), ay = Math.abs(vNorm.y), az = Math.abs(vNorm.z);
            let u, v;
            if (ay >= ax && ay >= az) {
                u = 0.257641 + vPos.x * 0.098543;
                v = 0.833500 - vPos.z * 0.140917;
            } else if (az >= ax && az > ay) {
                if (vNorm.z >= 0) {
                    u = 0.757641 + vPos.x * 0.098543;
                    v = 0.672660 + vPos.y * 0.265750;
                } else {
                    u = 0.257641 + vPos.x * 0.098543;
                    v = 0.339327 + vPos.y * 0.265750;
                }
            } else {
                if (vNorm.x < 0) {
                    u = 0.750000 + vPos.z * 0.214156;
                    v = 0.339327 + vPos.y * 0.265750;
                } else {
                    u = 0.250000 - vPos.z * 0.214156;
                    v = 0.005993 + vPos.y * 0.265750;
                }
            }
            uvs[i * 2] = u;
            uvs[i * 2 + 1] = v;
        }
        geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
        geo.attributes.uv.needsUpdate = true;
    });
}

export function cycleFinish() {
    state.finishIdx = (state.finishIdx + 1) % FINISHES.length;
    const f = FINISHES[state.finishIdx];
    refs.paintMat.map = f.useWrap ? refs.wrapTex : null;
    refs.paintMat.color.setHex(f.color);
    refs.paintMat.metalness = f.metal;
    refs.paintMat.roughness = f.rough;
    refs.paintMat.clearcoat = f.clear;
    refs.paintMat.needsUpdate = true;
    refs.caliperMat.color.setHex(f.caliper);

    dom.btnFinish.textContent = f.name;
    dom.subtitle.textContent = f.sub;
    updateStatus(f.status, 'PUSHROD_NOMINAL');
}

export function cycleTimeShift() {
    state.timeIdx = (state.timeIdx + 1) % TIME_PRESETS.length;
    const tp = TIME_PRESETS[state.timeIdx];
    refs.scene.background.setHex(tp.sky);
    refs.scene.fog.color.setHex(tp.fog);
    if (refs.hemiLightRef) {
        refs.hemiLightRef.color.setHex(tp.hemiSky);
        refs.hemiLightRef.groundColor.setHex(tp.hemiGnd);
        refs.hemiLightRef.intensity = tp.hemiInt;
    }
    if (refs.keyLightRef) {
        refs.keyLightRef.color.setHex(tp.sunCol);
        refs.keyLightRef.intensity = tp.sunInt;
        refs.keyLightRef.position.set(tp.sunPos[0], tp.sunPos[1], tp.sunPos[2]);
    }
    if (refs.lampMatRef) refs.lampMatRef.emissiveIntensity = tp.lamp;
    if (refs.winCyanRef) refs.winCyanRef.emissiveIntensity = tp.win;
    if (refs.winWarmRef) refs.winWarmRef.emissiveIntensity = tp.win * 0.85;
    if (refs.headlightSpotL) refs.headlightSpotL.intensity = tp.head;
    if (refs.headlightSpotR) refs.headlightSpotR.intensity = tp.head;
    dom.btnTimeShift.textContent = tp.name;
}

export function isAnyModalOpen() {
    return (
        (dom.bootOverlay && !dom.bootOverlay.classList.contains('hidden')) ||
        (dom.startMenu && !dom.startMenu.classList.contains('hidden')) ||
        (dom.settingsModal && dom.settingsModal.classList.contains('visible')) ||
        (dom.finishModal && dom.finishModal.classList.contains('visible'))
    );
}

export function openStartMenu() {
    if (state.isReplaying) stopReplay();
    clearTimerList(timers.countdown);
    clearTimerList(timers.dragTree);
    state.raceLocked = false;
    dom.countdownOverlay.classList.remove('visible');
    dom.finishModal.classList.remove('visible');
    dom.startMenu.classList.remove('hidden');
}

export function startRaceFromMenu() {
    dom.startMenu.classList.add('hidden');
    if (state.trackMode !== state.menuTrackChoice) {
        setTrackMode(state.menuTrackChoice);
    } else {
        restartRace();
    }
    setCameraPreset(state.menuCamChoice);
}

export function restartRace() {
    if (state.isReplaying) stopReplay();
    clearTimerList(timers.countdown);
    clearTimerList(timers.dragTree);
    dom.finishModal.classList.remove('visible');

    state.carSpeed = 0;
    state.carHeading = 0;
    state.velocityHeading = 0;
    state.driftSlipAngle = 0;
    state.nosFuel = 100;
    state.nosDepleted = false;
    state.topSpeedKmh = 0;
    state.chassisIntegrity = 100;
    dom.dmgPct.textContent = '100%';
    dom.dmgFill.style.width = '100%';
    dom.dmgFill.style.background = '#22c55e';

    state.replayBuffer = [];
    dom.btnReplay.textContent = 'Replay: Empty';
    dom.btnReplay.classList.remove('active');

    refs.carGroup.position.set(0, 0, state.isDragMode ? 3.2 : 0);
    refs.carGroup.rotation.set(0, 0, 0);
    state.dragStarted = false;
    state.dragFinished = false;
    state.dragZero100 = null;
    state.lapCount = 1;
    state.wasPastStartLine = false;

    dom.hudLap.textContent = state.isDragMode ? 'DRAG' : '1';
    dom.hudLapTime.textContent = '0.0';
    state.lastHudLapTime = '0.0';

    if (!state.driveMode) setDriveMode(true);
    setCameraPreset(state.menuCamChoice);
    runCountdown();
}

export function runCountdown() {
    clearTimerList(timers.countdown);
    state.raceLocked = true;
    const el = dom.countdownOverlay;
    const steps = ['3', '2', '1', 'GO!'];
    refs.treeLights.forEach(lm => { lm.emissiveIntensity = 0.2; });

    steps.forEach((txt, idx) => {
        const tid = setTimeout(() => {
            el.textContent = txt;
            el.classList.add('visible');
            if (state.isDragMode && refs.treeLights[idx]) refs.treeLights[idx].emissiveIntensity = 3.2;
            playCountdownBeep(txt === 'GO!');
            if (txt === 'GO!') {
                state.raceLocked = false;
                state.lapStartTime = performance.now();
                const hideTid = setTimeout(() => el.classList.remove('visible'), 650);
                timers.countdown.push(hideTid);
            }
        }, idx * 650);
        timers.countdown.push(tid);
    });
}

export function showFinishModal(title, timeText) {
    dom.finishTitle.textContent = title;
    dom.statTime.textContent = timeText;
    dom.statTopSpeed.textContent = `${state.topSpeedKmh} KM/H`;
    dom.finishModal.classList.add('visible');
}

export function toggleTrackMode() {
    const order = ['circuit', 'drag', 'openworld'];
    const next = order[(order.indexOf(state.trackMode) + 1) % order.length];
    setTrackMode(next);
}

export function setTrackMode(mode) {
    clearTimerList(timers.dragTree);
    state.trackMode = mode;
    state.isDragMode = (mode === 'drag');
    refs.circuitWorldGroup.visible = (mode === 'circuit');
    refs.dragWorldGroup.visible = (mode === 'drag');
    refs.openWorldGroup.visible = (mode === 'openworld');

    dom.btnTrackMode.textContent = mode === 'drag' ? 'Track: Drag Strip' : mode === 'openworld' ? 'Track: Open World' : 'Track: Circuit';
    dom.btnTrackMode.classList.toggle('active', mode !== 'circuit');

    state.carSpeed = 0;
    state.carHeading = 0;
    state.velocityHeading = 0;
    state.driftSlipAngle = 0;
    refs.carGroup.position.set(0, 0, state.isDragMode ? 3.2 : 0);
    refs.carGroup.rotation.set(0, 0, 0);
    state.dragStarted = false;
    state.dragFinished = false;
    state.dragZero100 = null;

    if (state.trackMode === 'openworld') {
        state.worldMorphSeed++;
        for (const val of refs.owChunks.values()) refs.openWorldGroup.remove(val.group);
        refs.owChunks.clear();
        updateInfiniteWorld(true);
    }

    if (state.isDragMode) {
        if (!state.driveMode) setDriveMode(true);
        dom.hudLap.textContent = 'DRAG';
        dom.hudLapTime.textContent = '0.0';
        dom.hudBestLap.textContent = '--.-';
        refs.treeLights.forEach(lm => { lm.emissiveIntensity = 0.2; });
        [0, 1, 2, 3].forEach(idx => {
            const tid = setTimeout(() => {
                if (state.isDragMode && refs.treeLights[idx]) refs.treeLights[idx].emissiveIntensity = 3.2;
            }, 500 * (idx + 1));
            timers.dragTree.push(tid);
        });
        updateStatus(FINISHES[state.finishIdx].status, 'DRAG_STRIP_STAGED');
    } else if (state.trackMode === 'openworld') {
        dom.hudLap.textContent = 'ROAM';
        dom.hudLapTime.textContent = '0.0';
        dom.hudBestLap.textContent = 'FREE';
        state.lapStartTime = performance.now();
        updateStatus(FINISHES[state.finishIdx].status, 'OPEN_WORLD_ROAM');
    } else {
        dom.hudLap.textContent = '1';
        updateStatus(FINISHES[state.finishIdx].status, state.driveMode ? 'FPS_DRIVE_ACTIVE' : 'PUSHROD_NOMINAL');
    }
}

export function toggleAIDriver() {
    state.aiDriverActive = !state.aiDriverActive;
    dom.btnAI.textContent = state.aiDriverActive ? 'AI Pilot: On' : 'AI Pilot: Off';
    dom.btnAI.classList.toggle('active', state.aiDriverActive);

    if (state.aiDriverActive) {
        dom.startMenu.classList.add('hidden');
        if (!state.driveMode) setDriveMode(true);
        updateStatus(FINISHES[state.finishIdx].status, 'AI_AUTOPILOT_ENGAGED');
    } else {
        state.keys.gas = false;
        state.keys.brake = false;
        state.keys.handbrake = false;
        state.keys.nos = false;
        state.manualSteerInput = 0;
        updateStatus(FINISHES[state.finishIdx].status, state.driveMode ? 'FPS_DRIVE_ACTIVE' : 'PUSHROD_NOMINAL');
    }
}

export function updateAIDriver() {
    if (state.raceLocked) {
        state.keys.gas = false;
        state.keys.brake = false;
        state.keys.handbrake = false;
        state.keys.nos = false;
        state.manualSteerInput = 0;
        return;
    }
    if (state.isDragMode) {
        const laneErr = 3.2 - refs.carGroup.position.z;
        state.manualSteerInput = THREE.MathUtils.clamp(-laneErr * 0.25 - state.carHeading * 1.5, -0.5, 0.5);
        state.keys.gas = !state.dragFinished;
        state.keys.brake = state.dragFinished;
        state.keys.handbrake = false;
        state.keys.nos = !state.dragFinished && state.nosFuel > 10;
        return;
    }
    if (state.trackMode === 'openworld') {
        const owWaypoints = [
            { x: -104, z: 0 }, { x: -104, z: -104 }, { x: 0, z: -104 }, { x: 0, z: 0 }
        ];
        let wpIdx = 0;
        if (refs.carGroup.position.x < -80 && refs.carGroup.position.z > -80) wpIdx = 1;
        else if (refs.carGroup.position.z < -80 && refs.carGroup.position.x < -20) wpIdx = 2;
        else if (refs.carGroup.position.x > -20 && refs.carGroup.position.z < -20) wpIdx = 3;
        const tgt = owWaypoints[wpIdx];
        const desiredHeading = Math.atan2(tgt.z - refs.carGroup.position.z, -(tgt.x - refs.carGroup.position.x));
        let err = desiredHeading - state.carHeading;
        while (err > Math.PI) err -= Math.PI * 2;
        while (err < -Math.PI) err += Math.PI * 2;
        state.manualSteerInput = THREE.MathUtils.clamp(err * 1.7, -1, 1);
        const absErr = Math.abs(err);
        state.keys.gas = absErr < 0.75 || state.carSpeed < 0.24;
        state.keys.brake = absErr > 0.85 && state.carSpeed > 0.35;
        state.keys.handbrake = absErr > 0.42 && state.carSpeed > 0.38;
        state.keys.nos = absErr < 0.14 && state.nosFuel > 30 && state.carSpeed > 0.25;
        return;
    }
    if (refs.trackSamples.length === 0) return;

    let bestIdx = 0, bestDistSq = Infinity;
    for (let i = 0; i < refs.trackSamples.length; i++) {
        const dx = refs.carGroup.position.x - refs.trackSamples[i].x;
        const dz = refs.carGroup.position.z - refs.trackSamples[i].z;
        const dSq = dx * dx + dz * dz;
        if (dSq < bestDistSq) {
            bestDistSq = dSq;
            bestIdx = i;
        }
    }
    const lookIdx = (bestIdx + 12) % refs.trackSamples.length;
    const tgt = refs.trackSamples[lookIdx];
    const desiredHeading = Math.atan2(tgt.z - refs.carGroup.position.z, -(tgt.x - refs.carGroup.position.x));
    let err = desiredHeading - state.carHeading;
    while (err > Math.PI) err -= Math.PI * 2;
    while (err < -Math.PI) err += Math.PI * 2;

    state.manualSteerInput = THREE.MathUtils.clamp(err * 1.75, -1, 1);
    const absErr = Math.abs(err);
    state.keys.gas = absErr < 0.72 || state.carSpeed < 0.24;
    state.keys.brake = absErr > 0.78 && state.carSpeed > 0.35;
    state.keys.handbrake = absErr > 0.38 && state.carSpeed > 0.40;
    state.keys.nos = absErr < 0.14 && state.nosFuel > 30 && state.carSpeed > 0.25;
}

export function setDriveMode(active) {
    if (active && state.isReplaying) stopReplay();
    state.driveMode = active;

    dom.btnDrive.textContent = active ? 'Drive: FPS' : 'Drive: Off';
    dom.btnDrive.classList.toggle('active', active);
    dom.driveHud.classList.toggle('visible', active);
    dom.touchDrive.classList.toggle('visible', active);
    dom.steerWheelPad.classList.toggle('visible', active);
    dom.minimapWrap.classList.toggle('visible', active);

    if (active) {
        dom.customDrawer.classList.remove('visible');
        dom.sideControls.classList.add('collapsed');
        dom.btnSideMenu.classList.remove('open');
        dom.btnSideMenu.setAttribute('aria-expanded', 'false');
        dom.btnSideMenu.textContent = '☰ Controls';
        state.lapStartTime = performance.now();
        state.lapCount = 1;
        state.wasPastStartLine = false;
        setCameraPreset('fps');
    } else {
        if (state.aiDriverActive) {
            state.aiDriverActive = false;
            dom.btnAI.textContent = 'AI Pilot: Off';
            dom.btnAI.classList.remove('active');
        }
        state.carSpeed = 0;
        refs.carGroup.position.set(0, 0, 0);
        state.carHeading = 0;
        state.velocityHeading = 0;
        state.driftSlipAngle = 0;
        refs.carGroup.rotation.set(0, 0, 0);
        refs.desiredLookTarget.set(0, 0.55, 0);
        setCameraPreset('front34');
    }
    updateStatus(FINISHES[state.finishIdx].status, active ? 'FPS_DRIVE_ACTIVE' : 'PUSHROD_NOMINAL');
}

export function toggleReplay() {
    if (state.isReplaying) {
        stopReplay();
    } else if (state.replayBuffer.length > 10) {
        if (state.driveMode) {
            state.driveMode = false;
            dom.btnDrive.textContent = 'Drive: Off';
            dom.btnDrive.classList.remove('active');
            dom.touchDrive.classList.remove('visible');
            dom.steerWheelPad.classList.remove('visible');
        }
        state.isReplaying = true;
        state.replayIndex = 0;
        state.replayCamCut = 0;
        state.replayCutTimer = 0;
        const f0 = state.replayBuffer[0];
        refs.apexCamPos.set(f0.x - Math.cos(f0.h) * 8 + 3, 1.35, f0.z + Math.sin(f0.h) * 8 + 3);
        dom.btnReplay.textContent = 'Stop Replay';
        dom.btnReplay.classList.add('active');
        document.body.classList.add('replay-clean');
        dom.replayBanner.classList.add('visible');
        dom.minimapWrap.classList.add('visible');
        dom.driveHud.classList.add('visible');
        updateStatus(FINISHES[state.finishIdx].status, 'CINEMATIC_REPLAY');
    }
}

export function stopReplay() {
    state.isReplaying = false;
    document.body.classList.remove('replay-clean');
    dom.btnReplay.textContent = state.replayBuffer.length > 10 ? 'Replay' : 'Replay: Empty';
    dom.btnReplay.classList.remove('active');
    dom.replayBanner.classList.remove('visible');
    dom.minimapWrap.classList.remove('visible');
    dom.driveHud.classList.remove('visible');
    setCameraPreset('front34');
    updateStatus(FINISHES[state.finishIdx].status, 'PUSHROD_NOMINAL');
}
