import { DEFAULT_SETTINGS, FINISHES } from '../config/constants.js';
import { state, refs, dom, applySettings } from '../state/context.js';
import {
    setCameraPreset, cycleFinish, cycleTimeShift, isAnyModalOpen,
    openStartMenu, startRaceFromMenu, restartRace, toggleTrackMode,
    setTrackMode, toggleAIDriver, setDriveMode, toggleReplay, stopReplay, updateStatus
} from './hudControls.js';
import { toggleV12Sound, playWebSfx } from '../audio/soundEngine.js';
import { exportToOBJ, toggleVideoExport } from '../export/exporters.js';
import { drawMinimap } from '../simulation/effects.js';

export function clearDriveInputs() {
    Object.keys(state.keys).forEach(k => { state.keys[k] = false; });
    state.manualSteerInput = 0;
    state.isWheelDragging = false;
    dom.driveKeys.forEach(b => b.classList.remove('pressed'));
}

export function bindEvents() {
    window.addEventListener('resize', () => {
        refs.camera.aspect = window.innerWidth / window.innerHeight;
        refs.camera.updateProjectionMatrix();
        refs.renderer.setSize(window.innerWidth, window.innerHeight);
    });

    // Orbit Mouse Controls
    refs.renderer.domElement.addEventListener('mousedown', e => {
        state.isDragging = true;
        state.previousMousePosition = { x: e.clientX, y: e.clientY };
    });
    window.addEventListener('mouseup', () => { state.isDragging = false; });
    window.addEventListener('mousemove', e => {
        if (!state.isDragging) return;
        const dx = e.clientX - state.previousMousePosition.x;
        const dy = e.clientY - state.previousMousePosition.y;
        state.targetRotation.y -= dx * 0.0065;
        state.targetRotation.x += dy * 0.0055;
        state.targetRotation.x = Math.max(0.04, Math.min(Math.PI / 2 - 0.15, state.targetRotation.x));
        state.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    refs.renderer.domElement.addEventListener('wheel', e => {
        e.preventDefault();
        state.targetZoom += e.deltaY * 0.008;
        state.targetZoom = Math.max(3.2, Math.min(18, state.targetZoom));
    }, { passive: false });

    // Orbit Touch Controls
    refs.renderer.domElement.addEventListener('touchstart', e => {
        state.isDragging = true;
        if (e.touches.length === 1) {
            state.previousMousePosition = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        } else if (e.touches.length === 2) {
            state.initialPinchDistance = Math.hypot(
                e.touches[0].clientX - e.touches[1].clientX,
                e.touches[0].clientY - e.touches[1].clientY
            );
        }
    }, { passive: true });

    refs.renderer.domElement.addEventListener('touchmove', e => {
        e.preventDefault();
        if (e.touches.length === 1 && state.isDragging) {
            const dx = e.touches[0].clientX - state.previousMousePosition.x;
            const dy = e.touches[0].clientY - state.previousMousePosition.y;
            state.targetRotation.y -= dx * 0.008;
            state.targetRotation.x += dy * 0.007;
            state.targetRotation.x = Math.max(0.04, Math.min(Math.PI / 2 - 0.15, state.targetRotation.x));
            state.previousMousePosition = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        } else if (e.touches.length === 2) {
            const dist = Math.hypot(
                e.touches[0].clientX - e.touches[1].clientX,
                e.touches[0].clientY - e.touches[1].clientY
            );
            state.targetZoom += (state.initialPinchDistance - dist) * 0.035;
            state.targetZoom = Math.max(3.2, Math.min(18, state.targetZoom));
            state.initialPinchDistance = dist;
        }
    }, { passive: false });

    refs.renderer.domElement.addEventListener('touchend', () => {
        state.isDragging = false;
        state.initialPinchDistance = 0;
    });

    // Side Panel Controls
    dom.btnDoors.addEventListener('click', () => {
        state.targetDoorAngle = state.targetDoorAngle === 0 ? 1.08 : 0;
        dom.btnDoors.classList.toggle('active', state.targetDoorAngle !== 0);
        playWebSfx('door', 0.3);
    });

    dom.btnHood.addEventListener('click', () => {
        state.targetHoodAngle = state.targetHoodAngle === 0 ? 0.72 : 0;
        dom.btnHood.classList.toggle('active', state.targetHoodAngle !== 0);
    });

    dom.btnEngine.addEventListener('click', () => {
        state.targetEngineCoverAngle = state.targetEngineCoverAngle === 0 ? 0.68 : 0;
        dom.btnEngine.classList.toggle('active', state.targetEngineCoverAngle !== 0);
    });

    dom.btnWing.addEventListener('click', () => {
        state.targetWingLift = state.targetWingLift === 0 ? 0.14 : 0;
        dom.btnWing.classList.toggle('active', state.targetWingLift !== 0);
    });

    dom.btnFinish.addEventListener('click', cycleFinish);

    dom.btnDrop.addEventListener('click', () => {
        refs.carGroup.position.y = 3.8;
        state.velocityY = 0;
        updateStatus(FINISHES[state.finishIdx].status, 'IMPACT_TEST_9.2G', 2200);
    });

    dom.btnExportObj.addEventListener('click', exportToOBJ);
    dom.btnExportVideo.addEventListener('click', toggleVideoExport);
    dom.btnDrive.addEventListener('click', () => setDriveMode(!state.driveMode));
    dom.btnAI.addEventListener('click', toggleAIDriver);
    dom.btnReplay.addEventListener('click', toggleReplay);
    dom.replayBanner.addEventListener('click', stopReplay);
    dom.replayBanner.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            stopReplay();
        }
    });
    dom.btnTrackMode.addEventListener('click', toggleTrackMode);
    dom.btnTimeShift.addEventListener('click', cycleTimeShift);

    dom.btnUnderglow.addEventListener('click', () => {
        state.underglowEnabled = !state.underglowEnabled;
        if (refs.underglowGroup) refs.underglowGroup.visible = state.underglowEnabled;
        dom.btnUnderglow.textContent = state.underglowEnabled ? 'Underglow: On' : 'Underglow: Off';
        dom.btnUnderglow.classList.toggle('active', state.underglowEnabled);
    });

    dom.btnTraffic.addEventListener('click', () => {
        state.trafficEnabled = !state.trafficEnabled;
        dom.btnTraffic.textContent = state.trafficEnabled ? 'Traffic: On' : 'Traffic: Off';
        dom.btnTraffic.classList.toggle('active', state.trafficEnabled);
        refs.trafficCars.forEach(tc => { tc.mesh.visible = state.trafficEnabled; });
        refs.pedestrians.forEach(pd => { pd.mesh.visible = state.trafficEnabled; });
    });

    dom.btnRestart.addEventListener('click', restartRace);
    dom.btnMenu.addEventListener('click', openStartMenu);

    dom.btnSideMenu.addEventListener('click', () => {
        const collapsed = dom.sideControls.classList.toggle('collapsed');
        dom.btnSideMenu.classList.toggle('open', !collapsed);
        dom.btnSideMenu.setAttribute('aria-expanded', String(!collapsed));
        dom.btnSideMenu.textContent = collapsed ? '☰ Controls' : '◀ Hide';
    });

    // Settings Modal (Centralized State + Persistence + Delegation)
    const openSettings = () => dom.settingsModal.classList.add('visible');
    const closeSettings = () => dom.settingsModal.classList.remove('visible');

    dom.btnSettings.addEventListener('click', openSettings);
    if (dom.btnMenuSettings) dom.btnMenuSettings.addEventListener('click', openSettings);
    dom.btnCloseSettings.addEventListener('click', closeSettings);
    dom.settingsModal.addEventListener('click', e => {
        if (e.target === dom.settingsModal) closeSettings();
    });

    dom.settingsModal.addEventListener('click', e => {
        const toggle = e.target.closest('.setting-toggle');
        if (!toggle) return;
        const key = toggle.dataset.uiKey;
        if (!Object.prototype.hasOwnProperty.call(DEFAULT_SETTINGS, key)) return;
        applySettings({ [key]: !state.settings[key] });
    });

    dom.speedMultSlider.addEventListener('input', e => {
        const parsed = parseFloat(e.target.value);
        if (Number.isFinite(parsed)) {
            applySettings({ speedMultiplier: parsed });
        }
    });

    dom.btnResetSettings.addEventListener('click', () => {
        applySettings({ ...DEFAULT_SETTINGS });
    });

    // Start Menu
    dom.menuTrackBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            state.menuTrackChoice = btn.dataset.menuTrack;
            dom.menuTrackBtns.forEach(b => b.classList.toggle('selected', b === btn));
        });
    });
    dom.menuCamBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            state.menuCamChoice = btn.dataset.menuCam;
            dom.menuCamBtns.forEach(b => b.classList.toggle('selected', b === btn));
        });
    });
    dom.btnStartRace.addEventListener('click', startRaceFromMenu);
    window._h2v12Bridge = {
        startRace: startRaceFromMenu,
        openHudSettings: openSettings
    };
    dom.btnStartAI.addEventListener('click', () => {
        startRaceFromMenu();
        if (!state.aiDriverActive) toggleAIDriver();
    });
    dom.btnInspectGarage.addEventListener('click', () => {
        dom.startMenu.classList.add('hidden');
        setDriveMode(false);
        dom.customDrawer.classList.add('visible');
    });

    // Garage Customisation
    dom.liveryPicker.addEventListener('input', e => { refs.paintMat.color.set(e.target.value); });
    dom.stripePicker.addEventListener('input', e => {
        refs.stripeMat.color.set(e.target.value);
        refs.caliperMat.color.set(e.target.value);
    });
    dom.upgAero.addEventListener('click', e => {
        e.currentTarget.classList.toggle('active');
        const w = refs.carGroup.getObjectByName('activeWing');
        if (w) w.visible = e.currentTarget.classList.contains('active');
    });
    dom.upgTurbo.addEventListener('click', e => {
        e.currentTarget.classList.toggle('active');
        state.turboBoostMult = e.currentTarget.classList.contains('active') ? 1.08 : 0.94;
    });

    // Finish Modal
    dom.btnRaceAgain.addEventListener('click', () => {
        dom.finishModal.classList.remove('visible');
        restartRace();
    });
    dom.btnFinishReplay.addEventListener('click', () => {
        dom.finishModal.classList.remove('visible');
        toggleReplay();
    });
    dom.btnBackMenu.addEventListener('click', () => {
        dom.finishModal.classList.remove('visible');
        openStartMenu();
    });

    dom.btnSound.addEventListener('click', toggleV12Sound);

    // Keyboard Controls
    window.addEventListener('keydown', e => {
        if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
        if (e.key === 'Escape') {
            if (dom.settingsModal.classList.contains('visible')) {
                dom.settingsModal.classList.remove('visible');
            } else {
                openStartMenu();
            }
            return;
        }
        if (isAnyModalOpen()) return;

        const k = e.key.toLowerCase();
        if (['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) {
            if (state.driveMode || k.startsWith('arrow') || k === ' ') e.preventDefault();
            if (!state.driveMode) setDriveMode(true);
        }
        if (k === 'w' || k === 'arrowup') state.keys.gas = true;
        if (k === 's' || k === 'arrowdown') state.keys.brake = true;
        if (k === 'a' || k === 'arrowleft') state.keys.left = true;
        if (k === 'd' || k === 'arrowright') state.keys.right = true;
        if (k === ' ') state.keys.handbrake = true;
        if (e.key === 'Shift') state.keys.nos = true;
        if (k === 'r' && state.driveMode) restartRace();
        if (k === 'm' && state.driveMode) {
            state.minimapExpanded = !state.minimapExpanded;
            dom.minimapWrap.classList.toggle('expanded', state.minimapExpanded);
            drawMinimap();
        }
    });

    window.addEventListener('keyup', e => {
        const k = e.key.toLowerCase();
        if (k === 'w' || k === 'arrowup') state.keys.gas = false;
        if (k === 's' || k === 'arrowdown') state.keys.brake = false;
        if (k === 'a' || k === 'arrowleft') state.keys.left = false;
        if (k === 'd' || k === 'arrowright') state.keys.right = false;
        if (k === ' ') state.keys.handbrake = false;
        if (e.key === 'Shift') state.keys.nos = false;
    });

    window.addEventListener('blur', clearDriveInputs);
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) clearDriveInputs();
    });

    // Touch Steering Wheel
    dom.steerWheelPad.addEventListener('pointerdown', e => {
        e.preventDefault();
        e.stopPropagation();
        state.isWheelDragging = true;
        state.wheelDragStartX = e.clientX;
        dom.steerWheelPad.setPointerCapture(e.pointerId);
    });
    dom.steerWheelPad.addEventListener('pointermove', e => {
        if (!state.isWheelDragging) return;
        e.preventDefault();
        const dx = e.clientX - state.wheelDragStartX;
        state.manualSteerInput = Math.max(-1, Math.min(1, -dx / 55));
    });
    const endWheelDrag = () => {
        state.isWheelDragging = false;
        state.manualSteerInput = 0;
    };
    dom.steerWheelPad.addEventListener('pointerup', endWheelDrag);
    dom.steerWheelPad.addEventListener('pointercancel', endWheelDrag);

    // Touch Pedals (Gas + Slide to Drift / NOS)
    let gasSlideActive = false;
    let gasStartX = 0;
    let gasStartY = 0;

    dom.gasBtn.addEventListener('pointerdown', e => {
        e.preventDefault();
        e.stopPropagation();
        gasSlideActive = true;
        gasStartX = e.clientX;
        gasStartY = e.clientY;
        state.keys.gas = true;
        dom.gasBtn.classList.add('pressed');
        dom.gasBtn.setPointerCapture(e.pointerId);
    });
    dom.gasBtn.addEventListener('pointermove', e => {
        if (!gasSlideActive) return;
        e.preventDefault();
        const dx = e.clientX - gasStartX;
        const dy = e.clientY - gasStartY;
        const driftRect = dom.driftBtn.getBoundingClientRect();
        const nosRect = dom.nosBtn.getBoundingClientRect();

        const slidingToDrift = dx < -22 || e.clientX <= driftRect.right + 10;
        const slidingToNos = dy < -22 || e.clientY <= nosRect.bottom + 8;

        state.keys.handbrake = slidingToDrift;
        state.keys.nos = slidingToNos;
        dom.driftBtn.classList.toggle('pressed', slidingToDrift);
        dom.nosBtn.classList.toggle('pressed', slidingToNos);
    });
    const endGasSlide = e => {
        if (!gasSlideActive) return;
        e.preventDefault();
        gasSlideActive = false;
        state.keys.gas = false;
        state.keys.handbrake = false;
        state.keys.nos = false;
        dom.gasBtn.classList.remove('pressed');
        dom.driftBtn.classList.remove('pressed');
        dom.nosBtn.classList.remove('pressed');
    };
    dom.gasBtn.addEventListener('pointerup', endGasSlide);
    dom.gasBtn.addEventListener('pointercancel', endGasSlide);

    [dom.driftBtn, dom.brakeBtn, dom.nosBtn].forEach(btn => {
        const k = btn.dataset.key;
        const setK = (val, ev) => {
            ev.preventDefault();
            state.keys[k] = val;
            btn.classList.toggle('pressed', val);
        };
        btn.addEventListener('pointerdown', e => setK(true, e));
        btn.addEventListener('pointerup', e => setK(false, e));
        btn.addEventListener('pointerleave', e => setK(false, e));
        btn.addEventListener('pointercancel', e => setK(false, e));
    });

    const toggleMinimapExpand = () => {
        state.minimapExpanded = !state.minimapExpanded;
        dom.minimapWrap.classList.toggle('expanded', state.minimapExpanded);
        drawMinimap();
    };
    dom.minimapWrap.addEventListener('click', toggleMinimapExpand);

    dom.camBtns.forEach(btn => {
        btn.addEventListener('click', () => setCameraPreset(btn.dataset.cam));
    });
}
