      (() => {
        
    const state = {
      muted: false,
      bloom: true,
      grid: true,
      volume: 75,
      difficulty: 'Pro',
      selectedEvent: 'circuit',
      selectedCamera: 'cockpit',
      selectedTrack: 0,
      activeCarIdx: 0,
      equippedPartIds: ['nitro_cell', 'apex_ecu'],
      events: {
        circuit: { label: 'Circuit · 3-Lap Race' },
        drag: { label: 'Drag Strip · 1/4-Mile ET' },
        open: { label: 'Open World · Free Roam' }
      },
      cameras: {
        cockpit: { label: 'FPS Cockpit' },
        chase: { label: 'Chase Cam' }
      },
      cars: [
        {
          id: 'valkyrie',
          name: 'VALKYRIE-X',
          tier: 'S-CLASS',
          img: './assets/images/hero-backdrop.jpg',
          speed: 88,
          nitro: 84,
          handling: 82,
          basePI: 880
        },
        {
          id: 'emerald_ghost',
          name: 'EMERALD GHOST',
          tier: 'S+ PROTOTYPE',
          img: './assets/images/car-emerald-ghost.jpg',
          speed: 94,
          nitro: 90,
          handling: 89,
          basePI: 935
        }
      ],
      tracks: [
        { name: 'SECTOR 7 RAINWAY', length: '4.8 KM', weather: 'Heavy Neon Rain', reward: '12,000 CR' },
        { name: 'EMERALD OVERPASS', length: '6.2 KM', weather: 'Midnight Mist', reward: '18,500 CR' },
        { name: 'COBALT HARBOR CIRCUIT', length: '5.5 KM', weather: 'Clear Cyber-Dusk', reward: '15,000 CR' }
      ],
      parts: [
        { id: 'nitro_cell', name: 'Quantum Nitro Cell', icon: '🔋', bonusPI: 24, stat: '+8 Nitro' },
        { id: 'apex_ecu', name: 'Apex ECU Chip', icon: '💾', bonusPI: 20, stat: '+6 Speed' },
        { id: 'aero_wing', name: 'Carbon Cyber Wing', icon: '🪽', bonusPI: 18, stat: '+7 Handling' },
        { id: 'plasma_coil', name: 'Plasma Ignition', icon: '⚡', bonusPI: 22, stat: '+5 Speed' },
        { id: 'mag_tires', name: 'Mag-Grip Slicks', icon: '🛞', bonusPI: 16, stat: '+6 Handling' },
        { id: 'cryo_cool', name: 'Cryo Intercooler', icon: '❄️', bonusPI: 15, stat: '+5 Nitro' }
      ]
    };

    // --- Web Audio ---
    let audioCtx = null;
    function ensureAudio() {
      if (!audioCtx && (window.AudioContext || window.webkitAudioContext)) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      }
      if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume().catch(() => {});
      }
    }

    function playTone(freq, duration = 0.08, type = 'sine', gainVal = 0.08) {
      if (state.muted) return;
      ensureAudio();
      if (!audioCtx) return;
      try {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
        gain.gain.setValueAtTime(gainVal * (state.volume / 100), audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + duration);
      } catch (_) {}
    }

    function showToast(msg) {
      const el = document.getElementById('statusToast');
      el.textContent = msg;
      el.classList.remove('opacity-0');
      clearTimeout(el._timer);
      el._timer = setTimeout(() => el.classList.add('opacity-0'), 2400);
    }

    function getActiveCarPI() {
      const car = state.cars[state.activeCarIdx];
      const partBonus = state.parts
        .filter(p => state.equippedPartIds.includes(p.id))
        .reduce((sum, p) => sum + p.bonusPI, 0);
      return car.basePI + partBonus;
    }

    function syncHUD() {
      const car = state.cars[state.activeCarIdx];
      document.getElementById('activeCarLabel').textContent = `${car.name} · ${car.tier}`;
      document.getElementById('activeCarRating').textContent = `${getActiveCarPI()} PI`;
      document.getElementById('hudNitroBar').style.width = `${Math.min(100, car.nitro + state.equippedPartIds.length * 2)}%`;
      document.getElementById('heroBackdropImg').src = car.img;
    }

    // --- Event & Camera Selectors ---
    document.querySelectorAll('#eventGrid [data-event]').forEach(btn => {
      btn.addEventListener('click', () => {
        state.selectedEvent = btn.dataset.event;
        document.querySelectorAll('#eventGrid [data-event]').forEach(b => {
          const active = b.dataset.event === state.selectedEvent;
          b.classList.toggle('active', active);
          b.querySelector('.event-arrow').classList.toggle('hidden', !active);
        });
        playTone(620, 0.06, 'triangle', 0.07);
        showToast(`Event: ${state.events[state.selectedEvent].label}`);
      });
    });

    document.querySelectorAll('#cameraGrid [data-camera]').forEach(btn => {
      btn.addEventListener('click', () => {
        state.selectedCamera = btn.dataset.camera;
        document.querySelectorAll('#cameraGrid [data-camera]').forEach(b => {
          const active = b.dataset.camera === state.selectedCamera;
          b.classList.toggle('active', active);
          b.querySelector('.cam-arrow').classList.toggle('hidden', !active);
        });
        playTone(660, 0.06, 'triangle', 0.07);
        showToast(`Camera: ${state.cameras[state.selectedCamera].label}`);
      });
    });

    // --- Modal System ---
    const modalOverlay = document.getElementById('neonModalOverlay');
    const modalContent = document.getElementById('neonModalContent');

    function openModal(html) {
      playTone(540, 0.09, 'triangle', 0.09);
      modalContent.innerHTML = html;
      modalOverlay.classList.remove('hidden');
      modalOverlay.classList.add('flex');
      const closeBtn = modalContent.querySelector('[data-close-modal]');
      if (closeBtn) closeBtn.addEventListener('click', closeModal);
    }

    function closeModal() {
      playTone(320, 0.07, 'sine', 0.06);
      modalOverlay.classList.add('hidden');
      modalOverlay.classList.remove('flex');
    }

    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) closeModal();
    });

    
    function openInventoryModal() {
      const slots = [];
      for (let i = 0; i < 12; i++) {
        const part = state.parts[i];
        if (part) {
          const isEq = state.equippedPartIds.includes(part.id);
          slots.push(`
            <button data-part="${part.id}" class="inv-slot p-2 ${isEq ? 'equipped' : ''}">
              <span class="text-2xl">${part.icon}</span>
              <span class="font-tech text-[11px] font-bold text-white mt-1 leading-tight text-center">${part.name}</span>
              <span class="font-tech text-[10px] text-emerald-300">${part.stat}</span>
            </button>
          `);
        } else {
          slots.push(`<div class="inv-slot opacity-40 cursor-default"><span class="font-tech text-[10px] text-slate-500">EMPTY</span></div>`);
        }
      }

      openModal(`
        <div class="flex items-center justify-between mb-3">
          <h2 class="font-display text-lg font-extrabold tracking-wider text-cyan-300">TUNING &amp; UPGRADES</h2>
          <button data-close-modal class="close-x-btn">✕</button>
        </div>
        <p class="font-tech text-xs text-slate-300 mb-3">Click any module to equip or unequip it on your active machine (${getActiveCarPI()} PI).</p>
        <div class="grid grid-cols-3 sm:grid-cols-6 gap-2.5">${slots.join('')}</div>
      `);

      modalContent.querySelectorAll('[data-part]').forEach(btn => {
        btn.addEventListener('click', () => {
          const id = btn.dataset.part;
          if (state.equippedPartIds.includes(id)) {
            state.equippedPartIds = state.equippedPartIds.filter(x => x !== id);
          } else {
            state.equippedPartIds.push(id);
          }
      
    // --- Fullscreen Start & Toggle ---
    function enterFullscreen() {
      const el = document.documentElement;
      if (!document.fullscreenElement && el.requestFullscreen) {
        try {
          const p = el.requestFullscreen();
          if (p && typeof p.catch === 'function') p.catch(() => {});
        } catch (_) {}
      }
    }

    function toggleFullscreen() {
      if (document.fullscreenElement) {
        if (document.exitFullscreen) {
          document.exitFullscreen().catch(() => {});
        }
      } else {
        enterFullscreen();
      }
    }

    document.getElementById('topFullscreenBtn').addEventListener('click', (e) => {
      e.stopPropagation();
      playTone(600, 0.06);
      toggleFullscreen();
    });

    // Attempt fullscreen on load; if browser requires a user gesture, enter on first interaction
    window.addEventListener('load', () => {
      enterFullscreen();
    });
    let fsArmed = true;
    function armFirstGestureFullscreen() {
      if (!fsArmed) return;
      fsArmed = false;
      enterFullscreen();
    }
    window.addEventListener('pointerdown', armFirstGestureFullscreen, { once: true });
    window.addEventListener('keydown', armFirstGestureFullscreen, { once: true });

    syncHUD();
          playTone(680, 0.06);
          openInventoryModal();
        });
      });
    }

    function openOptionsModal() {
      openModal(`
        <div class="flex items-center justify-between mb-4">
          <h2 class="font-display text-lg font-extrabold tracking-wider text-cyan-300">UI SETTINGS</h2>
          <button data-close-modal class="close-x-btn">✕</button>
        </div>
        <div class="space-y-4 font-tech text-sm">
          <div>
            <div class="flex justify-between mb-1"><span>MASTER VOLUME</span><span id="volVal" class="text-cyan-300">${state.volume}%</span></div>
            <input id="volSlider" type="range" min="0" max="100" value="${state.volume}" class="w-full accent-emerald-400 cursor-pointer" />
          </div>
          <label class="flex items-center justify-between p-3 rounded-lg bg-[#060B16]/75 border border-slate-600/60 cursor-pointer">
            <span>MUTE AUDIO</span>
            <input id="muteToggle" type="checkbox" ${state.muted ? 'checked' : ''} class="w-4 h-4 accent-emerald-400" />
          </label>
          <label class="flex items-center justify-between p-3 rounded-lg bg-[#060B16]/75 border border-slate-600/60 cursor-pointer">
            <span>NEON BLOOM EFFECTS</span>
            <input id="bloomToggle" type="checkbox" ${state.bloom ? 'checked' : ''} class="w-4 h-4 accent-emerald-400" />
          </label>
          <label class="flex items-center justify-between p-3 rounded-lg bg-[#060B16]/75 border border-slate-600/60 cursor-pointer">
            <span>HUD CYBER GRID OVERLAY</span>
            <input id="gridToggle" type="checkbox" ${state.grid ? 'checked' : ''} class="w-4 h-4 accent-emerald-400" />
          </label>
        </div>
      `);

      document.getElementById('volSlider').addEventListener('input', (e) => {
        state.volume = Number(e.target.value);
        document.getElementById('volVal').textContent = `${state.volume}%`;
      });

      document.getElementById('muteToggle').addEventListener('change', (e) => {
        state.muted = e.target.checked;
        showToast(state.muted ? 'Audio Muted' : 'Audio Enabled');
      });

      document.getElementById('bloomToggle').addEventListener('change', (e) => {
        state.bloom = e.target.checked;
        const sm = document.getElementById('startMenu'); if (sm) sm.classList.toggle('bloom-active', state.bloom);
        playTone(500, 0.05);
      });

      document.getElementById('gridToggle').addEventListener('change', (e) => {
        state.grid = e.target.checked;
        document.getElementById('gridOverlay').style.display = state.grid ? 'block' : 'none';
        playTone(500, 0.05);
      });
    }

    function openSystemMenuModal() {
      openModal(`
        <div class="flex items-center justify-between mb-4">
          <h2 class="font-display text-lg font-extrabold tracking-wider text-cyan-300">SYSTEM &amp; DRIVER HUB</h2>
          <button data-close-modal class="close-x-btn">✕</button>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 font-tech text-sm">
          <div class="p-3 rounded-lg bg-[#060B16]/75 border border-slate-600/60">
            <div class="text-xs text-slate-400">DRIVER STATS</div>
            <div class="font-display text-base text-emerald-300 mt-1">42 WINS · 342 KM/H</div>
          </div>
          <div class="p-3 rounded-lg bg-[#060B16]/75 border border-slate-600/60">
            <div class="text-xs text-slate-400">SECTOR 7 RANK</div>
            <div class="font-display text-base text-cyan-300 mt-1">#1 · 01:42.09</div>
          </div>
        </div>
        <div class="mt-4 space-y-2 font-tech text-sm">
          <div class="flex justify-between p-2.5 rounded bg-[#060B16]/70"><span>Steer Left / Right</span><span class="text-cyan-300">A / D or ◀ / ▶</span></div>
          <div class="flex justify-between p-2.5 rounded bg-[#060B16]/70"><span>Activate Nitro</span><span class="text-emerald-300">SPACE</span></div>
          <div class="flex justify-between p-2.5 rounded bg-[#060B16]/70"><span>Quick Launch Race</span><span class="text-cyan-300">ENTER</span></div>
        </div>
      `);
    }

    // --- Mini Playable Race & AI Demo ---
    let raceRaf = null;
    let raceRunning = false;
    
    // --- Wire Menu Buttons ---
    // btnStartRace wired by 3D Studio
    // btnStartAI wired by 3D Studio
    document.getElementById('btnTuning').addEventListener('click', openInventoryModal);
    // btnInspectGarage wired by 3D Studio
    document.getElementById('neonBtnSettings').addEventListener('click', openOptionsModal);
    document.getElementById('topSettingsBtn').addEventListener('click', openOptionsModal);
    document.getElementById('topPowerBtn').addEventListener('click', openSystemMenuModal);
    document.getElementById('driverHudBtn').addEventListener('click', openSystemMenuModal);

    document.querySelectorAll('.menu-bar-btn, .hex-btn, .selector-card').forEach(btn => {
      btn.addEventListener('mouseenter', () => playTone(480, 0.03, 'sine', 0.025));
    });

    window.addEventListener('keydown', (e) => {
      const sm = document.getElementById('startMenu');
      const menuVisible = sm && !sm.classList.contains('hidden');
      if (!menuVisible) return;
      if (e.key === 'Enter' && modalOverlay.classList.contains('hidden')) {
        playTone(720, 0.08, 'triangle', 0.07);
        if (window._h2v12Bridge && window._h2v12Bridge.startRace) window._h2v12Bridge.startRace();
      }
      if (e.key === 'Escape' && !modalOverlay.classList.contains('hidden')) {
        closeModal();
      }
    });


    
    function toggleFullscreen() {
      if (document.fullscreenElement) {
        if (document.exitFullscreen) document.exitFullscreen().catch(() => {});
      } else {
        const el = document.documentElement;
        if (el.requestFullscreen) {
          try {
            const p = el.requestFullscreen();
            if (p && typeof p.catch === 'function') p.catch(() => {});
          } catch (_) {}
        }
      }
    }

    document.getElementById('topFullscreenBtn').addEventListener('click', (e) => {
      e.stopPropagation();
      playTone(600, 0.06);
      toggleFullscreen();
    });

    window.closeNeonModal = closeModal;
    syncHUD();

      })();
