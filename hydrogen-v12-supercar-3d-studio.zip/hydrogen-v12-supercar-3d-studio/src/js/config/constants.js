export const MAX_REPLAY_FRAMES = 1200;
export const GRAVITY = -0.014;
export const BOUNCE = 0.36;
export const CHUNK_SIZE = 52;
export const SETTINGS_STORAGE_KEY = 'hydrogen_h2v12_ui_settings_v1';
export const DEFAULT_SETTINGS = Object.freeze({
    'hide-telemetry': false,
    'hide-minimap': false,
    'hide-touch': false,
    'hide-cams': false,
    'hide-title': false,
    'hide-status': false,
    speedMultiplier: 1.0
});

export const TIME_PRESETS = [
    { name: 'Time: Night',  sky: 0x07090d, fog: 0x07090d, hemiSky: 0x94a3b8, hemiGnd: 0x181c24, hemiInt: 0.85, sunCol: 0xdbeafe, sunInt: 1.9, sunPos: [8, 16, 10],   lamp: 2.2, head: 14, win: 1.4 },
    { name: 'Time: Dawn',   sky: 0x2b1d38, fog: 0x3b2645, hemiSky: 0xfda4af, hemiGnd: 0x272030, hemiInt: 1.05, sunCol: 0xfdba74, sunInt: 2.3, sunPos: [-35, 9, 18],  lamp: 1.2, head: 7,  win: 0.7 },
    { name: 'Time: Noon',   sky: 0x38bdf8, fog: 0x7dd3fc, hemiSky: 0xe0f2fe, hemiGnd: 0x334155, hemiInt: 1.35, sunCol: 0xffffff, sunInt: 3.1, sunPos: [12, 42, 14],  lamp: 0.2, head: 1,  win: 0.2 },
    { name: 'Time: Sunset', sky: 0x451a1a, fog: 0x7c2d12, hemiSky: 0xfb923c, hemiGnd: 0x1e1b24, hemiInt: 1.00, sunCol: 0xf97316, sunInt: 2.5, sunPos: [38, 7, -16],  lamp: 1.6, head: 9,  win: 1.1 }
];

export const SERPHENIX_WRAP_URL = './assets/textures/serphenix-wrap.png';

export const FINISHES = [
    { name: 'Finish: Serphenix Wrap', sub: 'SERPHENIX SP-01 // UV WRAP', status: 'SERPHENIX_SP01_WRAP', color: 0xffffff, metal: 0.42, rough: 0.20, clear: 1.0, caliper: 0xdc2626, useWrap: true },
    { name: 'Finish: Cobalt', sub: 'COBALT AERO // H2-V12', status: 'COBALT_H2V12', color: 0x1e3a8a, metal: 0.45, rough: 0.16, clear: 1.0, caliper: 0xdc2626, useWrap: false },
    { name: 'Finish: Solar Gold', sub: 'SOLAR GOLD // CARBON MONOCOQUE', status: 'SOLAR_GOLD_PEARL', color: 0xfacc15, metal: 0.25, rough: 0.16, clear: 1.0, caliper: 0xfacc15 },
    { name: 'Finish: Venom Green', sub: 'VENOM GREEN // CARBON MONOCOQUE', status: 'VENOM_GREEN_PEARL', color: 0x65a30d, metal: 0.28, rough: 0.16, clear: 1.0, caliper: 0x84cc16 },
    { name: 'Finish: CNC Billet', sub: 'AL-7075-T6 // BILLET MACHINED', status: 'AL-7075_CNC_BILLET', color: 0x9aa3ad, metal: 0.94, rough: 0.20, clear: 0.35, caliper: 0x00f2ff }
];

export const WEB_SFX_URLS = {
    engine: 'https://actions.google.com/sounds/v1/transportation/car_engine_idling_accelerating.ogg',
    shift: 'https://actions.google.com/sounds/v1/transportation/car_gear_shift.ogg',
    door: 'https://actions.google.com/sounds/v1/transportation/car_door_open_shut.ogg'
};
