import { timers, clearTimerList, dom, loadSettings, applySettings, cacheDom } from './state/context.js';
import { init } from './core/scene.js';

export function runBootSequence() {
    const steps = [
        { pct: 25, text: '&gt; V12_POWERTRAIN.SYS ..... OK' },
        { pct: 55, text: '&gt; V12_POWERTRAIN.SYS ..... OK<br>&gt; AERO_MONOCOQUE.DAT ..... OK' },
        { pct: 85, text: '&gt; V12_POWERTRAIN.SYS ..... OK<br>&gt; AERO_MONOCOQUE.DAT ..... OK<br>&gt; CITY_CIRCUIT_MAP ....... OK' },
        { pct: 100, text: '&gt; V12_POWERTRAIN.SYS ..... OK<br>&gt; AERO_MONOCOQUE.DAT ..... OK<br>&gt; CITY_CIRCUIT_MAP ....... READY' }
    ];

    let finished = false;
    const finishBoot = () => {
        if (finished) return;
        finished = true;
        clearTimerList(timers.boot);
        dom.bootOverlay.classList.add('hidden');
        dom.startMenu.classList.remove('hidden');
    };

    dom.btnBootSkip.addEventListener('click', finishBoot);

    steps.forEach((st, idx) => {
        const tid = setTimeout(() => {
            if (finished) return;
            dom.bootBarFill.style.width = `${st.pct}%`;
            dom.bootPct.textContent = `${st.pct}%`;
            dom.bootLines.innerHTML = st.text;
            if (st.pct === 100) {
                const endTid = setTimeout(finishBoot, 450);
                timers.boot.push(endTid);
            }
        }, (idx + 1) * 450);
        timers.boot.push(tid);
    });
}

window.addEventListener('DOMContentLoaded', () => {
    try {
        if (typeof THREE === 'undefined') {
            throw new Error('Three.js failed to load.');
        }
        if (!window.WebGLRenderingContext) {
            throw new Error('WebGL is unavailable in this browser.');
        }
        cacheDom();
        applySettings(loadSettings(), false);
        init();
        runBootSequence();
    } catch (err) {
        console.error('3D Studio initialization failed:', err);
        const overlay = document.createElement('div');
        overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;display:grid;place-items:center;padding:24px;background:#070b14;color:#f8fafc;font:14px/1.6 system-ui;text-align:center';
        overlay.innerHTML = '<div><h2>3D Studio could not start</h2><p>This browser may not support WebGL, or the Three.js library could not load.</p><p style="color:#94a3b8">Try enabling hardware acceleration and reopening the file with an internet connection.</p></div>';
        document.body.appendChild(overlay);
    }
});
