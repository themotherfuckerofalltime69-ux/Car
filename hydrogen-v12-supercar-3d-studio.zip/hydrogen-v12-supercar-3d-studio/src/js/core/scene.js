import { FINISHES, SERPHENIX_WRAP_URL } from '../config/constants.js';
import { state, refs } from '../state/context.js';
import { createSupercar, addMechanicalDetailPass, addEngineeringUpgradePass } from '../car/supercar.js';
import { addArchitecturalBuildingDetail, createUrbanBuildingLOD, updateInfiniteWorld } from '../world/cityLod.js';
import { setCameraPreset, updateStatus, applySerphenixWrapUVs } from '../ui/hudControls.js';
import { bindEvents } from '../ui/events.js';
import { animate } from '../simulation/loop.js';

export function init() {
    refs.lookTarget = new THREE.Vector3(0, 0.55, 0);
    refs.desiredLookTarget = new THREE.Vector3(0, 0.55, 0);
    refs.apexCamPos = new THREE.Vector3(6, 1.4, 6);

    refs.scene = new THREE.Scene();
    refs.scene.background = new THREE.Color(0x07090d);
    refs.scene.fog = new THREE.Fog(0x07090d, 35, 220);

    refs.camera = new THREE.PerspectiveCamera(36, window.innerWidth / window.innerHeight, 0.1, 450);

    refs.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    refs.renderer.setSize(window.innerWidth, window.innerHeight);
    refs.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    refs.renderer.outputColorSpace = THREE.SRGBColorSpace;
    refs.renderer.shadowMap.enabled = true;
    refs.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    refs.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    refs.renderer.toneMappingExposure = 1.2;
    document.body.appendChild(refs.renderer.domElement);

    refs.carGroup = new THREE.Group();
    setupLighting();
    setupFloor();
    createMaterials();
    createSupercar();
    addMechanicalDetailPass();
    addEngineeringUpgradePass();
    applySerphenixWrapUVs(refs.carGroup);
    refs.scene.add(refs.carGroup);

    bindEvents();
    requestAnimationFrame(animate);
}

export function setupLighting() {
    const hemi = new THREE.HemisphereLight(0xf1f5f9, 0x181c24, 0.85);
    refs.hemiLightRef = hemi;
    refs.scene.add(hemi);

    const keyLight = new THREE.DirectionalLight(0xffffff, 2.3);
    refs.keyLightRef = keyLight;
    keyLight.position.set(8, 16, 10);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    keyLight.shadow.camera.near = 2;
    keyLight.shadow.camera.far = 40;
    keyLight.shadow.camera.left = -7;
    keyLight.shadow.camera.right = 7;
    keyLight.shadow.camera.top = 7;
    keyLight.shadow.camera.bottom = -7;
    keyLight.shadow.bias = -0.0005;
    refs.scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x93c5fd, 0.9);
    fillLight.position.set(-10, 7, -9);
    refs.scene.add(fillLight);

    const rimLight = new THREE.SpotLight(0xfacc15, 28, 28, Math.PI / 4, 0.6);
    rimLight.position.set(0, 6, -10);
    rimLight.lookAt(0, 0.6, 0);
    refs.scene.add(rimLight);
}

export function setupFloor() {
    const worldGroup = new THREE.Group();

    const ground = new THREE.Mesh(
        new THREE.PlaneGeometry(520, 520),
        new THREE.MeshStandardMaterial({ color: 0x0b0e14, roughness: 0.9, metalness: 0.15 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    worldGroup.add(ground);

    const trackPts = [
        new THREE.Vector3(  25, 0,   0),
        new THREE.Vector3( -45, 0,   0),
        new THREE.Vector3(-105, 0,  -6),
        new THREE.Vector3(-130, 0, -45),
        new THREE.Vector3(-110, 0, -95),
        new THREE.Vector3( -45, 0,-112),
        new THREE.Vector3(  20, 0, -88),
        new THREE.Vector3(  65, 0,-118),
        new THREE.Vector3( 122, 0, -92),
        new THREE.Vector3( 135, 0, -35),
        new THREE.Vector3( 105, 0,  18),
        new THREE.Vector3(  65, 0,   6)
    ];
    const trackCurve = new THREE.CatmullRomCurve3(trackPts, true, 'catmullrom', 0.45);
    const SEGMENTS = 260;
    const HALF_W = 8.2;

    const roadVerts = [];
    const roadIndices = [];
    const up = new THREE.Vector3(0, 1, 0);
    const pt = new THREE.Vector3();
    const tan = new THREE.Vector3();
    const side = new THREE.Vector3();

    const sampledPts = [];
    const sampledSides = [];
    const sampledTans = [];

    for (let i = 0; i <= SEGMENTS; i++) {
        const t = (i % SEGMENTS) / SEGMENTS;
        trackCurve.getPointAt(t, pt);
        trackCurve.getTangentAt(t, tan).normalize();
        side.crossVectors(tan, up).normalize();
        sampledPts.push(pt.clone());
        refs.trackSamples.push(pt.clone());
        sampledSides.push(side.clone());
        sampledTans.push(tan.clone());

        const l = pt.clone().addScaledVector(side, -HALF_W);
        const r = pt.clone().addScaledVector(side, HALF_W);
        roadVerts.push(l.x, 0.02, l.z, r.x, 0.02, r.z);
    }

    for (let i = 0; i < SEGMENTS; i++) {
        const a = i * 2, b = i * 2 + 1, c = (i + 1) * 2, d = (i + 1) * 2 + 1;
        roadIndices.push(a, c, b, b, c, d);
    }

    const roadGeo = new THREE.BufferGeometry();
    roadGeo.setAttribute('position', new THREE.Float32BufferAttribute(roadVerts, 3));
    roadGeo.setIndex(roadIndices);
    roadGeo.computeVertexNormals();
    const roadMesh = new THREE.Mesh(
        roadGeo,
        new THREE.MeshStandardMaterial({ color: 0x1a1d24, roughness: 0.72, metalness: 0.12 })
    );
    roadMesh.receiveShadow = true;
    worldGroup.add(roadMesh);

    const redMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.6 });
    const whiteMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.6 });
    const barrierMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.75 });
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.7, roughness: 0.3 });
    const lampMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xfacc15, emissiveIntensity: 2.2 });

    for (let i = 0; i < SEGMENTS; i++) {
        const p0 = sampledPts[i];
        const p1 = sampledPts[i + 1];
        const s0 = sampledSides[i];
        const t0 = sampledTans[i];
        const segLen = p0.distanceTo(p1);
        const mid = p0.clone().lerp(p1, 0.5);
        const yaw = Math.atan2(t0.x, t0.z);

        if (i % 2 === 0) {
            const dash = new THREE.Mesh(
                new THREE.BoxGeometry(0.22, 0.015, segLen * 0.65),
                lampMat
            );
            dash.position.set(mid.x, 0.03, mid.z);
            dash.rotation.y = yaw;
            worldGroup.add(dash);
        }

        const cMat = (i % 2 === 0) ? redMat : whiteMat;
        [-1, 1].forEach(dir => {
            const curbPos = mid.clone().addScaledVector(s0, dir * (HALF_W + 0.45));
            const curb = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.08, segLen + 0.05), cMat);
            curb.position.set(curbPos.x, 0.04, curbPos.z);
            curb.rotation.y = yaw;
            curb.receiveShadow = true;
            worldGroup.add(curb);
        });

        if (i % 2 === 0) {
            [-1, 1].forEach(dir => {
                const bPos = mid.clone().addScaledVector(s0, dir * (HALF_W + 2.2));
                const barrier = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.85, segLen * 1.95), barrierMat);
                barrier.position.set(bPos.x, 0.425, bPos.z);
                barrier.rotation.y = yaw;
                barrier.castShadow = true;
                barrier.receiveShadow = true;
                worldGroup.add(barrier);
            });
        }

        if (i % 12 === 0) {
            const lPos = p0.clone().addScaledVector(s0, -(HALF_W + 3.0));
            const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.11, 6.2, 8), poleMat);
            pole.position.set(lPos.x, 3.1, lPos.z);
            const arm = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.1, 0.1), poleMat);
            arm.position.set(lPos.x + s0.x * 1.0, 6.15, lPos.z + s0.z * 1.0);
            arm.rotation.y = yaw;
            const bulb = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.08, 0.25), lampMat);
            bulb.position.set(lPos.x + s0.x * 1.9, 6.08, lPos.z + s0.z * 1.9);
            bulb.rotation.y = yaw;
            worldGroup.add(pole, arm, bulb);
        }
    }

    const gantryGroup = new THREE.Group();
    gantryGroup.position.set(-14, 0, 0);
    [-HALF_W - 1.2, HALF_W + 1.2].forEach(gz => {
        const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.6, 6.4, 0.6), poleMat);
        pillar.position.set(0, 3.2, gz);
        pillar.castShadow = true;
        gantryGroup.add(pillar);
        refs.buildingColliders.push({ minX: -14.4, maxX: -13.6, minZ: gz - 0.4, maxZ: gz + 0.4 });
    });
    const truss = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.1, HALF_W * 2 + 3.0), poleMat);
    truss.position.set(0, 6.0, 0);
    const signBoard = new THREE.Mesh(
        new THREE.BoxGeometry(1.15, 0.65, 10.5),
        new THREE.MeshStandardMaterial({ color: 0x0f172a, emissive: 0x0284c7, emissiveIntensity: 0.7 })
    );
    signBoard.position.set(0, 6.0, 0);
    gantryGroup.add(truss, signBoard);

    for (let cz = -HALF_W + 0.5; cz < HALF_W; cz += 1.0) {
        for (let cx = 0; cx < 2; cx++) {
            const isWhite = (Math.floor(cz + 10) + cx) % 2 === 0;
            const sq = new THREE.Mesh(
                new THREE.BoxGeometry(0.95, 0.015, 0.95),
                isWhite ? whiteMat : barrierMat
            );
            sq.position.set(-0.5 + cx * 1.0, 0.032, cz);
            gantryGroup.add(sq);
        }
    }
    worldGroup.add(gantryGroup);

    const bldgMat1 = new THREE.MeshStandardMaterial({ color: 0x161b26, roughness: 0.6, metalness: 0.4 });
    const bldgMat2 = new THREE.MeshStandardMaterial({ color: 0x1f2737, roughness: 0.5, metalness: 0.5 });
    const winCyan = new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0ea5e9, emissiveIntensity: 1.4 });
    const winWarm = new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xeab308, emissiveIntensity: 1.1 });
    refs.lampMatRef = lampMat;
    refs.winCyanRef = winCyan;
    refs.winWarmRef = winWarm;

    let seed = 42;
    const rand = () => {
        seed = (seed * 1664525 + 1013904223) % 4294967296;
        return seed / 4294967296;
    };
    const windowGeo = new THREE.BoxGeometry(0.92, 1.28, 0.075);
    const windowMat = new THREE.MeshStandardMaterial({
        color: 0xffffff, emissive: 0x8acfff, emissiveIntensity: 1.15,
        roughness: 0.28, metalness: 0.12
    });
    const facadeFinMat = new THREE.MeshStandardMaterial({ color: 0x303b4e, roughness: 0.72, metalness: 0.35 });
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x101722, roughness: 0.82, metalness: 0.18 });

    for (let gx = -180; gx <= 180; gx += 26) {
        for (let gz = -170; gz <= 170; gz += 26) {
            const cand = new THREE.Vector3(gx + (rand() - 0.5) * 6, 0, gz + (rand() - 0.5) * 6);
            let minD = 999;
            for (let k = 0; k < sampledPts.length; k += 2) {
                const d = cand.distanceTo(sampledPts[k]);
                if (d < minD) minD = d;
            }
            if (minD < HALF_W + 12.5) continue;

            const bw = 11 + rand() * 10;
            const bd = 11 + rand() * 10;
            const bh = 16 + rand() * 48;
            const baseMat = rand() > 0.5 ? bldgMat1 : bldgMat2;
            const lod = new THREE.LOD();
            lod.position.set(cand.x, 0, cand.z);

            const near = new THREE.Group();
            const shell = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, bd), baseMat);
            shell.position.y = bh / 2;
            shell.castShadow = true;
            shell.receiveShadow = true;
            near.add(shell);

            const colsX = Math.max(3, Math.floor(bw / 2.15));
            const colsZ = Math.max(3, Math.floor(bd / 2.15));
            const rows = Math.max(2, Math.floor((bh - 7) / 4.0));
            const windowCount = (colsX + colsZ) * rows * 2;
            const windows = new THREE.InstancedMesh(windowGeo, windowMat, windowCount);
            windows.castShadow = false;
            windows.receiveShadow = true;
            const dummy = new THREE.Object3D();
            let wi = 0;
            const addWindow = (x, y, z, rotY) => {
                dummy.position.set(x, y, z);
                dummy.rotation.set(0, rotY, 0);
                dummy.updateMatrix();
                windows.setMatrixAt(wi, dummy.matrix);
                const lit = rand();
                windows.setColorAt(wi, lit > 0.82 ? new THREE.Color(0xffd98a) : (lit > 0.48 ? new THREE.Color(0x78cfff) : new THREE.Color(0x26384e)));
                wi++;
            };
            for (let row = 0; row < rows; row++) {
                const wy = 4.0 + row * 4.0;
                for (let col = 0; col < colsX; col++) {
                    const x = -bw / 2 + (col + 0.5) * bw / colsX;
                    addWindow(x, wy, -bd / 2 - 0.045, 0);
                    addWindow(x, wy, bd / 2 + 0.045, Math.PI);
                }
                for (let col = 0; col < colsZ; col++) {
                    const z = -bd / 2 + (col + 0.5) * bd / colsZ;
                    addWindow(-bw / 2 - 0.045, wy, z, -Math.PI / 2);
                    addWindow(bw / 2 + 0.045, wy, z, Math.PI / 2);
                }
            }
            windows.count = wi;
            windows.instanceMatrix.needsUpdate = true;
            if (windows.instanceColor) windows.instanceColor.needsUpdate = true;
            near.add(windows);
            addArchitecturalBuildingDetail(near, bw, bh, bd, Math.round(bw * 11 + bh * 5 + bd));

            for (let sideSign = -1; sideSign <= 1; sideSign += 2) {
                for (let fin = 0; fin <= 2; fin++) {
                    const x = (fin - 1) * (bw / 3);
                    const rib = new THREE.Mesh(new THREE.BoxGeometry(0.13, bh, 0.18), facadeFinMat);
                    rib.position.set(x, bh / 2, sideSign * (bd / 2 + 0.09));
                    near.add(rib);
                }
            }
            const roofUnit = new THREE.Mesh(new THREE.BoxGeometry(bw * 0.34, 1.25, bd * 0.28), roofMat);
            roofUnit.position.set(bw * 0.17, bh + 0.62, -bd * 0.12);
            near.add(roofUnit);
            const roofVent = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.75, 1.0), roofMat);
            roofVent.position.set(-bw * 0.22, bh + 0.38, bd * 0.18);
            near.add(roofVent);
            lod.addLevel(near, 0);

            const mid = new THREE.Group();
            const midShell = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, bd), baseMat);
            midShell.position.y = bh / 2;
            mid.add(midShell);
            const bandMat = rand() > 0.5 ? winCyan : winWarm;
            for (let wy = 4.5; wy < bh - 2; wy += 8.5) {
                const band = new THREE.Mesh(new THREE.BoxGeometry(bw + 0.12, 0.12, bd + 0.12), bandMat);
                band.position.y = wy;
                mid.add(band);
            }
            lod.addLevel(mid, 88);

            const far = new THREE.Group();
            const silhouette = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, bd), baseMat);
            silhouette.position.y = bh / 2;
            far.add(silhouette);
            lod.addLevel(far, 185);
            lod.updateMatrixWorld(true);
            worldGroup.add(lod);

            refs.buildingColliders.push({
                minX: cand.x - bw / 2, maxX: cand.x + bw / 2,
                minZ: cand.z - bd / 2, maxZ: cand.z + bd / 2
            });
        }
    }

    refs.circuitWorldGroup = worldGroup;
    refs.scene.add(refs.circuitWorldGroup);

    // Drag Strip World
    refs.dragWorldGroup = new THREE.Group();
    refs.dragWorldGroup.visible = false;

    const dragGround = new THREE.Mesh(
        new THREE.PlaneGeometry(520, 520),
        new THREE.MeshStandardMaterial({ color: 0x090c12, roughness: 0.9, metalness: 0.15 })
    );
    dragGround.rotation.x = -Math.PI / 2;
    refs.dragWorldGroup.add(dragGround);

    const strip = new THREE.Mesh(
        new THREE.BoxGeometry(300, 0.04, 15),
        new THREE.MeshStandardMaterial({ color: 0x181b22, roughness: 0.65, metalness: 0.15 })
    );
    strip.position.set(-130, 0.02, 0);
    strip.receiveShadow = true;
    refs.dragWorldGroup.add(strip);

    for (let dx = 10; dx >= -270; dx -= 6) {
        const line = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.015, 0.2), lampMat);
        line.position.set(dx, 0.045, 0);
        refs.dragWorldGroup.add(line);
    }
    [-8.0, 8.0].forEach(wz => {
        const wall = new THREE.Mesh(new THREE.BoxGeometry(300, 1.0, 0.6), barrierMat);
        wall.position.set(-130, 0.5, wz);
        wall.castShadow = true;
        wall.receiveShadow = true;
        refs.dragWorldGroup.add(wall);
    });

    const stageLine = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.02, 15), whiteMat);
    stageLine.position.set(-2.5, 0.045, 0);
    refs.dragWorldGroup.add(stageLine);

    const finishGantry = new THREE.Group();
    finishGantry.position.set(-220, 0, 0);
    [-8.2, 8.2].forEach(gz => {
        const p = new THREE.Mesh(new THREE.BoxGeometry(0.6, 6.2, 0.6), poleMat);
        p.position.set(0, 3.1, gz);
        finishGantry.add(p);
    });
    const fBeam = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.0, 17.5), poleMat);
    fBeam.position.set(0, 5.8, 0);
    const fSign = new THREE.Mesh(
        new THREE.BoxGeometry(1.06, 0.7, 10),
        new THREE.MeshStandardMaterial({ color: 0x0f172a, emissive: 0xef4444, emissiveIntensity: 0.8 })
    );
    fSign.position.set(0, 5.8, 0);
    const fLine = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.02, 15), whiteMat);
    fLine.position.set(0, 0.045, 0);
    finishGantry.add(fBeam, fSign, fLine);
    refs.dragWorldGroup.add(finishGantry);

    const treePole = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.11, 2.8, 10), poleMat);
    treePole.position.set(-4.5, 1.4, 0);
    refs.dragWorldGroup.add(treePole);
    const lightColors = [0xf59e0b, 0xf59e0b, 0xf59e0b, 0x22c55e];
    lightColors.forEach((col, idx) => {
        const lm = new THREE.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: 0.2 });
        const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 12), lm);
        bulb.position.set(-4.35, 2.35 - idx * 0.38, 0);
        refs.dragWorldGroup.add(bulb);
        refs.treeLights.push(lm);
    });

    for (let fx = 0; fx >= -260; fx -= 26) {
        [-9.2, 9.2].forEach(fz => {
            const fp = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 6.2, 8), poleMat);
            fp.position.set(fx, 3.1, fz);
            const fb = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.12, 0.4), lampMat);
            fb.position.set(fx, 6.1, fz - Math.sign(fz) * 0.6);
            refs.dragWorldGroup.add(fp, fb);
        });
        [-22, 22].forEach(bz => {
            const bh = 20 + Math.abs((fx * 7) % 38);
            const bldg = new THREE.Mesh(new THREE.BoxGeometry(16, bh, 14), bldgMat1);
            bldg.position.set(fx, bh / 2, bz);
            refs.dragWorldGroup.add(bldg);
            const band = new THREE.Mesh(new THREE.BoxGeometry(16.2, 0.8, 14.2), winCyan);
            band.position.set(fx, bh * 0.65, bz);
            refs.dragWorldGroup.add(band);
        });
    }

    refs.scene.add(refs.dragWorldGroup);

    // Open World City
    refs.openWorldGroup = new THREE.Group();
    refs.openWorldGroup.visible = false;

    refs.owGroundMesh = new THREE.Mesh(
        new THREE.PlaneGeometry(520, 520),
        new THREE.MeshStandardMaterial({ color: 0x161a22, roughness: 0.78, metalness: 0.12 })
    );
    refs.owGroundMesh.rotation.x = -Math.PI / 2;
    refs.owGroundMesh.receiveShadow = true;
    refs.openWorldGroup.add(refs.owGroundMesh);

    refs.owChunkAssets = {
        roadMat: new THREE.MeshStandardMaterial({ color: 0x1b1f27, roughness: 0.72, metalness: 0.1 }),
        sidewalkMat: new THREE.MeshStandardMaterial({ color: 0x2a303c, roughness: 0.85 }),
        grassMat: new THREE.MeshStandardMaterial({ color: 0x166534, roughness: 0.92 }),
        trunkMat: new THREE.MeshStandardMaterial({ color: 0x5c4033, roughness: 0.9 }),
        leafMat: new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.85 }),
        marketSignMat: new THREE.MeshStandardMaterial({ color: 0x10b981, emissive: 0x059669, emissiveIntensity: 1.5 }),
        aptMat: new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.7 }),
        bldgMat1, bldgMat2, winCyan, winWarm, whiteMat, lampMat
    };
    updateInfiniteWorld(true);

    const trafficColors = [0xdc2626, 0x2563eb, 0xe2e8f0, 0x059669, 0xd97706, 0x4f46e5, 0x18181b, 0x0ea5e9, 0xf8fafc, 0xbe123c];
    const trafficStyles = ['sedan', 'coupe', 'suv', 'hatch'];
    const trafficTrimMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.72, metalness: 0.25 });
    const trafficGlassMat = new THREE.MeshPhysicalMaterial({ color: 0x0b1322, roughness: 0.08, metalness: 0.25, clearcoat: 1.0, clearcoatRoughness: 0.06 });
    const trafficTireMat = new THREE.MeshStandardMaterial({ color: 0x141619, roughness: 0.88, metalness: 0.08 });
    const trafficRimMat = new THREE.MeshStandardMaterial({ color: 0xcbd5e1, roughness: 0.24, metalness: 0.88 });
    const trafficHeadlightMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, emissive: 0xe0f2fe, emissiveIntensity: 2.4, roughness: 0.15 });
    const trafficTaillightMat = new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0xdc2626, emissiveIntensity: 2.1, roughness: 0.2 });
    const trafficPlateMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.5 });

    const tWheelTireGeo = new THREE.CylinderGeometry(0.34, 0.34, 0.24, 18);
    tWheelTireGeo.rotateX(Math.PI / 2);
    const tWheelRimGeo = new THREE.CylinderGeometry(0.22, 0.22, 0.25, 14);
    tWheelRimGeo.rotateX(Math.PI / 2);
    const tWheelHubGeo = new THREE.CylinderGeometry(0.07, 0.07, 0.26, 10);
    tWheelHubGeo.rotateX(Math.PI / 2);
    const tSpokeGeo = new THREE.BoxGeometry(0.38, 0.045, 0.255);

    function buildTrafficProfileGeo(style) {
        const shape = new THREE.Shape();
        if (style === 'suv') {
            shape.moveTo(-2.15, 0.34);
            shape.lineTo(2.15, 0.34);
            shape.lineTo(2.22, 0.58);
            shape.lineTo(2.12, 0.92);
            shape.lineTo(1.22, 1.02);
            shape.lineTo(0.65, 1.62);
            shape.lineTo(-1.72, 1.62);
            shape.lineTo(-2.08, 1.05);
            shape.lineTo(-2.18, 0.62);
        } else if (style === 'coupe') {
            shape.moveTo(-2.18, 0.28);
            shape.lineTo(2.22, 0.28);
            shape.lineTo(2.28, 0.48);
            shape.lineTo(2.05, 0.76);
            shape.lineTo(0.85, 0.86);
            shape.lineTo(0.05, 1.32);
            shape.lineTo(-1.15, 1.32);
            shape.lineTo(-1.98, 0.88);
            shape.lineTo(-2.20, 0.52);
        } else if (style === 'hatch') {
            shape.moveTo(-1.95, 0.30);
            shape.lineTo(1.98, 0.30);
            shape.lineTo(2.05, 0.52);
            shape.lineTo(1.88, 0.82);
            shape.lineTo(0.95, 0.92);
            shape.lineTo(0.32, 1.44);
            shape.lineTo(-1.35, 1.44);
            shape.lineTo(-1.85, 0.95);
            shape.lineTo(-1.98, 0.54);
        } else {
            // Sedan
            shape.moveTo(-2.18, 0.30);
            shape.lineTo(2.18, 0.30);
            shape.lineTo(2.25, 0.52);
            shape.lineTo(2.08, 0.82);
            shape.lineTo(1.02, 0.92);
            shape.lineTo(0.35, 1.42);
            shape.lineTo(-1.05, 1.42);
            shape.lineTo(-1.75, 0.95);
            shape.lineTo(-2.14, 0.88);
            shape.lineTo(-2.22, 0.52);
        }
        shape.closePath();
        const geo = new THREE.ExtrudeGeometry(shape, {
            depth: 1.66,
            bevelEnabled: true,
            bevelThickness: 0.08,
            bevelSize: 0.07,
            bevelSegments: 2
        });
        geo.translate(0, 0, -0.83);
        return geo;
    }

    const trafficProfileGeos = {
        sedan: buildTrafficProfileGeo('sedan'),
        coupe: buildTrafficProfileGeo('coupe'),
        suv: buildTrafficProfileGeo('suv'),
        hatch: buildTrafficProfileGeo('hatch')
    };

    function createTrafficVehicle(colorHex, style) {
        const g = new THREE.Group();
        const paint = new THREE.MeshPhysicalMaterial({
            color: colorHex,
            roughness: 0.24,
            metalness: 0.58,
            clearcoat: 0.9,
            clearcoatRoughness: 0.12
        });

        // Sculpted main body
        const bodyMesh = new THREE.Mesh(trafficProfileGeos[style], paint);
        bodyMesh.castShadow = true;
        bodyMesh.receiveShadow = true;
        g.add(bodyMesh);

        const isSuv = style === 'suv';
        const isCoupe = style === 'coupe';
        const isHatch = style === 'hatch';
        const frontX = isHatch ? 2.02 : 2.22;
        const rearX = isHatch ? -1.96 : -2.18;

        // Lower chassis / side skirts & bumpers
        const underbody = new THREE.Mesh(new THREE.BoxGeometry(isHatch ? 3.9 : 4.3, 0.18, 1.72), trafficTrimMat);
        underbody.position.set(0, 0.31, 0);
        g.add(underbody);

        // Front grille & splitter
        const grille = new THREE.Mesh(new THREE.BoxGeometry(0.12, isSuv ? 0.34 : 0.24, 1.05), trafficTrimMat);
        grille.position.set(frontX + 0.02, isSuv ? 0.64 : 0.54, 0);
        g.add(grille);

        // Rear diffuser & dual exhaust tips
        const diffuser = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.18, 1.38), trafficTrimMat);
        diffuser.position.set(rearX - 0.02, 0.38, 0);
        g.add(diffuser);
        [-0.48, 0.48].forEach(ez => {
            const tip = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.14, 10), trafficRimMat);
            tip.rotation.z = Math.PI / 2;
            tip.position.set(rearX - 0.06, 0.35, ez);
            g.add(tip);
        });

        // Tinted greenhouse (windshield, side windows, rear glass)
        const glassW = isSuv ? 2.15 : isHatch ? 1.55 : isCoupe ? 1.52 : 1.72;
        const glassX = isSuv ? -0.45 : isHatch ? -0.42 : isCoupe ? -0.46 : -0.35;
        const glassY = isSuv ? 1.30 : isCoupe ? 1.08 : 1.16;
        const glassH = isSuv ? 0.46 : isCoupe ? 0.34 : 0.38;
        const sideGlass = new THREE.Mesh(new THREE.BoxGeometry(glassW, glassH, 1.72), trafficGlassMat);
        sideGlass.position.set(glassX, glassY, 0);
        g.add(sideGlass);

        // Raked front windshield & rear glass
        const ws = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.06, 1.52), trafficGlassMat);
        ws.position.set(isSuv ? 0.90 : isHatch ? 0.62 : isCoupe ? 0.46 : 0.68, isSuv ? 1.32 : isCoupe ? 1.10 : 1.18, 0);
        ws.rotation.z = isSuv ? -0.68 : isCoupe ? -0.52 : -0.60;
        g.add(ws);

        const rg = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.06, 1.48), trafficGlassMat);
        rg.position.set(isSuv ? -1.84 : isHatch ? -1.56 : isCoupe ? -1.52 : -1.38, isSuv ? 1.32 : isCoupe ? 1.10 : 1.18, 0);
        rg.rotation.z = isSuv ? 0.92 : isCoupe ? 0.46 : 0.56;
        g.add(rg);

        // Side mirrors
        const mirrorX = isSuv ? 0.72 : isHatch ? 0.48 : 0.54;
        const mirrorY = isSuv ? 1.08 : 0.94;
        [-0.94, 0.94].forEach(mz => {
            const mir = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.11, 0.18), paint);
            mir.position.set(mirrorX, mirrorY, mz);
            g.add(mir);
        });

        // LED Headlights & Taillights
        [-0.64, 0.64].forEach(lz => {
            const hl = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.32), trafficHeadlightMat);
            hl.position.set(frontX + 0.01, isSuv ? 0.74 : 0.62, lz);
            g.add(hl);

            const tl = new THREE.Mesh(new THREE.BoxGeometry(0.10, 0.11, 0.34), trafficTaillightMat);
            tl.position.set(rearX - 0.01, isSuv ? 0.82 : 0.70, lz);
            g.add(tl);
        });

        // Rear lightbar accent + license plate
        const lightbar = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.04, 1.35), trafficTaillightMat);
        lightbar.position.set(rearX - 0.01, isSuv ? 0.82 : 0.70, 0);
        g.add(lightbar);

        const plate = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.14, 0.38), trafficPlateMat);
        plate.position.set(rearX - 0.04, 0.54, 0);
        g.add(plate);

        // 4 Detailed Rotating Wheels
        const wheels = [];
        const wx = isHatch ? 1.24 : 1.38;
        const wy = isSuv ? 0.37 : 0.34;
        const wz = 0.86;
        [[wx, wy, wz], [wx, wy, -wz], [-wx, wy, wz], [-wx, wy, -wz]].forEach(([x, y, z]) => {
            const wg = new THREE.Group();
            wg.position.set(x, y, z);
            const tire = new THREE.Mesh(tWheelTireGeo, trafficTireMat);
            const rim = new THREE.Mesh(tWheelRimGeo, trafficRimMat);
            const hub = new THREE.Mesh(tWheelHubGeo, trafficTrimMat);
            const sp1 = new THREE.Mesh(tSpokeGeo, trafficRimMat);
            const sp2 = new THREE.Mesh(tSpokeGeo, trafficRimMat);
            sp2.rotation.z = Math.PI / 2;
            const sp3 = new THREE.Mesh(tSpokeGeo, trafficRimMat);
            sp3.rotation.z = Math.PI / 4;
            wg.add(tire, rim, hub, sp1, sp2, sp3);
            g.add(wg);
            wheels.push(wg);
        });

        return { group: g, wheels };
    }

    const trafficRoutes = [
        { axis: 'x', lane: 3.5, z: -52, dir: 1, x: -120 },
        { axis: 'x', lane: -3.5, z: -52, dir: -1, x: 65 },
        { axis: 'x', lane: -3.5, z: 0, dir: -1, x: 90 },
        { axis: 'x', lane: 3.5, z: 0, dir: 1, x: -85 },
        { axis: 'x', lane: 3.5, z: 52, dir: 1, x: -60 },
        { axis: 'x', lane: -3.5, z: 52, dir: -1, x: 110 },
        { axis: 'z', lane: 3.5, x: -52, dir: 1, z: -100 },
        { axis: 'z', lane: -3.5, x: -52, dir: -1, z: 75 },
        { axis: 'z', lane: -3.5, x: 52, dir: -1, z: 80 },
        { axis: 'z', lane: 3.5, x: 52, dir: 1, z: -95 },
        { axis: 'z', lane: 3.5, x: 0, dir: 1, z: -140 },
        { axis: 'z', lane: -3.5, x: 0, dir: -1, z: 45 }
    ];
    trafficRoutes.forEach((r, idx) => {
        const colorHex = trafficColors[idx % trafficColors.length];
        const style = trafficStyles[idx % trafficStyles.length];
        const built = createTrafficVehicle(colorHex, style);
        const tGroup = built.group;

        const px = r.axis === 'x' ? r.x : r.x + r.lane;
        const pz = r.axis === 'z' ? r.z : r.z + r.lane;
        tGroup.position.set(px, 0, pz);
        tGroup.rotation.y = r.axis === 'x' ? (r.dir > 0 ? 0 : Math.PI) : (r.dir > 0 ? -Math.PI / 2 : Math.PI / 2);
        refs.openWorldGroup.add(tGroup);
        refs.trafficCars.push({
            mesh: tGroup,
            wheels: built.wheels,
            axis: r.axis,
            dir: r.dir,
            speed: 0.16 + (idx % 4) * 0.035,
            hitVx: 0, hitVz: 0, hitSpin: 0, stun: 0
        });
    });

    const pedColors = [0xf43f5e, 0x38bdf8, 0xfacc15, 0xa855f7, 0x22c55e, 0xf97316];
    for (let p = 0; p < 16; p++) {
        const pg = new THREE.Group();
        const shirt = new THREE.MeshStandardMaterial({ color: pedColors[p % pedColors.length], roughness: 0.7 });
        const skin = new THREE.MeshStandardMaterial({ color: 0xf1c27d, roughness: 0.8 });
        const legs = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.75, 0.24), bldgMat1);
        legs.position.y = 0.375;
        const torso = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.62, 0.26), shirt);
        torso.position.y = 1.05;
        const head = new THREE.Mesh(new THREE.SphereGeometry(0.16, 10, 10), skin);
        head.position.y = 1.52;
        pg.add(legs, torso, head);

        const sx = (p % 4 - 1.5) * 52 + 16;
        const sz = (Math.floor(p / 4) - 1.5) * 52 + 16;
        pg.position.set(sx, 0.08, sz);
        refs.openWorldGroup.add(pg);
        refs.pedestrians.push({
            mesh: pg, homeX: sx, homeZ: sz,
            walkAxis: p % 2 === 0 ? 'x' : 'z',
            walkDir: 1, walkPhase: p * 0.7,
            vx: 0, vy: 0, vz: 0, spinX: 0, spinZ: 0, impacted: false, recoverTimer: 0
        });
    }

    refs.scene.add(refs.openWorldGroup);
}

export function createMaterials() {
    refs.wrapTex = new THREE.TextureLoader().load(SERPHENIX_WRAP_URL);
    refs.wrapTex.colorSpace = THREE.SRGBColorSpace;
    refs.wrapTex.anisotropy = 8;
    refs.wrapTex.needsUpdate = true;

    refs.paintMat = new THREE.MeshPhysicalMaterial({
        color: 0xffffff,
        map: refs.wrapTex,
        roughness: 0.20,
        metalness: 0.42,
        clearcoat: 1.0,
        clearcoatRoughness: 0.08
    });

    refs.carbonMat = new THREE.MeshStandardMaterial({
        color: 0x15181e,
        roughness: 0.36,
        metalness: 0.45
    });

    refs.darkTrimMat = new THREE.MeshStandardMaterial({
        color: 0x111317,
        roughness: 0.65,
        metalness: 0.2
    });

    refs.chromeMat = new THREE.MeshStandardMaterial({
        color: 0xe2e8f0,
        roughness: 0.14,
        metalness: 0.95
    });

    refs.alloyMat = new THREE.MeshStandardMaterial({
        color: 0x2b303a,
        roughness: 0.24,
        metalness: 0.88
    });

    refs.glassMat = new THREE.MeshPhysicalMaterial({
        color: 0x0b121c,
        roughness: 0.05,
        metalness: 0.1,
        transparent: true,
        opacity: 0.68,
        clearcoat: 1.0
    });

    refs.tireMat = new THREE.MeshStandardMaterial({
        color: 0x121316,
        roughness: 0.88,
        metalness: 0.05
    });

    refs.stripeMat = new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        emissive: 0x0284c7,
        emissiveIntensity: 0.45,
        roughness: 0.25
    });
    refs.caliperMat = new THREE.MeshStandardMaterial({
        color: 0xdc2626,
        roughness: 0.22,
        metalness: 0.35
    });

    refs.goldFoilMat = new THREE.MeshStandardMaterial({
        color: 0xd97706,
        roughness: 0.25,
        metalness: 0.92
    });

    refs.alcantaraMat = new THREE.MeshStandardMaterial({
        color: 0x1c1f26,
        roughness: 0.92,
        metalness: 0.02
    });

    refs.screenMat = new THREE.MeshStandardMaterial({
        color: 0x091524,
        emissive: 0x00e5ff,
        emissiveIntensity: 0.9,
        roughness: 0.15
    });

    refs.drlMat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        emissive: 0xf8fafc,
        emissiveIntensity: 2.6
    });

    refs.tailLedMat = new THREE.MeshStandardMaterial({
        color: 0xff1122,
        emissive: 0xff0019,
        emissiveIntensity: 2.4
    });

    refs.exhaustGlowMat = new THREE.MeshStandardMaterial({
        color: 0x9ca3af,
        emissive: 0x38bdf8,
        emissiveIntensity: 0.6,
        metalness: 0.9,
        roughness: 0.2
    });

    refs.engineLedMat = new THREE.MeshStandardMaterial({
        color: 0xfacc15,
        emissive: 0xfacc15,
        emissiveIntensity: 2.2
    });

    refs.smokeGeo = new THREE.SphereGeometry(0.14, 8, 8);
    refs.smokeMat = new THREE.MeshBasicMaterial({
        color: 0xd1d5db,
        transparent: true,
        opacity: 0.42
    });
    refs.sparkGeo = new THREE.BoxGeometry(0.08, 0.08, 0.08);
    refs.sparkMat = new THREE.MeshBasicMaterial({
        color: 0xfacc15,
        transparent: true,
        opacity: 0.95
    });
    refs.skidGeo = new THREE.PlaneGeometry(0.24, 0.55);
    refs.skidGeo.rotateX(-Math.PI / 2);
    refs.skidMat = new THREE.MeshBasicMaterial({
        color: 0x050608,
        transparent: true,
        opacity: 0.65,
        depthWrite: false
    });
}
