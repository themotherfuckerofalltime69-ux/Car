import { WEB_SFX_URLS } from '../config/constants.js';
import { state, refs, dom } from '../state/context.js';

export function makeDistortionCurve(amount = 18) {
    const n = 256;
    const curve = new Float32Array(n);
    for (let i = 0; i < n; i++) {
        const x = (i * 2) / n - 1;
        curve[i] = Math.tanh(x * (1 + amount * 0.12));
    }
    return curve;
}

export function initAudioEngine() {
    if (refs.audioCtx) return;
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;

    refs.audioCtx = new AudioCtx();
    refs.audioDest = refs.audioCtx.createMediaStreamDestination();

    refs.oscSub = refs.audioCtx.createOscillator();
    refs.osc1 = refs.audioCtx.createOscillator();
    refs.osc2 = refs.audioCtx.createOscillator();
    refs.oscHarm = refs.audioCtx.createOscillator();
    refs.oscSub.type = 'triangle';
    refs.osc1.type = 'sawtooth';
    refs.osc2.type = 'sawtooth';
    refs.oscHarm.type = 'triangle';

    const shaper = refs.audioCtx.createWaveShaper();
    shaper.curve = makeDistortionCurve(14);
    shaper.oversample = '2x';

    refs.engineFilter = refs.audioCtx.createBiquadFilter();
    refs.engineFilter.type = 'lowpass';
    refs.engineFilter.frequency.value = 420;
    refs.engineFilter.Q.value = 2.8;

    refs.gainNode = refs.audioCtx.createGain();
    refs.gainNode.gain.value = 0;

    refs.oscSub.connect(shaper);
    refs.osc1.connect(shaper);
    refs.osc2.connect(shaper);
    refs.oscHarm.connect(shaper);
    shaper.connect(refs.engineFilter);
    refs.engineFilter.connect(refs.gainNode);
    refs.gainNode.connect(refs.audioCtx.destination);
    refs.gainNode.connect(refs.audioDest);

    refs.oscSub.start();
    refs.osc1.start();
    refs.osc2.start();
    refs.oscHarm.start();

    const bufLen = refs.audioCtx.sampleRate * 2;
    refs.noiseBufferGlobal = refs.audioCtx.createBuffer(1, bufLen, refs.audioCtx.sampleRate);
    const data = refs.noiseBufferGlobal.getChannelData(0);
    for (let i = 0; i < bufLen; i++) data[i] = Math.random() * 2 - 1;

    const noiseSrc = refs.audioCtx.createBufferSource();
    noiseSrc.buffer = refs.noiseBufferGlobal;
    noiseSrc.loop = true;
    const bp1 = refs.audioCtx.createBiquadFilter();
    bp1.type = 'bandpass';
    bp1.frequency.value = 920;
    bp1.Q.value = 8.5;
    const bp2 = refs.audioCtx.createBiquadFilter();
    bp2.type = 'bandpass';
    bp2.frequency.value = 1850;
    bp2.Q.value = 9.0;
    refs.screechGain = refs.audioCtx.createGain();
    refs.screechGain.gain.value = 0;
    noiseSrc.connect(bp1);
    noiseSrc.connect(bp2);
    bp1.connect(refs.screechGain);
    bp2.connect(refs.screechGain);
    refs.screechGain.connect(refs.audioCtx.destination);
    refs.screechGain.connect(refs.audioDest);
    noiseSrc.start();

    const nosSrc = refs.audioCtx.createBufferSource();
    nosSrc.buffer = refs.noiseBufferGlobal;
    nosSrc.loop = true;
    const nosHp = refs.audioCtx.createBiquadFilter();
    nosHp.type = 'bandpass';
    nosHp.frequency.value = 2200;
    nosHp.Q.value = 1.2;
    refs.nosGain = refs.audioCtx.createGain();
    refs.nosGain.gain.value = 0;
    nosSrc.connect(nosHp);
    nosHp.connect(refs.nosGain);
    refs.nosGain.connect(refs.audioCtx.destination);
    refs.nosGain.connect(refs.audioDest);
    nosSrc.start();

    Object.entries(WEB_SFX_URLS).forEach(async ([key, url]) => {
        try {
            const res = await fetch(url, { mode: 'cors' });
            if (!res.ok) return;
            const arr = await res.arrayBuffer();
            refs.sfxBuffers[key] = await refs.audioCtx.decodeAudioData(arr);
        } catch {
            // Ignore optional remote SFX fetch errors
        }
    });
}

export function playWebSfx(key, vol = 0.25) {
    if (!state.soundEnabled || !refs.audioCtx || !refs.sfxBuffers[key]) return;
    try {
        const src = refs.audioCtx.createBufferSource();
        src.buffer = refs.sfxBuffers[key];
        const g = refs.audioCtx.createGain();
        g.gain.value = vol;
        src.connect(g);
        g.connect(refs.audioCtx.destination);
        if (refs.audioDest) g.connect(refs.audioDest);
        src.start();
    } catch {
        // Ignore playback failure
    }
}

export function playImpactThud() {
    if (!state.soundEnabled || !refs.audioCtx) return;
    try {
        const o = refs.audioCtx.createOscillator();
        const g = refs.audioCtx.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(125, refs.audioCtx.currentTime);
        o.frequency.exponentialRampToValueAtTime(32, refs.audioCtx.currentTime + 0.22);
        g.gain.setValueAtTime(0.28, refs.audioCtx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.001, refs.audioCtx.currentTime + 0.24);
        o.connect(g);
        g.connect(refs.audioCtx.destination);
        if (refs.audioDest) g.connect(refs.audioDest);
        o.start();
        o.stop(refs.audioCtx.currentTime + 0.25);
    } catch {
        // Ignore playback failure
    }
}

export function playExhaustPop(count = 2) {
    if (!state.soundEnabled || !refs.audioCtx || !refs.noiseBufferGlobal) return;
    for (let i = 0; i < count; i++) {
        const t = refs.audioCtx.currentTime + i * (0.055 + Math.random() * 0.045);
        const src = refs.audioCtx.createBufferSource();
        src.buffer = refs.noiseBufferGlobal;
        const lp = refs.audioCtx.createBiquadFilter();
        lp.type = 'bandpass';
        lp.frequency.value = 320 + Math.random() * 240;
        lp.Q.value = 1.8;
        const g = refs.audioCtx.createGain();
        g.gain.setValueAtTime(0.22, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.065);
        src.connect(lp);
        lp.connect(g);
        g.connect(refs.audioCtx.destination);
        if (refs.audioDest) g.connect(refs.audioDest);
        src.start(t);
        src.stop(t + 0.07);
    }
}

export function playGearClunk() {
    if (!state.soundEnabled || !refs.audioCtx) return;
    playWebSfx('shift', 0.28);
    playExhaustPop(1);
    try {
        const o = refs.audioCtx.createOscillator();
        const g = refs.audioCtx.createGain();
        o.type = 'triangle';
        o.frequency.setValueAtTime(190, refs.audioCtx.currentTime);
        o.frequency.exponentialRampToValueAtTime(65, refs.audioCtx.currentTime + 0.07);
        g.gain.setValueAtTime(0.18, refs.audioCtx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.001, refs.audioCtx.currentTime + 0.08);
        o.connect(g);
        g.connect(refs.audioCtx.destination);
        if (refs.audioDest) g.connect(refs.audioDest);
        o.start();
        o.stop(refs.audioCtx.currentTime + 0.09);
    } catch {
        // Ignore playback failure
    }
}

export function playCountdownBeep(isGo) {
    if (!state.soundEnabled || !refs.audioCtx) return;
    try {
        const o = refs.audioCtx.createOscillator();
        const g = refs.audioCtx.createGain();
        o.type = 'sine';
        o.frequency.value = isGo ? 880 : 440;
        g.gain.setValueAtTime(0.15, refs.audioCtx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.001, refs.audioCtx.currentTime + (isGo ? 0.32 : 0.14));
        o.connect(g);
        g.connect(refs.audioCtx.destination);
        if (refs.audioDest) g.connect(refs.audioDest);
        o.start();
        o.stop(refs.audioCtx.currentTime + 0.35);
    } catch {
        // Ignore playback failure
    }
}

export function toggleV12Sound() {
    if (!state.soundEnabled) {
        try {
            initAudioEngine();
            if (!refs.audioCtx) return;
            if (refs.audioCtx.state === 'suspended') refs.audioCtx.resume();
            refs.gainNode.gain.value = 0.055;
            state.soundEnabled = true;
            dom.btnSound.textContent = 'V12 Audio: On';
            dom.btnSound.classList.add('active');
        } catch {
            // Ignore audio initialization errors
        }
    } else {
        if (refs.gainNode) refs.gainNode.gain.value = 0;
        if (refs.screechGain) refs.screechGain.gain.value = 0;
        if (refs.nosGain) refs.nosGain.gain.value = 0;
        state.soundEnabled = false;
        dom.btnSound.textContent = 'V12 Audio: Off';
        dom.btnSound.classList.remove('active');
    }
}
