import { CHUNK_SIZE, FINISHES } from '../config/constants.js';
import { state, refs, dom } from '../state/context.js';
import { getWorldZone } from '../world/cityLod.js';
import { updateStatus } from '../ui/hudControls.js';
import { playImpactThud } from '../audio/soundEngine.js';

export function spawnSkidMark() {
    [-0.88, 0.88].forEach(rz => {
        const p = new THREE.Vector3(1.48, 0.032, rz).applyMatrix4(refs.carGroup.matrixWorld);
        const m = new THREE.Mesh(refs.skidGeo, refs.skidMat);
        m.position.set(p.x, 0.032, p.z);
        m.rotation.y = state.carHeading + Math.PI / 2;
        refs.scene.add(m);
        refs.skidMarks.push(m);
        if (refs.skidMarks.length > 320) {
            const old = refs.skidMarks.shift();
            refs.scene.remove(old);
        }
    });
}

export function drawPlayerArrow(ctx, x, y, heading, color = '#38bdf8') {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(-heading + Math.PI);
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(6, 0);
    ctx.lineTo(-4.5, -4);
    ctx.lineTo(-2.5, 0);
    ctx.lineTo(-4.5, 4);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
}

export function drawMinimap() {
    if (!refs.minimapCtx || !dom.minimapCanvas || refs.trackSamples.length === 0) return;
    const cvs = dom.minimapCanvas;
    const ctx = refs.minimapCtx;
    const targetW = state.minimapExpanded ? 248 : 120;
    const targetH = state.minimapExpanded ? 204 : 100;
    if (cvs.width !== targetW || cvs.height !== targetH) {
        cvs.width = targetW;
        cvs.height = targetH;
    }
    ctx.clearRect(0, 0, cvs.width, cvs.height);

    if (state.trackMode === 'openworld') {
        const span = state.minimapExpanded ? 320 : 210;
        const scale = Math.min(cvs.width, cvs.height) / span;
        const px = refs.carGroup.position.x;
        const pz = refs.carGroup.position.z;
        const toX = wx => cvs.width / 2 + (wx - px) * scale;
        const toY = wz => cvs.height / 2 + (wz - pz) * scale;

        // Render real-world chunks, terrain zones, and building footprints
        const zoneColors = {
            waterfront: 'rgba(14, 116, 144, 0.35)',
            highway: 'rgba(245, 158, 11, 0.14)',
            suburban: 'rgba(34, 197, 94, 0.12)',
            downtown: 'rgba(56, 189, 248, 0.12)'
        };
        for (const val of refs.owChunks.values()) {
            const m = val.meta;
            if (!m) continue;
            const x0 = toX(m.cx * CHUNK_SIZE + 8);
            const y0 = toY(m.cz * CHUNK_SIZE + 8);
            const blk = 36 * scale;
            ctx.fillStyle = m.kind === 'park'
                ? 'rgba(22, 163, 74, 0.35)'
                : (zoneColors[m.zone] || 'rgba(51, 65, 85, 0.3)');
            ctx.fillRect(x0, y0, blk, blk);

            // Exact 3D building / water / park footprints
            ctx.fillStyle = m.kind === 'waterfront'
                ? 'rgba(2, 132, 199, 0.65)'
                : m.kind === 'commercial'
                    ? 'rgba(16, 185, 129, 0.55)'
                    : 'rgba(148, 163, 184, 0.55)';
            for (let i = 0; i < m.buildings.length; i++) {
                const b = m.buildings[i];
                ctx.fillRect(
                    toX(b.x - b.w / 2),
                    toY(b.z - b.d / 2),
                    Math.max(2, b.w * scale),
                    Math.max(2, b.d * scale)
                );
            }
        }

        // Real-world avenue network lines
        ctx.strokeStyle = 'rgba(226, 232, 240, 0.25)';
        ctx.lineWidth = Math.max(2, 14 * scale);
        const baseX = Math.floor(px / CHUNK_SIZE) * CHUNK_SIZE;
        const baseZ = Math.floor(pz / CHUNK_SIZE) * CHUNK_SIZE;
        for (let off = -CHUNK_SIZE * 3; off <= CHUNK_SIZE * 3; off += CHUNK_SIZE) {
            const rx = toX(baseX + off);
            const rz = toY(baseZ + off);
            ctx.beginPath(); ctx.moveTo(rx, 0); ctx.lineTo(rx, cvs.height); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(0, rz); ctx.lineTo(cvs.width, rz); ctx.stroke();
        }

        // Live traffic cars
        if (state.trafficEnabled) {
            ctx.fillStyle = '#facc15';
            for (let i = 0; i < refs.trafficCars.length; i++) {
                const tp = refs.trafficCars[i].mesh.position;
                ctx.fillRect(toX(tp.x) - 1.5, toY(tp.z) - 1.5, 3, 3);
            }
        }

        drawPlayerArrow(ctx, cvs.width / 2, cvs.height / 2, state.carHeading, '#38bdf8');

        // Zone & Compass badge
        const curZone = getWorldZone(Math.floor(px / CHUNK_SIZE), Math.floor(pz / CHUNK_SIZE)).toUpperCase();
        ctx.fillStyle = 'rgba(248, 250, 252, 0.85)';
        ctx.font = 'bold 8px ui-monospace, monospace';
        ctx.fillText(curZone, 4, 10);
        ctx.fillText('N', cvs.width - 10, 10);
        return;
    }

    if (state.isDragMode) {
        ctx.strokeStyle = 'rgba(148, 163, 184, 0.65)';
        ctx.lineWidth = 8;
        ctx.beginPath();
        ctx.moveTo(cvs.width - 12, cvs.height / 2);
        ctx.lineTo(12, cvs.height / 2);
        ctx.stroke();
        const cx = cvs.width - 12 - ((-refs.carGroup.position.x) / 230) * (cvs.width - 24);
        ctx.fillStyle = '#facc15';
        ctx.beginPath();
        ctx.arc(Math.max(8, Math.min(cvs.width - 8, cx)), cvs.height / 2, 4, 0, Math.PI * 2);
        ctx.fill();
        return;
    }

    const mapX = wx => ((wx + 150) / 305) * (cvs.width - 14) + 7;
    const mapY = wz => ((wz + 135) / 170) * (cvs.height - 14) + 7;

    ctx.beginPath();
    for (let i = 0; i < refs.trackSamples.length; i++) {
        const px = mapX(refs.trackSamples[i].x);
        const py = mapY(refs.trackSamples[i].z);
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.55)';
    ctx.lineWidth = 4;
    ctx.stroke();

    ctx.fillStyle = '#facc15';
    ctx.beginPath();
    ctx.arc(mapX(refs.carGroup.position.x), mapY(refs.carGroup.position.z), 4, 0, Math.PI * 2);
    ctx.fill();
}

export function spawnImpactSparks(pos) {
    for (let i = 0; i < 10; i++) {
        if (refs.sparkParticles.length > 80) break;
        const sp = new THREE.Mesh(refs.sparkGeo, refs.sparkMat.clone());
        sp.position.set(pos.x, 0.35 + Math.random() * 0.3, pos.z);
        refs.scene.add(sp);
        refs.sparkParticles.push({
            mesh: sp,
            vx: (Math.random() - 0.5) * 0.28,
            vy: 0.08 + Math.random() * 0.14,
            vz: (Math.random() - 0.5) * 0.28,
            life: 1.0
        });
    }
}

export function spawnDriftSmoke() {
    if (refs.driftParticles.length > 90) return;
    [-0.86, 0.86].forEach(rz => {
        const localRear = new THREE.Vector3(1.48, 0.14, rz).applyMatrix4(refs.carGroup.matrixWorld);
        const p = new THREE.Mesh(refs.smokeGeo, refs.smokeMat.clone());
        p.position.copy(localRear);
        p.scale.setScalar(0.6 + Math.random() * 0.6);
        refs.scene.add(p);
        refs.driftParticles.push({ mesh: p, life: 1.0, vy: 0.015 + Math.random() * 0.015 });
    });
}

export function resolveBoxList(boxList, radius) {
    let maxHit = 0;
    const fwdX = -Math.cos(state.carHeading);
    const fwdZ = Math.sin(state.carHeading);
    const offsets = [1.35, 0, -1.35];

    for (let o = 0; o < offsets.length; o++) {
        const px = refs.carGroup.position.x + fwdX * offsets[o];
        const pz = refs.carGroup.position.z + fwdZ * offsets[o];

        for (let i = 0; i < boxList.length; i++) {
            const b = boxList[i];
            const cx = Math.max(b.minX, Math.min(px, b.maxX));
            const cz = Math.max(b.minZ, Math.min(pz, b.maxZ));
            const dx = px - cx;
            const dz = pz - cz;
            const dSq = dx * dx + dz * dz;

            if (dSq < radius * radius) {
                let nx = 0, nz = 0, pen = 0;
                if (dSq > 1e-6) {
                    const d = Math.sqrt(dSq);
                    nx = dx / d;
                    nz = dz / d;
                    pen = radius - d;
                } else {
                    const dL = Math.abs(px - b.minX), dR = Math.abs(b.maxX - px);
                    const dT = Math.abs(pz - b.minZ), dB = Math.abs(b.maxZ - pz);
                    const m = Math.min(dL, dR, dT, dB);
                    if (m === dL) { nx = -1; pen = dL + radius; }
                    else if (m === dR) { nx = 1; pen = dR + radius; }
                    else if (m === dT) { nz = -1; pen = dT + radius; }
                    else { nz = 1; pen = dB + radius; }
                }

                refs.carGroup.position.x += nx * pen;
                refs.carGroup.position.z += nz * pen;

                const vx = -Math.cos(state.velocityHeading) * state.carSpeed;
                const vz = Math.sin(state.velocityHeading) * state.carSpeed;
                const vDotN = vx * nx + vz * nz;
                if (vDotN < 0) {
                    maxHit = Math.max(maxHit, -vDotN);
                    const rvx = vx - 1.25 * vDotN * nx;
                    const rvz = vz - 1.25 * vDotN * nz;
                    const newSpd = Math.hypot(rvx, rvz) * 0.72;
                    state.carSpeed = state.carSpeed >= 0 ? newSpd : -newSpd;
                    if (newSpd > 0.02) {
                        state.velocityHeading = Math.atan2(rvz, -rvx);
                    }
                }
            }
        }
    }
    return maxHit;
}

export function resolveCollisions() {
    const CAR_R = 1.05;
    const BARRIER_LIMIT = 9.05;
    let hitIntensity = 0;

    if (state.isDragMode) {
        const Z_LIM = 6.55;
        if (Math.abs(refs.carGroup.position.z) > Z_LIM) {
            refs.carGroup.position.z = Math.sign(refs.carGroup.position.z) * Z_LIM;
            hitIntensity = Math.max(hitIntensity, Math.abs(state.carSpeed) * 0.5);
            state.carSpeed *= 0.82;
            state.velocityHeading = 0;
            state.carHeading = THREE.MathUtils.lerp(state.carHeading, 0, 0.5);
        }
        if (refs.carGroup.position.x > 12) {
            refs.carGroup.position.x = 12;
            state.carSpeed = 0;
        } else if (refs.carGroup.position.x < -270) {
            refs.carGroup.position.x = -270;
            hitIntensity = Math.max(hitIntensity, Math.abs(state.carSpeed));
            state.carSpeed = 0;
        }
    } else if (state.trackMode === 'openworld') {
        hitIntensity = Math.max(hitIntensity, resolveBoxList(refs.openWorldColliders, CAR_R));

        if (state.trafficEnabled) {
            const carVx = -Math.cos(state.velocityHeading) * state.carSpeed;
            const carVz = Math.sin(state.velocityHeading) * state.carSpeed;

            for (let i = 0; i < refs.trafficCars.length; i++) {
                const tc = refs.trafficCars[i];
                const dx = refs.carGroup.position.x - tc.mesh.position.x;
                const dz = refs.carGroup.position.z - tc.mesh.position.z;
                const d = Math.hypot(dx, dz);
                if (d < 2.4 && d > 1e-4) {
                    const nx = dx / d, nz = dz / d;
                    refs.carGroup.position.x += nx * (2.4 - d) * 0.5;
                    refs.carGroup.position.z += nz * (2.4 - d) * 0.5;
                    tc.hitVx = -nx * Math.max(0.25, Math.abs(state.carSpeed) * 1.1) + carVx * 0.6;
                    tc.hitVz = -nz * Math.max(0.25, Math.abs(state.carSpeed) * 1.1) + carVz * 0.6;
                    tc.hitSpin = (Math.random() - 0.5) * 0.25;
                    tc.stun = 90;
                    hitIntensity = Math.max(hitIntensity, Math.abs(state.carSpeed));
                    state.carSpeed *= 0.55;
                }
            }

            for (let i = 0; i < refs.pedestrians.length; i++) {
                const pd = refs.pedestrians[i];
                const dx = pd.mesh.position.x - refs.carGroup.position.x;
                const dz = pd.mesh.position.z - refs.carGroup.position.z;
                const d = Math.hypot(dx, dz);
                if (d < 1.55 && Math.abs(state.carSpeed) > 0.05 && !pd.impacted) {
                    const nx = dx / Math.max(0.1, d), nz = dz / Math.max(0.1, d);
                    pd.impacted = true;
                    pd.recoverTimer = 180;
                    pd.vx = nx * (0.18 + Math.abs(state.carSpeed) * 0.9) + carVx * 0.5;
                    pd.vz = nz * (0.18 + Math.abs(state.carSpeed) * 0.9) + carVz * 0.5;
                    pd.vy = 0.22 + Math.abs(state.carSpeed) * 0.35;
                    pd.spinX = (Math.random() - 0.5) * 0.35;
                    pd.spinZ = (Math.random() - 0.5) * 0.35;
                    playImpactThud();
                    updateStatus(FINISHES[state.finishIdx].status, 'PEDESTRIAN_IMPACT', 900);
                }
            }
        }
    } else if (refs.trackSamples.length > 0) {
        let bestDistSq = Infinity;
        let bestPt = null;
        for (let i = 0; i < refs.trackSamples.length; i++) {
            const tp = refs.trackSamples[i];
            const dx = refs.carGroup.position.x - tp.x;
            const dz = refs.carGroup.position.z - tp.z;
            const dSq = dx * dx + dz * dz;
            if (dSq < bestDistSq) {
                bestDistSq = dSq;
                bestPt = tp;
            }
        }
        const dist = Math.sqrt(bestDistSq);
        if (dist > BARRIER_LIMIT && bestPt) {
            const nx = (refs.carGroup.position.x - bestPt.x) / dist;
            const nz = (refs.carGroup.position.z - bestPt.z) / dist;
            refs.carGroup.position.x = bestPt.x + nx * BARRIER_LIMIT;
            refs.carGroup.position.z = bestPt.z + nz * BARRIER_LIMIT;

            const vx = -Math.cos(state.velocityHeading) * state.carSpeed;
            const vz = Math.sin(state.velocityHeading) * state.carSpeed;
            const vDotN = vx * nx + vz * nz;
            if (vDotN > 0) {
                hitIntensity = Math.max(hitIntensity, vDotN);
                const rvx = vx - 1.35 * vDotN * nx;
                const rvz = vz - 1.35 * vDotN * nz;
                const newSpd = Math.hypot(rvx, rvz) * 0.78;
                state.carSpeed = state.carSpeed >= 0 ? newSpd : -newSpd;
                if (newSpd > 0.02) {
                    state.velocityHeading = Math.atan2(rvz, -rvx);
                    state.carHeading = THREE.MathUtils.lerp(state.carHeading, state.velocityHeading, 0.35);
                }
            }
        }
    }

    if (state.trackMode === 'circuit') {
        hitIntensity = Math.max(hitIntensity, resolveBoxList(refs.buildingColliders, CAR_R));
    }

    if (hitIntensity > 0.06 && state.collisionCooldown <= 0) {
        state.collisionCooldown = 14;
        state.chassisIntegrity = Math.max(15, Math.round(state.chassisIntegrity - hitIntensity * 14));
        dom.dmgPct.textContent = `${state.chassisIntegrity}%`;
        dom.dmgFill.style.width = `${state.chassisIntegrity}%`;
        dom.dmgFill.style.background = state.chassisIntegrity > 60 ? '#22c55e' : state.chassisIntegrity > 30 ? '#f59e0b' : '#ef4444';
        state.suspensionVelocity = Math.min(0.24, hitIntensity * 0.45);
        spawnImpactSparks(refs.carGroup.position);
        playImpactThud();
        updateStatus(FINISHES[state.finishIdx].status, 'BARRIER_IMPACT', 900);
    }
}
