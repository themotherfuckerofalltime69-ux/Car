import { MAX_REPLAY_FRAMES, GRAVITY, BOUNCE, FINISHES } from '../config/constants.js';
import { state, refs, dom } from '../state/context.js';
import { updateInfiniteWorld } from '../world/cityLod.js';
import {
    updateAIDriver, setTrackMode, setDriveMode, showFinishModal, stopReplay, updateStatus
} from '../ui/hudControls.js';
import {
    spawnSkidMark, drawMinimap, spawnDriftSmoke, resolveCollisions
} from './effects.js';
import { playExhaustPop, playGearClunk, playCountdownBeep } from '../audio/soundEngine.js';

let previousFrameTime = 0;

export function dampFactor(rate, frameScale) {
    return 1 - Math.pow(1 - rate, frameScale);
}

export function updateDriveTelemetry(kmh, gear, rpmPct, nosPct, steerDeg, gx, gy) {
    if (state.lastHudSpeed !== kmh) {
        state.lastHudSpeed = kmh;
        dom.hudSpeed.textContent = kmh;
    }
    const gearStr = `GEAR: ${gear}`;
    if (state.lastHudGear !== gearStr) {
        state.lastHudGear = gearStr;
        dom.hudGear.textContent = gearStr;
    }
    const rpmRounded = Math.round(rpmPct);
    if (state.lastRpmPct !== rpmRounded) {
        state.lastRpmPct = rpmRounded;
        dom.rpmFill.style.width = `${rpmRounded}%`;
    }
    const nosRounded = Math.round(nosPct);
    if (state.lastNosPct !== nosRounded) {
        state.lastNosPct = nosRounded;
        dom.nosFill.style.width = `${nosRounded}%`;
    }
    const steerFixed = steerDeg.toFixed(1);
    if (state.lastSteerDeg !== steerFixed) {
        state.lastSteerDeg = steerFixed;
        dom.steerWheelSvg.style.transform = `rotate(${steerFixed}deg)`;
    }
    const gfTransform = `translate(calc(-50% + ${gx.toFixed(1)}px), calc(-50% + ${gy.toFixed(1)}px))`;
    if (state.lastGForceTransform !== gfTransform) {
        state.lastGForceTransform = gfTransform;
        dom.gforceDot.style.transform = gfTransform;
    }
}

export function animate(now = performance.now()) {
    requestAnimationFrame(animate);

    if (refs.underglowGroup && refs.underglowGroup.userData.glowMaterial) {
        refs.underglowGroup.userData.glowMaterial.uniforms.uTime.value = now * 0.001;
    }

    const frameScale = previousFrameTime
        ? THREE.MathUtils.clamp((now - previousFrameTime) / 16.6667, 0.35, 2.5)
        : 1;
    previousFrameTime = now;

    // Gravity & Pushrod Suspension Bounce
    if (refs.carGroup.position.y > 0 || state.velocityY !== 0) {
        state.velocityY += GRAVITY * frameScale;
        refs.carGroup.position.y += state.velocityY * frameScale;
        if (refs.carGroup.position.y <= 0) {
            refs.carGroup.position.y = 0;
            if (Math.abs(state.velocityY) > 0.025) {
                state.velocityY = -state.velocityY * BOUNCE;
                state.suspensionVelocity = state.velocityY * 1.3;
            } else {
                state.velocityY = 0;
            }
        }
    }

    state.suspensionVelocity += (0 - state.suspensionOffset) * 0.18 * frameScale;
    state.suspensionVelocity *= Math.pow(0.85, frameScale);
    state.suspensionOffset += state.suspensionVelocity * frameScale;
    refs.carGroup.rotation.z = state.suspensionOffset * 0.08;
    refs.carGroup.position.y += Math.max(0, state.suspensionOffset * 0.05);

    if (state.driveMode) {
        if (state.aiDriverActive) updateAIDriver();

        if (!state.keys.nos && state.nosFuel >= 12) state.nosDepleted = false;
        if (state.nosFuel >= 18) state.nosDepleted = false;
        const nosActive = !state.raceLocked && !state.nosDepleted && state.keys.nos && state.nosFuel > 0.5 && (state.keys.gas || state.carSpeed > 0.1);
        if (nosActive) {
            state.nosFuel = Math.max(0, state.nosFuel - 0.38 * frameScale);
            if (state.nosFuel <= 0.5) state.nosDepleted = true;
        } else {
            state.nosFuel = Math.min(100, state.nosFuel + 0.25 * frameScale);
        }

        const maxFwd = (nosActive ? 1.12 : 0.68) * state.turboBoostMult * state.speedMultiplier;
        const maxRev = -0.22 * state.speedMultiplier;
        const accel = (nosActive ? 0.038 : 0.011) * state.speedMultiplier;

        refs.flameMeshes.forEach(fm => {
            fm.visible = nosActive;
            if (nosActive) fm.scale.set(1.4, 1.8 + Math.random() * 1.1, 1.4);
        });
        if (refs.nosLight) refs.nosLight.intensity = nosActive ? 7.5 + Math.random() * 3.0 : 0;

        const targetFov = nosActive ? 44 : 36;
        if (Math.abs(refs.camera.fov - targetFov) > 0.05) {
            const fovLerp = targetFov > refs.camera.fov ? 0.12 : 0.055;
            refs.camera.fov = THREE.MathUtils.lerp(refs.camera.fov, targetFov, dampFactor(fovLerp, frameScale));
            refs.camera.updateProjectionMatrix();
        }
        refs.tailLedMat.emissiveIntensity = (state.keys.brake || state.keys.handbrake) ? 5.5 : 2.4;

        const brakeForce = 0.022;
        const drag = state.keys.handbrake ? 0.965 : 0.986;
        let targetPitch = 0;

        if (state.raceLocked) {
            state.carSpeed = 0;
        } else if (state.keys.gas) {
            if (state.carSpeed > maxFwd) {
                state.carSpeed = Math.max(maxFwd, state.carSpeed - (state.carSpeed - maxFwd) * dampFactor(0.032, frameScale) - 0.0012 * frameScale);
            } else {
                state.carSpeed = Math.min(maxFwd, state.carSpeed + accel * frameScale);
            }
            targetPitch = -0.022;
        } else if (state.keys.brake) {
            if (state.carSpeed > 0.01) {
                state.carSpeed = Math.max(0, state.carSpeed - brakeForce * frameScale);
                targetPitch = 0.032;
            } else {
                state.carSpeed = Math.max(maxRev, state.carSpeed - accel * 0.65 * frameScale);
            }
        } else {
            state.carSpeed *= Math.pow(drag, frameScale);
            if (Math.abs(state.carSpeed) < 0.001) state.carSpeed = 0;
        }

        const maxSteer = 0.44 / (1 + Math.abs(state.carSpeed) * 1.2);
        let targetSteer = state.manualSteerInput * maxSteer;
        if (state.keys.left) targetSteer = maxSteer;
        if (state.keys.right) targetSteer = -maxSteer;
        state.steerAngle = THREE.MathUtils.lerp(state.steerAngle, targetSteer, dampFactor(0.16, frameScale));

        refs.frontSteerKnuckles.forEach(k => { k.rotation.y = state.steerAngle; });

        const driftingNow = state.keys.handbrake && Math.abs(state.carSpeed) > 0.10;
        const turnRate = state.steerAngle * state.carSpeed * (driftingNow ? 0.21 : 0.15);
        state.carHeading += turnRate * frameScale;

        const targetSlip = driftingNow ? THREE.MathUtils.clamp(state.steerAngle * 0.95, -0.44, 0.44) : 0;
        state.driftSlipAngle = THREE.MathUtils.lerp(state.driftSlipAngle, targetSlip, dampFactor(driftingNow ? 0.08 : 0.10, frameScale));
        state.velocityHeading = THREE.MathUtils.lerp(state.velocityHeading, state.carHeading - state.driftSlipAngle, dampFactor(driftingNow ? 0.10 : 0.22, frameScale));

        if (driftingNow && state.keys.gas) {
            state.carSpeed = Math.max(state.carSpeed, 0.28);
        }

        const moveX = -Math.cos(state.velocityHeading);
        const moveZ = Math.sin(state.velocityHeading);
        refs.carGroup.position.x += moveX * state.carSpeed * frameScale;
        refs.carGroup.position.z += moveZ * state.carSpeed * frameScale;

        if (state.collisionCooldown > 0) state.collisionCooldown -= frameScale;
        resolveCollisions();

        if (state.trackMode === 'openworld') {
            updateInfiniteWorld();
        } else {
            refs.carGroup.position.x = Math.max(-280, Math.min(280, refs.carGroup.position.x));
            refs.carGroup.position.z = Math.max(-280, Math.min(280, refs.carGroup.position.z));
        }

        const targetRoll = -state.steerAngle * state.carSpeed * 0.16;
        state.bodyPitch = THREE.MathUtils.lerp(state.bodyPitch, targetPitch, dampFactor(0.12, frameScale));
        state.bodyRoll = THREE.MathUtils.lerp(state.bodyRoll, targetRoll, dampFactor(0.12, frameScale));
        refs.carGroup.rotation.y = state.carHeading;
        refs.carGroup.rotation.z = state.suspensionOffset * 0.08 + state.bodyPitch;
        refs.carGroup.rotation.x = state.bodyRoll;

        const kmh = Math.round(Math.abs(state.carSpeed) / 0.68 * 350);
        if (kmh > state.topSpeedKmh) state.topSpeedKmh = kmh;
        const gear = state.carSpeed < -0.01 ? 'R' : kmh < 5 ? 'N' : Math.min(7, Math.floor(kmh / 50) + 1);
        const rpmPct = state.carSpeed < -0.01 ? 35 : kmh < 5 ? 12 : Math.min(98, 22 + ((kmh % 50) / 50) * 76);

        const uiSteerDeg = -(state.steerAngle / maxSteer) * 95;
        const gx = THREE.MathUtils.clamp(-state.steerAngle * state.carSpeed * 42, -14, 14);
        const gy = THREE.MathUtils.clamp((state.keys.brake ? 11 : state.keys.gas ? -10 : 0), -14, 14);
        updateDriveTelemetry(kmh, gear, rpmPct, state.nosFuel, uiSteerDeg, gx, gy);

        if (state.soundEnabled && refs.audioCtx && refs.osc1 && refs.osc2 && refs.oscSub && refs.oscHarm) {
            const baseFreq = 44 + rpmPct * 1.75 + (nosActive ? 24 : 0);
            const tNow = refs.audioCtx.currentTime;
            refs.oscSub.frequency.setTargetAtTime(baseFreq * 0.5, tNow, 0.03);
            refs.osc1.frequency.setTargetAtTime(baseFreq, tNow, 0.03);
            refs.osc2.frequency.setTargetAtTime(baseFreq * 1.5, tNow, 0.03);
            refs.oscHarm.frequency.setTargetAtTime(baseFreq * 3.0, tNow, 0.03);
            if (refs.engineFilter) {
                const cutoff = state.keys.gas ? 950 + rpmPct * 18 : 380 + rpmPct * 6;
                refs.engineFilter.frequency.setTargetAtTime(cutoff, tNow, 0.05);
            }
            if (refs.nosGain) {
                refs.nosGain.gain.setTargetAtTime(nosActive ? 0.075 : 0, tNow, 0.05);
            }
            if (state.wasGasPressed && !state.keys.gas && rpmPct > 52) {
                playExhaustPop(2);
            }
            state.wasGasPressed = state.keys.gas;
            if (gear !== state.lastGear && gear !== 'N' && state.lastGear !== 'N') {
                playGearClunk();
            }
            state.lastGear = gear;
        }

        if (kmh > 110 && state.targetWingLift === 0) {
            state.wingLift = THREE.MathUtils.lerp(state.wingLift, 0.14, dampFactor(0.08, frameScale));
        } else {
            state.wingLift = THREE.MathUtils.lerp(state.wingLift, state.targetWingLift, dampFactor(0.1, frameScale));
        }

        if (refs.steeringWheelMesh) {
            refs.steeringWheelMesh.rotation.x = -state.steerAngle * 2.4;
        }

        const isDrifting = (state.keys.handbrake && Math.abs(state.carSpeed) > 0.12) || (Math.abs(state.steerAngle) > 0.18 && Math.abs(state.carSpeed) > 0.25);
        if (refs.screechGain && state.soundEnabled && refs.audioCtx) {
            refs.screechGain.gain.setTargetAtTime(isDrifting ? 0.065 : 0, refs.audioCtx.currentTime, 0.05);
        }
        if (isDrifting) {
            spawnDriftSmoke();
            spawnSkidMark();
        }

        if (state.isDragMode) {
            if (!state.dragStarted && refs.carGroup.position.x < -2.5) {
                state.dragStarted = true;
                state.dragStartMs = performance.now();
            }
            if (state.dragStarted && !state.dragFinished) {
                const et = (performance.now() - state.dragStartMs) / 1000;
                const etStr = et.toFixed(2);
                if (state.lastHudLapTime !== etStr) {
                    state.lastHudLapTime = etStr;
                    dom.hudLapTime.textContent = etStr;
                }
                if (state.dragZero100 === null && kmh >= 100) {
                    state.dragZero100 = et;
                    dom.hudBestLap.textContent = `0-100: ${et.toFixed(2)}s`;
                }
                if (refs.carGroup.position.x <= -220) {
                    state.dragFinished = true;
                    dom.hudBestLap.textContent = `${et.toFixed(2)}s @${kmh}`;
                    updateStatus(FINISHES[state.finishIdx].status, `1/4_MILE: ${et.toFixed(2)}s`);
                    showFinishModal('1/4-MILE COMPLETE', `${et.toFixed(2)}s`);
                }
            }
        } else if (state.trackMode === 'openworld') {
            if (state.lapStartTime > 0) {
                const ltStr = ((performance.now() - state.lapStartTime) / 1000).toFixed(1);
                if (state.lastHudLapTime !== ltStr) {
                    state.lastHudLapTime = ltStr;
                    dom.hudLapTime.textContent = ltStr;
                }
            }
            const bestStr = `TOP:${state.topSpeedKmh}`;
            if (state.lastHudBestLap !== bestStr) {
                state.lastHudBestLap = bestStr;
                dom.hudBestLap.textContent = bestStr;
            }
        } else {
            const nearStartZ = Math.abs(refs.carGroup.position.z) < 12;
            if (refs.carGroup.position.x < -14 && nearStartZ && !state.wasPastStartLine && state.carSpeed > 0.05) {
                state.wasPastStartLine = true;
            } else if (refs.carGroup.position.x > 10 && nearStartZ && state.wasPastStartLine) {
                state.wasPastStartLine = false;
            }
            if (state.wasPastStartLine && refs.carGroup.position.x > -15 && refs.carGroup.position.x < -13 && nearStartZ && state.lapStartTime > 0) {
                const elapsed = (performance.now() - state.lapStartTime) / 1000;
                if (elapsed > 6.0) {
                    if (state.bestLapSec === null || elapsed < state.bestLapSec) {
                        state.bestLapSec = elapsed;
                        dom.hudBestLap.textContent = `${state.bestLapSec.toFixed(1)}s`;
                    }
                    if (state.lapCount >= 3) {
                        showFinishModal('3-LAP RACE COMPLETE', `${(state.bestLapSec || elapsed).toFixed(1)}s`);
                    }
                    state.lapCount++;
                    dom.hudLap.textContent = state.lapCount;
                    state.lapStartTime = performance.now();
                }
            }
            if (state.lapStartTime > 0) {
                const ltStr = ((performance.now() - state.lapStartTime) / 1000).toFixed(1);
                if (state.lastHudLapTime !== ltStr) {
                    state.lastHudLapTime = ltStr;
                    dom.hudLapTime.textContent = ltStr;
                }
            }
        }
        drawMinimap();

        state.wheelSpinAngle += state.carSpeed * 0.42 * frameScale;
        refs.wheels.forEach(w => { w.rotation.z = state.wheelSpinAngle; });

        state.replayBuffer.push({
            x: refs.carGroup.position.x, y: refs.carGroup.position.y, z: refs.carGroup.position.z,
            h: state.carHeading, pitch: state.bodyPitch, roll: state.bodyRoll,
            steer: state.steerAngle, spin: state.wheelSpinAngle, speed: state.carSpeed,
            wing: state.wingLift, drift: isDrifting, kmh, gear, rpmPct
        });
        if (state.replayBuffer.length > MAX_REPLAY_FRAMES) state.replayBuffer.shift();
        if (state.replayBuffer.length === 15) {
            dom.btnReplay.textContent = 'Replay';
        }
    } else if (state.isReplaying && state.replayBuffer.length > 0) {
        const fr = state.replayBuffer[state.replayIndex];
        refs.carGroup.position.set(fr.x, fr.y, fr.z);
        state.carHeading = fr.h;
        refs.carGroup.rotation.y = fr.h;
        refs.carGroup.rotation.z = fr.pitch;
        refs.carGroup.rotation.x = fr.roll;
        refs.frontSteerKnuckles.forEach(k => { k.rotation.y = fr.steer; });
        if (refs.steeringWheelMesh) refs.steeringWheelMesh.rotation.x = -fr.steer * 2.4;
        refs.wheels.forEach(w => { w.rotation.z = fr.spin; });
        state.wingLift = fr.wing;
        if (fr.drift) { spawnDriftSmoke(); spawnSkidMark(); }
        refs.flameMeshes.forEach(fm => { fm.visible = false; });
        if (refs.nosLight) refs.nosLight.intensity = 0;
        if (state.trackMode === 'openworld') updateInfiniteWorld();
        drawMinimap();

        updateDriveTelemetry(fr.kmh, fr.gear, fr.rpmPct, state.nosFuel, 0, 0, 0);

        state.replayIndex = (state.replayIndex + 1) % state.replayBuffer.length;
        state.replayCutTimer += frameScale;
        if (state.replayCutTimer > 210) {
            state.replayCutTimer = 0;
            state.replayCamCut = (state.replayCamCut + 1) % 4;
            if (state.replayCamCut === 2) {
                const lookIdx = (state.replayIndex + 70) % state.replayBuffer.length;
                const nf = state.replayBuffer[lookIdx];
                refs.apexCamPos.set(nf.x + (Math.random() - 0.5) * 6, 1.15, nf.z + (Math.random() - 0.5) * 6);
            }
        }
    } else {
        const idleLerp = dampFactor(0.12, frameScale);
        refs.frontSteerKnuckles.forEach(k => { k.rotation.y = THREE.MathUtils.lerp(k.rotation.y, 0, idleLerp); });
        if (refs.steeringWheelMesh) refs.steeringWheelMesh.rotation.x = THREE.MathUtils.lerp(refs.steeringWheelMesh.rotation.x, 0, idleLerp);
        refs.carGroup.rotation.x = THREE.MathUtils.lerp(refs.carGroup.rotation.x, 0, idleLerp);
        state.wingLift = THREE.MathUtils.lerp(state.wingLift, state.targetWingLift, dampFactor(0.1, frameScale));
        refs.wheels.forEach(w => { w.rotation.z += 0.005 * frameScale; });
        refs.flameMeshes.forEach(fm => { fm.visible = false; });
        if (refs.nosLight) refs.nosLight.intensity = 0;
        if (Math.abs(refs.camera.fov - 36) > 0.05) {
            refs.camera.fov = THREE.MathUtils.lerp(refs.camera.fov, 36, idleLerp);
            refs.camera.updateProjectionMatrix();
        }
    }

    // Update Drift Smoke Particles
    for (let i = refs.driftParticles.length - 1; i >= 0; i--) {
        const dp = refs.driftParticles[i];
        dp.life -= 0.025 * frameScale;
        dp.mesh.position.y += dp.vy * frameScale;
        dp.mesh.scale.multiplyScalar(Math.pow(1.03, frameScale));
        dp.mesh.material.opacity = Math.max(0, dp.life * 0.38);
        if (dp.life <= 0) {
            refs.scene.remove(dp.mesh);
            dp.mesh.material.dispose();
            refs.driftParticles.splice(i, 1);
        }
    }

    // Update Open World Traffic & Pedestrians
    if (state.trackMode === 'openworld' && state.trafficEnabled) {
        for (let i = 0; i < refs.trafficCars.length; i++) {
            const tc = refs.trafficCars[i];
            if (tc.stun > 0) {
                tc.stun -= frameScale;
                tc.mesh.position.x += tc.hitVx * frameScale;
                tc.mesh.position.z += tc.hitVz * frameScale;
                tc.mesh.rotation.y += tc.hitSpin * frameScale;
                tc.hitVx *= Math.pow(0.92, frameScale);
                tc.hitVz *= Math.pow(0.92, frameScale);
                tc.hitSpin *= Math.pow(0.9, frameScale);
            } else {
                const moveDelta = tc.speed * frameScale;
                if (tc.axis === 'x') {
                    tc.mesh.position.x += moveDelta * tc.dir;
                    if (tc.mesh.position.x - refs.carGroup.position.x > 130) tc.mesh.position.x = refs.carGroup.position.x - 130;
                    if (tc.mesh.position.x - refs.carGroup.position.x < -130) tc.mesh.position.x = refs.carGroup.position.x + 130;
                } else {
                    tc.mesh.position.z += moveDelta * tc.dir;
                    if (tc.mesh.position.z - refs.carGroup.position.z > 130) tc.mesh.position.z = refs.carGroup.position.z - 130;
                    if (tc.mesh.position.z - refs.carGroup.position.z < -130) tc.mesh.position.z = refs.carGroup.position.z + 130;
                }
                if (tc.wheels) {
                    const wheelSpin = moveDelta / 0.34;
                    for (let w = 0; w < tc.wheels.length; w++) {
                        tc.wheels[w].rotation.z -= wheelSpin;
                    }
                }
            }
        }
        for (let i = 0; i < refs.pedestrians.length; i++) {
            const pd = refs.pedestrians[i];
            if (pd.impacted) {
                pd.mesh.position.x += pd.vx * frameScale;
                pd.mesh.position.z += pd.vz * frameScale;
                pd.mesh.position.y += pd.vy * frameScale;
                pd.vy -= 0.014 * frameScale;
                if (pd.mesh.position.y <= 0.08) {
                    pd.mesh.position.y = 0.08;
                    pd.vy *= -0.25;
                    pd.vx *= Math.pow(0.72, frameScale);
                    pd.vz *= Math.pow(0.72, frameScale);
                }
                pd.mesh.rotation.x += pd.spinX * frameScale;
                pd.mesh.rotation.z += pd.spinZ * frameScale;
                pd.spinX *= Math.pow(0.94, frameScale);
                pd.spinZ *= Math.pow(0.94, frameScale);
                pd.recoverTimer -= frameScale;
                if (pd.recoverTimer <= 0) {
                    pd.impacted = false;
                    pd.mesh.position.set(pd.homeX, 0.08, pd.homeZ);
                    pd.mesh.rotation.set(0, 0, 0);
                }
            } else {
                if (pd.homeX - refs.carGroup.position.x > 115) pd.homeX -= 208;
                if (pd.homeX - refs.carGroup.position.x < -115) pd.homeX += 208;
                if (pd.homeZ - refs.carGroup.position.z > 115) pd.homeZ -= 208;
                if (pd.homeZ - refs.carGroup.position.z < -115) pd.homeZ += 208;
                pd.walkPhase += 0.03 * frameScale;
                const offset = Math.sin(pd.walkPhase) * 9.0;
                if (pd.walkAxis === 'x') pd.mesh.position.x = pd.homeX + offset;
                else pd.mesh.position.z = pd.homeZ + offset;
            }
        }
    }

    // Update Impact Sparks
    for (let i = refs.sparkParticles.length - 1; i >= 0; i--) {
        const sp = refs.sparkParticles[i];
        sp.life -= 0.05 * frameScale;
        sp.vy -= 0.012 * frameScale;
        sp.mesh.position.x += sp.vx * frameScale;
        sp.mesh.position.y = Math.max(0.04, sp.mesh.position.y + sp.vy * frameScale);
        sp.mesh.position.z += sp.vz * frameScale;
        sp.mesh.material.opacity = Math.max(0, sp.life);
        if (sp.life <= 0) {
            refs.scene.remove(sp.mesh);
            sp.mesh.material.dispose();
            refs.sparkParticles.splice(i, 1);
        }
    }

    // Doors & Engine Cover & Active Aero
    const aeroLerp = dampFactor(0.09, frameScale);
    state.doorAngle = THREE.MathUtils.lerp(state.doorAngle, state.targetDoorAngle, aeroLerp);
    const dL = refs.carGroup.getObjectByName('carDoorL');
    const dR = refs.carGroup.getObjectByName('carDoorR');
    if (dL) {
        dL.rotation.z = 0;
        dL.rotation.y = -state.doorAngle;
    }
    if (dR) {
        dR.rotation.z = 0;
        dR.rotation.y = state.doorAngle;
    }

    state.hoodAngle = THREE.MathUtils.lerp(state.hoodAngle, state.targetHoodAngle, aeroLerp);
    const frontHood = refs.carGroup.getObjectByName('frontHood');
    if (frontHood) frontHood.rotation.z = -state.hoodAngle;

    state.engineCoverAngle = THREE.MathUtils.lerp(state.engineCoverAngle, state.targetEngineCoverAngle, aeroLerp);
    const engCover = refs.carGroup.getObjectByName('engineCover');
    if (engCover) engCover.rotation.z = state.engineCoverAngle;

    const wing = refs.carGroup.getObjectByName('activeWing');
    if (wing) {
        wing.position.y = 0.96 + state.wingLift;
        wing.rotation.z = -state.wingLift * (state.keys.brake && state.carSpeed > 0.05 ? 2.2 : 1.1);
    }

    // Camera Modes
    refs.carGroup.updateMatrixWorld(true);
    if (state.isReplaying) {
        if (state.replayCamCut === 0) {
            const camLocal = new THREE.Vector3(2.4, 0.55, 2.2).applyMatrix4(refs.carGroup.matrixWorld);
            const tgtLocal = new THREE.Vector3(-0.3, 0.45, 0.0).applyMatrix4(refs.carGroup.matrixWorld);
            refs.camera.position.copy(camLocal);
            refs.camera.lookAt(tgtLocal);
        } else if (state.replayCamCut === 1) {
            const sweepAng = Date.now() * 0.0012;
            refs.camera.position.set(
                refs.carGroup.position.x + Math.cos(sweepAng) * 5.4,
                refs.carGroup.position.y + 1.9,
                refs.carGroup.position.z + Math.sin(sweepAng) * 5.4
            );
            refs.camera.lookAt(refs.carGroup.position.x, refs.carGroup.position.y + 0.55, refs.carGroup.position.z);
        } else if (state.replayCamCut === 2) {
            refs.camera.position.copy(refs.apexCamPos);
            refs.camera.lookAt(refs.carGroup.position.x, refs.carGroup.position.y + 0.45, refs.carGroup.position.z);
        } else {
            const eyePos = new THREE.Vector3(-0.14, 0.87, 0.38).applyMatrix4(refs.carGroup.matrixWorld);
            const lookFwd = new THREE.Vector3(-3.5, 0.74, 0.36).applyMatrix4(refs.carGroup.matrixWorld);
            refs.camera.position.copy(eyePos);
            refs.camera.lookAt(lookFwd);
        }
    } else if (state.camMode === 'fps') {
        const eyePos = new THREE.Vector3(-0.14, 0.87, 0.38).applyMatrix4(refs.carGroup.matrixWorld);
        const lookFwd = new THREE.Vector3(-3.5, 0.74, 0.36).applyMatrix4(refs.carGroup.matrixWorld);
        refs.camera.position.copy(eyePos);
        refs.camera.lookAt(lookFwd);
    } else if (state.camMode === 'chase') {
        const backX = Math.cos(state.carHeading) * 5.6;
        const backZ = -Math.sin(state.carHeading) * 5.6;
        refs.camera.position.set(
            refs.carGroup.position.x + backX,
            refs.carGroup.position.y + 1.85,
            refs.carGroup.position.z + backZ
        );
        refs.camera.lookAt(refs.carGroup.position.x, refs.carGroup.position.y + 0.65, refs.carGroup.position.z);
    } else {
        const orbLerp = dampFactor(0.12, frameScale);
        state.rotation.x = THREE.MathUtils.lerp(state.rotation.x, state.targetRotation.x, orbLerp);
        state.rotation.y = THREE.MathUtils.lerp(state.rotation.y, state.targetRotation.y, orbLerp);
        state.zoom = THREE.MathUtils.lerp(state.zoom, state.targetZoom, orbLerp);
        refs.lookTarget.lerp(refs.desiredLookTarget, dampFactor(0.1, frameScale));

        refs.camera.position.x = refs.lookTarget.x + Math.sin(state.rotation.y) * Math.cos(state.rotation.x) * state.zoom;
        refs.camera.position.y = refs.lookTarget.y + Math.sin(state.rotation.x) * state.zoom;
        refs.camera.position.z = refs.lookTarget.z + Math.cos(state.rotation.y) * Math.cos(state.rotation.x) * state.zoom;
        refs.camera.lookAt(refs.lookTarget);
    }

    refs.renderer.render(refs.scene, refs.camera);
}
