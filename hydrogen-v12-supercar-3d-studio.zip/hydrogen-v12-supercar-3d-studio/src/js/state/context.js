import { DEFAULT_SETTINGS, SETTINGS_STORAGE_KEY } from '../config/constants.js';

export const state = {
    finishIdx: 0,
    timeIdx: 0,
    driveMode: false,
    aiDriverActive: false,
    camMode: 'orbit',
    trackMode: 'circuit', // 'circuit' | 'drag' | 'openworld'
    isDragMode: false,
    menuTrackChoice: 'circuit',
    menuCamChoice: 'fps',
    raceLocked: false,
    trafficEnabled: true,
    underglowEnabled: true,

    // Physics & Driving
    carHeading: 0,
    velocityHeading: 0,
    driftSlipAngle: 0,
    carSpeed: 0,
    steerAngle: 0,
    wheelSpinAngle: 0,
    bodyPitch: 0,
    bodyRoll: 0,
    manualSteerInput: 0,
    isWheelDragging: false,
    wheelDragStartX: 0,
    nosFuel: 100,
    nosDepleted: false,
    topSpeedKmh: 0,
    chassisIntegrity: 100,
    turboBoostMult: 1.08,
    settings: { ...DEFAULT_SETTINGS },
    speedMultiplier: 1.0,
    collisionCooldown: 0,

    // Lap / Drag Timing
    lapCount: 1,
    lapStartTime: 0,
    bestLapSec: null,
    wasPastStartLine: false,
    dragStarted: false,
    dragFinished: false,
    dragStartMs: 0,
    dragZero100: null,

    // Animations & Suspension
    doorAngle: 0,
    targetDoorAngle: 0,
    hoodAngle: 0,
    targetHoodAngle: 0,
    engineCoverAngle: 0,
    targetEngineCoverAngle: 0,
    wingLift: 0,
    targetWingLift: 0,
    velocityY: 0,
    suspensionOffset: 0,
    suspensionVelocity: 0,

    // Orbit Camera
    isDragging: false,
    previousMousePosition: { x: 0, y: 0 },
    rotation: { x: 0.22, y: -2.35 },
    targetRotation: { x: 0.22, y: -2.35 },
    zoom: 7.4,
    targetZoom: 7.4,
    initialPinchDistance: 0,

    // Replay & Recording
    replayBuffer: [],
    isReplaying: false,
    replayIndex: 0,
    replayCamCut: 0,
    replayCutTimer: 0,
    isRecordingVideo: false,
    recordedChunks: [],

    // World Generation
    lastChunkKey: '',
    worldMorphSeed: 1,
    minimapExpanded: false,

    // Audio
    soundEnabled: false,
    lastGear: 'N',
    wasGasPressed: false,

    // UI Cache (avoid redundant DOM writes in render loop)
    lastHudSpeed: null,
    lastHudGear: null,
    lastHudLapTime: null,
    lastHudBestLap: null,
    lastRpmPct: null,
    lastNosPct: null,
    lastSteerDeg: null,
    lastGForceTransform: null,

    // Input State
    keys: { gas: false, brake: false, left: false, right: false, handbrake: false, nos: false }
};

// ==========================================================
// TIMERS & SCENE / AUDIO REFERENCES
// ==========================================================
export const timers = {
    boot: [],
    countdown: [],
    dragTree: [],
    statusReset: null
};

export function clearTimerList(list) {
    while (list.length > 0) {
        clearTimeout(list.pop());
    }
}

export const refs = {
    scene: null,
    camera: null,
    renderer: null,
    carGroup: null,
    lookTarget: null,
    desiredLookTarget: null,
    apexCamPos: null,
    wheels: [],
    frontSteerKnuckles: [],
    steeringWheelMesh: null,
    headlightSpotL: null,
    headlightSpotR: null,
    flameMeshes: [],
    nosLight: null,
    skidMarks: [],
    skidGeo: null,
    skidMat: null,
    driftParticles: [],
    sparkParticles: [],
    smokeGeo: null,
    smokeMat: null,
    sparkGeo: null,
    sparkMat: null,
    trackSamples: [],
    buildingColliders: [],
    circuitWorldGroup: null,
    dragWorldGroup: null,
    openWorldGroup: null,
    openWorldColliders: [],
    owChunks: new Map(),
    owGroundMesh: null,
    owChunkAssets: null,
    trafficCars: [],
    pedestrians: [],
    treeLights: [],
    underglowGroup: null,
    hemiLightRef: null,
    keyLightRef: null,
    lampMatRef: null,
    winCyanRef: null,
    winWarmRef: null,
    archDetailMats: null,
    paintMat: null,
    wrapTex: null,
    carbonMat: null,
    darkTrimMat: null,
    chromeMat: null,
    alloyMat: null,
    glassMat: null,
    tireMat: null,
    caliperMat: null,
    goldFoilMat: null,
    alcantaraMat: null,
    screenMat: null,
    drlMat: null,
    tailLedMat: null,
    exhaustGlowMat: null,
    engineLedMat: null,
    stripeMat: null,
    audioCtx: null,
    osc1: null,
    osc2: null,
    oscSub: null,
    oscHarm: null,
    engineFilter: null,
    gainNode: null,
    audioDest: null,
    screechGain: null,
    nosGain: null,
    noiseBufferGlobal: null,
    sfxBuffers: {},
    mediaRecorder: null,
    minimapCtx: null
};

export const dom = {};

export function loadSettings() {
    const loaded = { ...DEFAULT_SETTINGS };
    try {
        const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
        if (!raw) return loaded;
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') {
            Object.keys(DEFAULT_SETTINGS).forEach(key => {
                if (key === 'speedMultiplier') {
                    const spd = Number(parsed.speedMultiplier);
                    if (Number.isFinite(spd)) {
                        loaded.speedMultiplier = Math.max(0.5, Math.min(2.0, Math.round(spd * 10) / 10));
                    }
                } else if (typeof parsed[key] === 'boolean') {
                    loaded[key] = parsed[key];
                }
            });
        }
    } catch {
        // Ignore storage read/parse errors
    }
    return loaded;
}

export function saveSettings() {
    try {
        localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(state.settings));
    } catch {
        // Ignore storage quota/privacy errors
    }
}

export function applySettings(patch = {}, persist = true) {
    const next = { ...state.settings, ...patch };
    if (Number.isFinite(next.speedMultiplier)) {
        next.speedMultiplier = Math.max(0.5, Math.min(2.0, Math.round(next.speedMultiplier * 10) / 10));
    } else {
        next.speedMultiplier = DEFAULT_SETTINGS.speedMultiplier;
    }
    state.settings = next;
    state.speedMultiplier = next.speedMultiplier;

    if (dom.settingToggles) {
        dom.settingToggles.forEach(toggle => {
            const key = toggle.dataset.uiKey;
            if (!Object.prototype.hasOwnProperty.call(next, key)) return;
            const hidden = Boolean(next[key]);
            const isOn = !hidden;
            document.body.classList.toggle(key, hidden);
            toggle.classList.toggle('on', isOn);
            toggle.textContent = isOn ? 'ON' : 'OFF';
            toggle.setAttribute('aria-pressed', String(isOn));
        });
    }

    if (dom.speedMultSlider) dom.speedMultSlider.value = next.speedMultiplier.toFixed(1);
    if (dom.speedMultVal) dom.speedMultVal.textContent = `${next.speedMultiplier.toFixed(1)}x`;
    if (persist) saveSettings();
}

export function cacheDom() {
    const ids = [
        'bootOverlay', 'bootLines', 'bootBarFill', 'bootPct', 'btnBootSkip',
        'startMenu', 'btnStartRace', 'btnStartAI', 'btnInspectGarage', 'btnMenuSettings',
        'countdownOverlay', 'settingsModal', 'btnCloseSettings', 'btnResetSettings',
        'speedMultVal', 'speedMultSlider',
        'finishModal', 'finishTitle', 'statTime', 'statTopSpeed', 'btnRaceAgain', 'btnFinishReplay', 'btnBackMenu',
        'subtitle', 'status',
        'btnSideMenu', 'sideControls',
        'btnDoors', 'btnHood', 'btnEngine', 'btnWing', 'btnFinish', 'btnDrop', 'btnDrive', 'btnAI',
        'btnTrackMode', 'btnTimeShift', 'btnTraffic', 'btnUnderglow', 'btnReplay', 'btnSound',
        'btnRestart', 'btnMenu', 'btnSettings', 'btnExportObj', 'btnExportVideo',
        'replayBanner', 'driveHud', 'hudSpeed', 'hudGear', 'rpmFill', 'nosFill',
        'gforceDot', 'dmgPct', 'dmgFill', 'hudLap', 'hudLapTime', 'hudBestLap',
        'customDrawer', 'liveryPicker', 'stripePicker', 'upgAero', 'upgTurbo',
        'minimapWrap', 'minimapCanvas', 'steerWheelPad', 'steerWheelSvg', 'touchDrive'
    ];
    ids.forEach(id => { dom[id] = document.getElementById(id); });
    dom.camBtns = Array.from(document.querySelectorAll('.cam-btn'));
    dom.menuTrackBtns = Array.from(document.querySelectorAll('[data-menu-track]'));
    dom.menuCamBtns = Array.from(document.querySelectorAll('[data-menu-cam]'));
    dom.settingToggles = Array.from(document.querySelectorAll('.setting-toggle'));
    dom.driveKeys = Array.from(document.querySelectorAll('.drive-key'));
    dom.gasBtn = document.querySelector('.drive-key[data-key="gas"]');
    dom.driftBtn = document.querySelector('.drive-key[data-key="handbrake"]');
    dom.brakeBtn = document.querySelector('.drive-key[data-key="brake"]');
    dom.nosBtn = document.querySelector('.drive-key[data-key="nos"]');
    if (dom.minimapCanvas) {
        refs.minimapCtx = dom.minimapCanvas.getContext('2d');
    }
}
