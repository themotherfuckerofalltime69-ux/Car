import { FINISHES } from '../config/constants.js';
import { state, refs, dom } from '../state/context.js';
import { updateStatus } from '../ui/hudControls.js';
import { toggleV12Sound } from '../audio/soundEngine.js';

export function toggleVideoExport() {
    if (!state.isRecordingVideo) {
        try {
            if (typeof MediaRecorder === 'undefined' || !refs.renderer.domElement.captureStream) {
                throw new Error('MediaRecorder unavailable');
            }
            if (!state.soundEnabled) toggleV12Sound();
            const videoStream = refs.renderer.domElement.captureStream(60);
            const tracks = [...videoStream.getVideoTracks()];
            if (refs.audioDest && refs.audioDest.stream) {
                tracks.push(...audioDest.stream.getAudioTracks());
            }
            const combinedStream = new MediaStream(tracks);
            const mime = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
                ? 'video/webm;codecs=vp9,opus'
                : MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')
                    ? 'video/webm;codecs=vp8,opus'
                    : 'video/webm';

            state.recordedChunks = [];
            refs.mediaRecorder = new MediaRecorder(combinedStream, { mimeType: mime, videoBitsPerSecond: 12000000 });
            refs.mediaRecorder.ondataavailable = e => {
                if (e.data && e.data.size > 0) state.recordedChunks.push(e.data);
            };
            refs.mediaRecorder.onerror = () => {
                state.isRecordingVideo = false;
                dom.btnExportVideo.textContent = 'Export Video';
                dom.btnExportVideo.classList.remove('active');
                updateStatus(FINISHES[state.finishIdx].status, 'VIDEO_UNSUPPORTED', 2200);
            };
            refs.mediaRecorder.onstop = () => {
                const blob = new Blob(state.recordedChunks, { type: 'video/webm' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'hydrogen-v12-supercar-60fps.webm';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                setTimeout(() => URL.revokeObjectURL(url), 1000);
                updateStatus(FINISHES[state.finishIdx].status, 'VIDEO_60FPS_SAVED', 2200);
            };
            refs.mediaRecorder.start(200);
            state.isRecordingVideo = true;
            dom.btnExportVideo.textContent = 'Stop & Save Video';
            dom.btnExportVideo.classList.add('active');
            updateStatus(FINISHES[state.finishIdx].status, 'VIDEO_REC_60FPS');
        } catch {
            updateStatus(FINISHES[state.finishIdx].status, 'VIDEO_UNSUPPORTED', 2200);
        }
    } else {
        state.isRecordingVideo = false;
        dom.btnExportVideo.textContent = 'Export Video';
        dom.btnExportVideo.classList.remove('active');
        if (refs.mediaRecorder && refs.mediaRecorder.state !== 'inactive') {
            refs.mediaRecorder.stop();
        }
    }
}

export function exportToOBJ() {
    refs.carGroup.updateMatrixWorld(true);
    const rootInverse = new THREE.Matrix4().copy(refs.carGroup.matrixWorld).invert();
    const lines = ['# Hydrogen V12 Supercar - Wavefront OBJ (vehicle-local coordinates)', 'o Hydrogen_V12_Supercar'];
    let vertexOffset = 1;
    let normalOffset = 1;
    let meshIndex = 0;

    const v = new THREE.Vector3();
    const n = new THREE.Vector3();
    const normalMatrix = new THREE.Matrix3();

    refs.carGroup.traverse(child => {
        if (!child.isMesh || !child.geometry) return;
        let visible = true;
        for (let node = child; node && node !== refs.carGroup; node = node.parent) {
            if (!node.visible) { visible = false; break; }
        }
        if (!visible) return;

        const geom = child.geometry;
        const posAttr = geom.getAttribute('position');
        if (!posAttr) return;

        const normAttr = geom.getAttribute('normal');
        const indexAttr = geom.getIndex();
        const matWorld = new THREE.Matrix4().multiplyMatrices(rootInverse, child.matrixWorld);
        normalMatrix.getNormalMatrix(matWorld);

        meshIndex++;
        lines.push(`g ${child.name || 'part_' + meshIndex}`);

        for (let i = 0; i < posAttr.count; i++) {
            v.fromBufferAttribute(posAttr, i).applyMatrix4(matWorld);
            lines.push(`v ${v.x.toFixed(5)} ${v.y.toFixed(5)} ${v.z.toFixed(5)}`);
        }

        if (normAttr) {
            for (let i = 0; i < normAttr.count; i++) {
                n.fromBufferAttribute(normAttr, i).applyMatrix3(normalMatrix).normalize();
                lines.push(`vn ${n.x.toFixed(5)} ${n.y.toFixed(5)} ${n.z.toFixed(5)}`);
            }
        }

        const triCount = indexAttr ? indexAttr.count / 3 : posAttr.count / 3;
        for (let t = 0; t < triCount; t++) {
            const a = indexAttr ? indexAttr.getX(t * 3) : t * 3;
            const b = indexAttr ? indexAttr.getX(t * 3 + 1) : t * 3 + 1;
            const c = indexAttr ? indexAttr.getX(t * 3 + 2) : t * 3 + 2;
            if (normAttr) {
                lines.push(`f ${a + vertexOffset}//${a + normalOffset} ${b + vertexOffset}//${b + normalOffset} ${c + vertexOffset}//${c + normalOffset}`);
            } else {
                lines.push(`f ${a + vertexOffset} ${b + vertexOffset} ${c + vertexOffset}`);
            }
        }

        vertexOffset += posAttr.count;
        if (normAttr) normalOffset += normAttr.count;
    });

    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'hydrogen-v12-supercar.obj';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);

    updateStatus(FINISHES[state.finishIdx].status, 'OBJ_EXPORTED', 2200);
}
