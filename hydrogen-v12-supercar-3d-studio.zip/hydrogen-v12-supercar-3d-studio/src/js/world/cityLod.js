import { CHUNK_SIZE } from '../config/constants.js';
import { state, refs } from '../state/context.js';

export function addArchitecturalBuildingDetail(group, width, height, depth, styleSeed = 0) {
    if (!refs.archDetailMats) {
        refs.archDetailMats = {
            trim: new THREE.MeshStandardMaterial({ color: 0x596579, roughness: 0.58, metalness: 0.48 }),
            dark: new THREE.MeshStandardMaterial({ color: 0x101722, roughness: 0.78, metalness: 0.22 }),
            glass: new THREE.MeshStandardMaterial({ color: 0x183448, emissive: 0x071b2b, emissiveIntensity: 0.65, roughness: 0.2, metalness: 0.55, transparent: true, opacity: 0.88 }),
            warm: new THREE.MeshStandardMaterial({ color: 0xffd58a, emissive: 0x9a5b1b, emissiveIntensity: 0.55, roughness: 0.3 }),
            roof: new THREE.MeshStandardMaterial({ color: 0x202b39, roughness: 0.82, metalness: 0.18 })
        };
    }
    const m = refs.archDetailMats;
    const addBox = (w, h, d, x, y, z, mat, cast = false) => {
        const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
        mesh.position.set(x, y, z);
        mesh.castShadow = cast;
        mesh.receiveShadow = true;
        group.add(mesh);
        return mesh;
    };

    const cornerGeo = new THREE.BoxGeometry(0.22, height, 0.24);
    const corners = new THREE.InstancedMesh(cornerGeo, m.trim, 4);
    const dummy = new THREE.Object3D();
    let ci = 0;
    for (const x of [-1, 1]) {
        for (const z of [-1, 1]) {
            dummy.position.set(x * (width / 2 - 0.18), height / 2, z * (depth / 2 - 0.18));
            dummy.updateMatrix();
            corners.setMatrixAt(ci++, dummy.matrix);
        }
    }
    corners.instanceMatrix.needsUpdate = true;
    group.add(corners);
    addBox(width + 0.34, 0.32, depth + 0.34, 0, 0.18, 0, m.dark);

    const lobbyH = Math.min(3.6, height * 0.22);
    for (const side of [-1, 1]) {
        addBox(width * 0.72, lobbyH, 0.09, 0, lobbyH / 2 + 0.42, side * (depth / 2 + 0.055), m.glass);
        addBox(0.16, lobbyH + 0.25, 0.18, 0, lobbyH / 2 + 0.42, side * (depth / 2 + 0.13), m.trim);
    }
    addBox(Math.min(width * 0.62, 8.5), 0.18, 2.0, 0, lobbyH + 0.7, depth / 2 + 0.72, m.trim);
    addBox(Math.min(width * 0.28, 3.2), 0.12, 0.12, 0, lobbyH + 0.82, depth / 2 + 1.72, m.warm);

    const floorStep = height > 30 ? 4.2 : 3.8;
    const bandCount = Math.max(1, Math.floor((height - 5) / floorStep));
    const bandGeo = new THREE.BoxGeometry(width + 0.24, 0.105, depth + 0.24);
    const bands = new THREE.InstancedMesh(bandGeo, m.trim, bandCount);
    for (let i = 0; i < bandCount; i++) {
        dummy.position.set(0, 3.8 + i * floorStep, 0);
        dummy.updateMatrix();
        bands.setMatrixAt(i, dummy.matrix);
    }
    bands.instanceMatrix.needsUpdate = true;
    group.add(bands);

    const parapetH = 0.72;
    addBox(width + 0.22, parapetH, 0.22, 0, height + parapetH / 2, depth / 2, m.roof);
    addBox(width + 0.22, parapetH, 0.22, 0, height + parapetH / 2, -depth / 2, m.roof);
    addBox(0.22, parapetH, depth, width / 2, height + parapetH / 2, 0, m.roof);
    addBox(0.22, parapetH, depth, -width / 2, height + parapetH / 2, 0, m.roof);

    const unitW = Math.max(1.2, Math.min(3.2, width * 0.2));
    for (let i = 0; i < 3; i++) {
        const x = (i - 1) * (unitW + 0.65);
        addBox(unitW, 0.85, Math.max(1.2, depth * 0.18), x, height + 1.05, -depth * 0.12, m.roof, true);
        addBox(unitW * 0.72, 0.12, 0.18, x, height + 1.52, -depth * 0.12, m.trim);
    }
    addBox(0.12, Math.min(4.5, height * 0.12), 0.12, width * 0.28, height + 2.7, depth * 0.2, m.trim);
    addBox(1.1, 0.12, 0.12, width * 0.28, height + 4.0, depth * 0.2, m.trim);

    if ((styleSeed % 3) !== 1) {
        const finCount = Math.max(2, Math.floor(width / 5));
        const finGeo = new THREE.BoxGeometry(0.11, height * 0.72, 0.16);
        const fins = new THREE.InstancedMesh(finGeo, m.trim, finCount * 2);
        let fi = 0;
        for (const side of [-1, 1]) {
            for (let i = 0; i < finCount; i++) {
                dummy.position.set(-width / 2 + (i + 0.5) * width / finCount, height * 0.55, side * (depth / 2 + 0.08));
                dummy.updateMatrix();
                fins.setMatrixAt(fi++, dummy.matrix);
            }
        }
        fins.instanceMatrix.needsUpdate = true;
        group.add(fins);
    }
}

export function createUrbanBuildingLOD(width, height, depth, baseMaterial, windowMaterial) {
    const lod = new THREE.LOD();
    const near = new THREE.Group();
    const shell = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), baseMaterial);
    shell.position.y = height / 2;
    shell.castShadow = true;
    shell.receiveShadow = true;
    near.add(shell);

    const colsW = Math.max(3, Math.floor(width / 2.8));
    const colsD = Math.max(2, Math.floor(depth / 2.8));
    const rows = Math.max(2, Math.floor((height - 3) / 3.8));
    const count = (colsW + colsD) * rows * 2;
    const geo = new THREE.BoxGeometry(0.82, 1.18, 0.07);
    const panes = new THREE.InstancedMesh(geo, windowMaterial, count);
    const dummy = new THREE.Object3D();
    let index = 0;

    for (let row = 0; row < rows; row++) {
        const y = 2.5 + row * 3.8;
        for (let col = 0; col < colsW; col++) {
            const x = -width / 2 + (col + 0.5) * width / colsW;
            for (const side of [-1, 1]) {
                dummy.position.set(x, y, side * (depth / 2 + 0.04));
                dummy.rotation.set(0, side < 0 ? 0 : Math.PI, 0);
                dummy.updateMatrix();
                panes.setMatrixAt(index, dummy.matrix);
                panes.setColorAt(index, ((row + col) % 5 === 0) ? new THREE.Color(0xffd995) : new THREE.Color(0x77cfff));
                index++;
            }
        }
        for (let col = 0; col < colsD; col++) {
            const z = -depth / 2 + (col + 0.5) * depth / colsD;
            for (const side of [-1, 1]) {
                dummy.position.set(side * (width / 2 + 0.04), y, z);
                dummy.rotation.set(0, side < 0 ? -Math.PI / 2 : Math.PI / 2, 0);
                dummy.updateMatrix();
                panes.setMatrixAt(index, dummy.matrix);
                panes.setColorAt(index, ((row + col) % 6 === 0) ? new THREE.Color(0xffd995) : new THREE.Color(0x77cfff));
                index++;
            }
        }
    }
    panes.count = index;
    panes.instanceMatrix.needsUpdate = true;
    if (panes.instanceColor) panes.instanceColor.needsUpdate = true;
    near.add(panes);
    addArchitecturalBuildingDetail(near, width, height, depth, Math.round(width * 13 + height * 7 + depth));
    const roof = new THREE.Mesh(new THREE.BoxGeometry(width * 0.32, 0.9, depth * 0.28), baseMaterial);
    roof.position.set(width * 0.16, height + 0.45, -depth * 0.12);
    near.add(roof);
    lod.addLevel(near, 0);

    const mid = new THREE.Group();
    const midShell = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), baseMaterial);
    midShell.position.y = height / 2;
    mid.add(midShell);
    for (let y = 4.5; y < height - 1.5; y += 7.6) {
        const band = new THREE.Mesh(new THREE.BoxGeometry(width + 0.1, 0.16, depth + 0.1), windowMaterial);
        band.position.y = y;
        mid.add(band);
    }
    lod.addLevel(mid, 58);

    const far = new THREE.Group();
    const silhouette = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), baseMaterial);
    silhouette.position.y = height / 2;
    far.add(silhouette);
    lod.addLevel(far, 125);
    return lod;
}

export function getWorldZone(cx, cz) {
    if (cz >= 2) return 'waterfront';
    if (cx >= 2) return 'highway';
    if (cx <= -2 || cz <= -2) return 'suburban';
    return 'downtown';
}

export function buildOpenWorldChunk(cx, cz) {
    const bx = cx * CHUNK_SIZE + 26;
    const bz = cz * CHUNK_SIZE + 26;
    const a = refs.owChunkAssets;
    const grp = new THREE.Group();
    const cols = [];
    const buildings = [];
    const zone = getWorldZone(cx, cz);
    const addCol = (x, z, w, d) => {
        cols.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2 });
        buildings.push({ x, z, w, d });
    };

    // Real-world avenue lane dashes + intersection crosswalks
    for (let d = -20; d <= 20; d += 10) {
        const dEW = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.015, 0.22), a.lampMat);
        dEW.position.set(bx + d, 0.025, cz * CHUNK_SIZE);
        const dNS = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.015, 4.5), a.lampMat);
        dNS.position.set(cx * CHUNK_SIZE, 0.025, bz + d);
        grp.add(dEW, dNS);
    }
    for (let cw = -5; cw <= 5; cw += 2) {
        const stripeX = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.016, 0.65), a.whiteMat);
        stripeX.position.set(cx * CHUNK_SIZE + cw, 0.026, cz * CHUNK_SIZE + 8.5);
        const stripeZ = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.016, 1.8), a.whiteMat);
        stripeZ.position.set(cx * CHUNK_SIZE + 8.5, 0.026, cz * CHUNK_SIZE + cw);
        grp.add(stripeX, stripeZ);
    }

    const sw = new THREE.Mesh(new THREE.BoxGeometry(36, 0.08, 36), a.sidewalkMat);
    sw.position.set(bx, 0.04, bz);
    sw.receiveShadow = true;
    grp.add(sw);

    const hash = Math.abs((cx * 73856093) ^ (cz * 19349663) ^ (state.worldMorphSeed * 83492791)) % 10;
    let kind = 'towers';

    if (zone === 'waterfront') {
        kind = 'waterfront';
        const waterMat = new THREE.MeshStandardMaterial({ color: 0x0369a1, roughness: 0.18, metalness: 0.35 });
        const ocean = new THREE.Mesh(new THREE.BoxGeometry(35, 0.06, 22), waterMat);
        ocean.position.set(bx, 0.08, bz + 6);
        const boardwalk = new THREE.Mesh(new THREE.BoxGeometry(35, 0.14, 11), a.trunkMat);
        boardwalk.position.set(bx, 0.09, bz - 11.5);
        grp.add(ocean, boardwalk);
        addCol(bx, bz + 6, 35, 22);
        [-12, 0, 12].forEach(px => {
            const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.32, 3.2, 7), a.trunkMat);
            trunk.position.set(bx + px, 1.6, bz - 8);
            const crown = new THREE.Mesh(new THREE.ConeGeometry(1.9, 2.2, 7), a.leafMat);
            crown.position.set(bx + px, 3.6, bz - 8);
            grp.add(trunk, crown);
            addCol(bx + px, bz - 8, 1.0, 1.0);
        });
    } else if (zone === 'highway' && (hash % 3 === 0)) {
        kind = 'industrial';
        const yard = new THREE.Mesh(new THREE.BoxGeometry(34, 0.05, 34), a.roadMat);
        yard.position.set(bx, 0.09, bz);
        const hangar = new THREE.Mesh(new THREE.BoxGeometry(26, 8.5, 16), a.aptMat);
        hangar.position.set(bx, 4.25, bz - 5);
        const canopy = new THREE.Mesh(new THREE.BoxGeometry(14, 0.5, 6), a.winCyan);
        canopy.position.set(bx, 4.2, bz + 9);
        grp.add(yard, hangar, canopy);
        addCol(bx, bz - 5, 26, 16);
    } else if (hash === 0 || (zone === 'suburban' && hash <= 2)) {
        kind = 'park';
        const lawn = new THREE.Mesh(new THREE.BoxGeometry(33, 0.06, 33), a.grassMat);
        lawn.position.set(bx, 0.09, bz);
        grp.add(lawn);
        const fountain = new THREE.Mesh(new THREE.CylinderGeometry(3.4, 3.8, 0.55, 16), a.sidewalkMat);
        fountain.position.set(bx, 0.34, bz);
        const water = new THREE.Mesh(new THREE.CylinderGeometry(2.9, 2.9, 0.4, 16), a.winCyan);
        water.position.set(bx, 0.45, bz);
        grp.add(fountain, water);
        addCol(bx, bz, 7.2, 7.2);
        [[-10, -10], [10, -10], [-10, 10], [10, 10]].forEach(tp => {
            const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.35, 2.4, 7), a.trunkMat);
            trunk.position.set(bx + tp[0], 1.2, bz + tp[1]);
            const crown = new THREE.Mesh(new THREE.ConeGeometry(2.0, 4.0, 7), a.leafMat);
            crown.position.set(bx + tp[0], 3.7, bz + tp[1]);
            grp.add(trunk, crown);
            addCol(bx + tp[0], bz + tp[1], 1.0, 1.0);
        });
    } else if (hash === 3) {
        kind = 'commercial';
        const lot = new THREE.Mesh(new THREE.BoxGeometry(34, 0.05, 34), a.roadMat);
        lot.position.set(bx, 0.09, bz);
        grp.add(lot);
        for (let px = -12; px <= 12; px += 4) {
            const stall = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.02, 5.2), a.whiteMat);
            stall.position.set(bx + px, 0.12, bz + 9.5);
            grp.add(stall);
        }
        const store = new THREE.Mesh(new THREE.BoxGeometry(28, 6.2, 12), a.bldgMat2);
        store.position.set(bx, 3.1, bz - 8);
        const sign = new THREE.Mesh(new THREE.BoxGeometry(16, 1.4, 0.4), a.marketSignMat);
        sign.position.set(bx, 5.2, bz - 1.9);
        const glassFront = new THREE.Mesh(new THREE.BoxGeometry(12, 3.2, 0.3), a.winWarm);
        glassFront.position.set(bx, 1.8, bz - 1.9);
        grp.add(store, sign, glassFront);
        addCol(bx, bz - 8, 28, 12);
    } else if (zone === 'suburban' || hash === 4) {
        kind = 'suburban';
        [-8.5, 8.5].forEach(az => {
            const apt = createUrbanBuildingLOD(28, 16, 11, a.aptMat, a.winWarm);
            apt.position.set(bx, 0, bz + az);
            grp.add(apt);
            addCol(bx, bz + az, 28, 11);
            for (let wy = 3; wy <= 13; wy += 3.5) {
                const balc = new THREE.Mesh(new THREE.BoxGeometry(28.6, 0.3, 11.6), a.sidewalkMat);
                balc.position.set(bx, wy, bz + az);
                const winStrip = new THREE.Mesh(new THREE.BoxGeometry(28.1, 1.0, 11.1), a.winWarm);
                winStrip.position.set(bx, wy + 1.1, bz + az);
                grp.add(balc, winStrip);
            }
        });
    } else if (hash === 5) {
        kind = 'plaza';
        const plaza = new THREE.Mesh(new THREE.BoxGeometry(34, 0.05, 34), a.roadMat);
        plaza.position.set(bx, 0.09, bz);
        const ring = new THREE.Mesh(new THREE.RingGeometry(8, 8.5, 32), a.winCyan);
        ring.rotation.x = -Math.PI / 2;
        ring.position.set(bx, 0.125, bz);
        grp.add(plaza, ring);
    } else {
        kind = 'towers';
        const h1 = 18 + ((hash * 9 + Math.abs(cx * 7)) % 36);
        const h2 = 16 + ((hash * 5 + Math.abs(cz * 11)) % 34);
        const b1 = createUrbanBuildingLOD(13, h1, 28, a.bldgMat1, (hash % 2 === 0) ? a.winCyan : a.winWarm);
        b1.position.set(bx - 9.5, 0, bz);
        const b2 = createUrbanBuildingLOD(13, h2, 28, a.bldgMat2, (hash % 2 === 0) ? a.winCyan : a.winWarm);
        b2.position.set(bx + 9.5, 0, bz);
        grp.add(b1, b2);
        addCol(bx - 9.5, bz, 13, 28);
        addCol(bx + 9.5, bz, 13, 28);
    }

    return { group: grp, colliders: cols, meta: { cx, cz, zone, kind, buildings } };
}

export function updateInfiniteWorld(force = false) {
    if (!refs.owChunkAssets || !refs.openWorldGroup) return;
    const cxPos = refs.carGroup ? refs.carGroup.position.x : 0;
    const czPos = refs.carGroup ? refs.carGroup.position.z : 0;
    const pcx = Math.floor(cxPos / CHUNK_SIZE);
    const pcz = Math.floor(czPos / CHUNK_SIZE);

    if (refs.owGroundMesh) {
        refs.owGroundMesh.position.set(cxPos, 0, czPos);
    }

    const key = `${pcx},${pcz},${state.worldMorphSeed}`;
    if (!force && key === state.lastChunkKey) return;
    state.lastChunkKey = key;

    const needed = new Set();
    for (let dx = -2; dx <= 2; dx++) {
        for (let dz = -2; dz <= 2; dz++) {
            const cx = pcx + dx;
            const cz = pcz + dz;
            const ck = `${cx},${cz}`;
            needed.add(ck);
            if (!refs.owChunks.has(ck)) {
                const built = buildOpenWorldChunk(cx, cz);
                refs.openWorldGroup.add(built.group);
                refs.owChunks.set(ck, built);
            }
        }
    }
    for (const [ck, val] of refs.owChunks.entries()) {
        if (!needed.has(ck)) {
            refs.openWorldGroup.remove(val.group);
            val.group.traverse(c => { if (c.geometry) c.geometry.dispose(); });
            refs.owChunks.delete(ck);
        }
    }
    refs.openWorldColliders = [];
    for (const val of refs.owChunks.values()) {
        for (let i = 0; i < val.colliders.length; i++) {
            refs.openWorldColliders.push(val.colliders[i]);
        }
    }
}
